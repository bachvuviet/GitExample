/***
<Synonym>
	<Description>Synonym for Discovery.dbo.XMLServicesLog - a legacy logging table.</Description>
	<Columns>
	    <Column Name="Id">
			<Description>Id</Description>
			<DataType>int</DataType>
			<IsIdentity>true</IsIdentity>
		</Column>
		<Column Name="LogTime">
			<Description>LogTime</Description>
			<DataType>datetime</DataType>
		</Column>
		<Column Name="Request">
			<Description>Request</Description>
			<DataType>varchar(max)</DataType>
		</Column>
		<Column Name="Response">
			<Description>Response</Description>
			<DataType>varchar(max)</DataType>
		</Column>
		<Column Name="Url">
			<Description>Url</Description>
			<DataType>varchar(max)</DataType>
		</Column>
		<Column Name="UserId">
			<Description>UserId</Description>
			<DataType>int</DataType>
		</Column>
		<Column Name="ServiceName">
			<Description>ServiceName</Description>
			<DataType>varchar(500)</DataType>
		</Column>
		<Column Name="OperationName">
			<Description>OperationName</Description>
			<DataType>varchar(100)</DataType>
		</Column>
		<Column Name="Method">
			<Description>Method</Description>
			<DataType>varchar(20)</DataType>
		</Column>
		<Column Name="ServiceReference">
			<Description>ServiceReference</Description>
			<DataType>varchar(100)</DataType>
		</Column>
		<Column Name="ResponseTimeInMs">
			<Description>ResponseTimeInMs</Description>
			<DataType>int </DataType>
		</Column>
		<Column Name="StatusCode">
			<Description>StatusCode</Description>
			<DataType>int</DataType>
		</Column>
		<Column Name="RequestId">
			<Description>RequestId</Description>
			<DataType>varchar(100)</DataType>
		</Column>
		<Column Name="ApplicationName">
			<Description>ApplicationName</Description>
			<DataType>varchar(50)</DataType>
		</Column>
		<Column Name="Host">
			<Description>Host</Description>
			<DataType>varchar(100)</DataType>
		</Column>
		<Column Name="ErrorMessage">
			<Description>ErrorMessage</Description>
			<DataType>varchar(max)</DataType>
		</Column>
		<Column Name="OnBehalfOf">
			<Description>OnBehalfOf</Description>
			<DataType>varchar(100)</DataType>
		</Column>
	</Columns>
</Synonym>
***/
CREATE SYNONYM [Logging].[ServicesLegacy] FOR [Discovery].[dbo].[XMLServicesLog]
GO