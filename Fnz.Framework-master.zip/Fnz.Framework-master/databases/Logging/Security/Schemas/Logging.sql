/***
<Schema>
	<Description>Contains objects related to the logging</Description>
	<Service>Logging</Service>
	<Feature>Logging</Feature>
</Schema>
***/
CREATE SCHEMA [Logging] AUTHORIZATION [dbo]
GO
