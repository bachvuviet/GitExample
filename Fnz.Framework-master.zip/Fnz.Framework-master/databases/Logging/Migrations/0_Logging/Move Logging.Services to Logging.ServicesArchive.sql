IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'Logging')
BEGIN
    EXEC('CREATE SCHEMA Logging AUTHORIZATION dbo')
END

IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Logging' AND TABLE_NAME = 'ServicesArchive')
BEGIN
	CREATE TABLE [Logging].[Services2](
		[Id] [bigint] IDENTITY(1,1) NOT NULL,
		[LogTime] [datetime2](3) NOT NULL,
		[Request] [varchar](max) NULL,
		[Response] [varchar](max) NULL,
		[Url] [varchar](max) NULL,
		[UserId] [int] NULL,
		[ServiceName] [varchar](500) NULL,
		[OperationName] [varchar](100) NULL,
		[Method] [varchar](20) NULL,
		[ServiceReference] [varchar](100) NULL,
		[ResponseTimeInMs] [int] NULL,
		[StatusCode] [int] NULL,
		[RequestId] [varchar](100) NULL,
		[ApplicationName] [varchar](50) NULL,
		[Host] [varchar](100) NULL,
		[ErrorMessage] [varchar](max) NULL,
		[OnBehalfOf] [varchar](100) NULL,
		[ServerName] [varchar](30) NULL,
		[RequestHeaders] [varchar](max) NULL
	CONSTRAINT [PK_Services2] PRIMARY KEY CLUSTERED 
	(
		[Id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

	if exists (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Logging' AND TABLE_NAME = 'Services')
	begin
		declare @NewId bigint
		select @NewId = ISNULL(MAX(Id), 1) from [Logging].[Services]

		DBCC CHECKIDENT ('Logging.Services2', RESEED, @NewId);

		EXEC [SchemaMigration].[spRenameTable] @Schema = N'Logging', @OldTableName= N'Services', @NewTableName = N'ServicesArchive'
		EXEC [SchemaMigration].[spRenamePrimaryKey] @Schema = N'Logging', @Table= N'ServicesArchive', @NewPKName = N'PK_ServicesArchive'

		EXEC [SchemaMigration].[spRenameTable] @Schema = N'Logging', @OldTableName= N'Services2', @NewTableName = N'Services'
		EXEC [SchemaMigration].[spRenamePrimaryKey] @Schema = N'Logging', @Table= N'Services', @NewPKName = N'PK_Services'
	end
END