/***
<StoredProcedure>
    <Description>
		Insert a new row in Logging.Services log table. The reason this exists
		and should be used instead of an dal.UpdateRecordset() or prepared 
		statement is that these methods incur some minor overhead which can
		be roughly cut in half by using a Stored Procedure.
	</Description>
    <Service>Logging</Service>
    <Feature>Logging</Feature>
</StoredProcedure>
***/
CREATE PROCEDURE [Logging].[spInsertServicesLog] (@LogTime As datetime, @Request as varchar(max), @Response as varchar(max), @Url as varchar(max), @UserId as int, @ServiceName as varchar(500), @OperationName as varchar(100), @Method as varchar(20), @ServiceReference as varchar(100), @ResponseTimeInMs as int , @StatusCode as int, @RequestId as varchar(100), @ApplicationName as varchar(50), @Host as varchar(100), @ErrorMessage as varchar(max), @OnBehalfOf as varchar(100), @RequestHeaders as varchar(MAX), @ApiKey as varchar(128)) AS
BEGIN
	INSERT INTO [Logging].[Services]
	(LogTime,Request,Response,Url,UserId,ServiceName,OperationName,Method,ServiceReference,ResponseTimeInMs,StatusCode,RequestId,ApplicationName,Host,ErrorMessage,OnBehalfOf,RequestHeaders,ApiKey)
	VALUES (@LogTime,@Request,@Response,@Url,@UserId,@ServiceName,@OperationName,@Method,@ServiceReference,@ResponseTimeInMs,@StatusCode,@RequestId,@ApplicationName,@Host,@ErrorMessage,@OnBehalfOf,@RequestHeaders,@ApiKey)
END