/***
<StoredProcedure>
    <Description>
		Insert a new row in the XMLServicesLog. The reason this exists and
		should be used instead of an dal.UpdateRecordset() or prepared 
		statement is that these methods incur some minor overhead which can
		be roughly cut in half by using a Stored Procedure.
	</Description>
    <Service>Messaging</Service>
    <Feature>Messaging</Feature>
</StoredProcedure>
***/
CREATE PROCEDURE [Logging].[spInsertServicesLogLegacy] (@LogTime As datetime, @Request as varchar(max), @Response as varchar(max), @Url as varchar(max), @UserId as int, @ServiceName as varchar(500), @OperationName as varchar(100), @Method as varchar(20), @ServiceReference as varchar(100), @ResponseTimeInMs as int , @StatusCode as int, @RequestId as varchar(100), @ApplicationName as varchar(50), @Host as varchar(100), @ErrorMessage as varchar(max), @OnBehalfOf as varchar(100)) AS
BEGIN
	INSERT INTO [Logging].[ServicesLegacy]
	(LogTime,Request,Response,Url,UserId,ServiceName,OperationName,Method,ServiceReference,ResponseTimeInMs,StatusCode,RequestId,ApplicationName,Host,ErrorMessage,OnBehalfOf)
	VALUES (@LogTime,@Request,@Response,@Url,@UserId,@ServiceName,@OperationName,@Method,@ServiceReference,@ResponseTimeInMs,@StatusCode,@RequestId,@ApplicationName,@Host,@ErrorMessage,@OnBehalfOf)
END