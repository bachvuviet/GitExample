/***
<Table>
	<Description>ServicesArchive table - Archive table for Logging.Services</Description>
	<Service>All services</Service>
	<Feature>Archive table for Logging.Services</Feature>
	<TableType>Logging</TableType>
		<Columns>
		<Column Name="Id">
			<Description>The Id of the table</Description>
		</Column>
		<Column Name="LogTime">
			<Description>Date and time of request</Description>
		</Column>
		<Column Name="Request">
			<Description>The request</Description>
			<PrivacyLevel>Confidential</PrivacyLevel>
		</Column>
		<Column Name="Response">
			<Description>Response from call</Description>
			<PrivacyLevel>Confidential</PrivacyLevel>
		</Column>
		<Column Name="Url">
			<Description>Url request sent to</Description>
			<PrivacyLevel>Confidential</PrivacyLevel>
		</Column>
		<Column Name="UserId">
			<Description>User Id of who made call</Description>
		</Column>
		<Column Name="ServiceName">
			<Description>Name of service</Description>
			<PrivacyLevel>Confidential</PrivacyLevel>
		</Column>
		<Column Name="OperationName">
			<Description>Type of operation</Description>
		</Column>
		<Column Name="Method">
			<Description>HTTP Verb</Description>
		</Column>
		<Column Name="ServiceReference">
			<Description>The Service Reference</Description>
		</Column>
		<Column Name="ResponseTimeInMs">
			<Description>Response time in milliseconds</Description>
		</Column>
		<Column Name="StatusCode">
			<Description>HTTP status code</Description>
		</Column>
		<Column Name="RequestId">
			<Description>The Id of the request</Description>
		</Column>
		<Column Name="ApplicationName">
			<Description>The ApplicationName</Description>
			<PrivacyLevel>Confidential</PrivacyLevel>
		</Column>
		<Column Name="Host">
			<Description>The Host</Description>
			<PrivacyLevel>Confidential</PrivacyLevel>
		</Column>
		<Column Name="ErrorMessage">
			<Description>The Error message of failed request</Description>
			<PrivacyLevel>Confidential</PrivacyLevel>
		</Column>
		<Column Name="OnBehalfOf">
			<Description>The message OnBehalfOf</Description>
		</Column>
		<Column Name="ApiKey">
			<Description>The Api Key</Description>
		</Column>
	</Columns>
</Table>
***/
CREATE TABLE [Logging].[ServicesArchive]
(
	[Id] [int] NOT NULL IDENTITY(1, 1) CONSTRAINT [PK_ServicesArchive] PRIMARY KEY CLUSTERED,
	[LogTime] [datetime] NOT NULL,
	[Request] [varchar] (max) NULL,
	[Response] [varchar] (max) NULL,
	[Url] [varchar] (max) NULL,
	[UserId] [int] NULL,
	[ServiceName] [varchar] (500) NULL,
	[OperationName] [varchar] (100) NULL,
	[Method] [varchar] (20) NULL,
	[ServiceReference] [varchar] (100) NULL,
	[ResponseTimeInMs] [int] NULL,
	[StatusCode] [int] NULL,
	[RequestId] [varchar] (100) NULL,
	[ApplicationName] [varchar] (50) NULL,
	[Host] [varchar] (100) NULL,
	[ErrorMessage] [varchar](max) NULL,
	[OnBehalfOf] [varchar] (100) NULL,
	[RequestHeaders] [varchar] (max) NULL,
	[ApiKey] [varchar] (max) NULL
)
GO