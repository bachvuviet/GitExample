CREATE PROCEDURE [Messaging].[spGetRabbitQueues] @ActiveOnly AS BIT
AS
BEGIN
	IF @ActiveOnly = 1
	BEGIN
		SELECT
		H.RabbitHostId,
		H.Host,
		H.PublisherConfirms,
		H.VirtualHost,
		H.Username,
		H.Password,
		H.IsActive,
		MT.MessageType,
		Q.RabbitQueueId,
		Q.ShouldLog,
		Q.ShouldSubscribe,
		Q.SubscriberMaxThreadCount,
		Q.SingleSubscriptionOnly,
		Q.Topic,
		Q.SubscriptionId,
		PH.PropositionId,
		Q.[Priority],
		Q.PrefetchCount,
		NQ.QueueName,
		Q.ShouldSendAckMessage
		FROM Messaging.RabbitQueues Q
			INNER JOIN Messaging.RabbitMessageTypes MT ON MT.MessageTypeId = Q.MessageTypeId
			INNER JOIN Messaging.RabbitHosts H ON H.RabbitHostId = Q.RabbitHostId
			LEFT JOIN Messaging.RabbitPropositionHosts PH ON PH.RabbitHostId = H.RabbitHostId
			LEFT JOIN Messaging.RabbitNamedQueues NQ on NQ.RabbitNamedQueueId = Q.RabbitQueueId
		WHERE H.IsActive = 1
	END
	ELSE
	BEGIN
		SELECT
		H.RabbitHostId,
		H.Host,
		H.PublisherConfirms,
		H.VirtualHost,
		H.Username,
		H.Password,
		H.IsActive,
		MT.MessageType,
		Q.RabbitQueueId,
		Q.ShouldLog,
		Q.ShouldSubscribe,
		Q.SubscriberMaxThreadCount,
		Q.SingleSubscriptionOnly,
		Q.Topic,
		Q.SubscriptionId,
		PH.PropositionId,
		Q.[Priority],
		Q.PrefetchCount,
		NQ.QueueName,
		Q.ShouldSendAckMessage
		FROM Messaging.RabbitQueues Q
			INNER JOIN Messaging.RabbitMessageTypes MT ON MT.MessageTypeId = Q.MessageTypeId
			INNER JOIN Messaging.RabbitHosts H ON H.RabbitHostId = Q.RabbitHostId
			LEFT JOIN Messaging.RabbitPropositionHosts PH ON PH.RabbitHostId = H.RabbitHostId
			LEFT JOIN Messaging.RabbitNamedQueues NQ on NQ.RabbitNamedQueueId = Q.RabbitQueueId
	END
END
