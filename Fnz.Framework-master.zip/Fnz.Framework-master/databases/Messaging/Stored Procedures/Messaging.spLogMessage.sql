/***
<StoredProcedure>
    <Description>
		Insert a new row in the MessageLog. The reason this exists and
		should be used instead of an dal.UpdateRecordset() or prepared 
		statement is that these methods incur some minor overhead which can
		be roughly cut in half by using a Stored Procedure.
	</Description>
    <Service>Messaging</Service>
    <Feature>Messaging</Feature>
</StoredProcedure>
***/
CREATE PROCEDURE [Messaging].[spLogMessage] (@MessageAction as varchar(2), @MachineName as varchar(100), @MessageType as varchar(255), @Message as varchar(max), @PropositionId as int = null, @RoutingKey as varchar(50) = null, @ElapsedTimeInMs as int = null, @MessageCorrelationId as uniqueidentifier = null) AS
BEGIN
	INSERT INTO [Messaging].[MessageLog] ([MessageAction],[Host],[MessageType],[Message],[PropositionId],[RoutingKey],[ElapsedTimeInMs])
	VALUES (@MessageAction,@MachineName,@MessageType,@Message,@PropositionId,@RoutingKey,@ElapsedTimeInMs)

	If @MessageCorrelationId IS NOT NULL
	BEGIN
		INSERT INTO [Messaging].[MessageCorrelationIds] ([MessageLogId], [CorrelationId])
		SELECT Scope_Identity(), @MessageCorrelationId
	END
END