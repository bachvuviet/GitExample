/***
<StoredProcedure>
    <Description>Retrieve connectin details for given hub service</Description>
    <Service>Messaging</Service>
    <Feature>Messaging</Feature>
</StoredProcedure>
***/
CREATE PROCEDURE Messaging.spGetHubServiceConfiguration(@serviceName varchar(64))
AS
SELECT 
	XBS.MessageName As MessageName, 
	WS.Url As BaseUrl, 
	WS.RequestHeaderValue As UserContext, 
	XBS.ApplicationName As PropositionId,
	XBS.StubGateway as StubGateway
FROM [Messaging].[XMLBusinessService] XBS
	INNER JOIN [Messaging].[WebService] WS ON XBS.WebServiceName = WS.Name AND XBS.WebServiceEnvironment = WS.Environment
WHERE XBS.MessageName = @serviceName
GO