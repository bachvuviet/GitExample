CREATE PROCEDURE [Messaging].[spGetActiveRabbitNamedExchanges] AS

SELECT
	H.RabbitHostId,
	H.Host,
	H.PublisherConfirms,
	H.VirtualHost,
	H.Username,
	H.Password,
	H.IsActive,
	E.RabbitNamedExchangeId,
	E.ExchangeName,
	ET.ExchangeType,
	E.ShouldLog,
	PH.PropositionId
FROM Messaging.RabbitNamedExchanges E
	INNER JOIN Messaging.RabbitExchangeTypes ET on ET.ExchangeTypeId = E.RabbitExchangeTypeId
	INNER JOIN Messaging.RabbitHosts H ON H.RabbitHostId = E.RabbitHostId
	LEFT JOIN Messaging.RabbitPropositionHosts PH ON PH.RabbitHostId = H.RabbitHostId
WHERE H.IsActive = 1

GO