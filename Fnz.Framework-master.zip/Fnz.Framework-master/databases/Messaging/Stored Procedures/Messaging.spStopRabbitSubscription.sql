CREATE PROCEDURE [Messaging].[spStopRabbitSubscription] @RabbitQueueId AS smallint, @MachineHosted AS varchar(30)
AS
BEGIN
	DELETE FROM Messaging.RabbitSubscriptions
	WHERE RabbitQueueId = @RabbitQueueId AND MachineHosted = @MachineHosted
END