CREATE PROCEDURE [Messaging].[spGetAdditionalMessageTypesForActiveRabbitNamedQueues] AS

SELECT
	A.RabbitNamedQueueId,
	MT.MessageType

FROM Messaging.RabbitQueues Q
	INNER JOIN Messaging.RabbitNamedQueueAdditionalMessageTypes A ON A.RabbitNamedQueueId = Q.RabbitQueueId
	INNER JOIN Messaging.RabbitMessageTypes MT ON Mt.MessageTypeId = A.MessageTypeId
	INNER JOIN Messaging.RabbitHosts H ON H.RabbitHostId = Q.RabbitHostId
WHERE H.IsActive = 1

GO