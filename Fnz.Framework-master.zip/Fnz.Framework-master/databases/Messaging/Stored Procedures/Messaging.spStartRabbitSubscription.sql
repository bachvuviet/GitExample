/***
<StoredProcedure>
   <Description>
	This provides a record of the subscriptions made/attempted from a host.
	For a SingleSubscriptionOnly queue, this records the potential subscriber, not the single actual subscriber allowed to connect by the Rabbit server.
   </Description>
   <Parameters>
      <Parameter Name="@RabbitQueueId">
         <Description>The queue the subscription is for</Description>
      </Parameter>
      <Parameter Name="@MachineHosted">
         <Description>The MachineName of the box starting this subscription</Description>
      </Parameter>
   </Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE [Messaging].[spStartRabbitSubscription] @RabbitQueueId AS smallint, @MachineHosted AS varchar(30)
AS
BEGIN
	UPDATE Messaging.RabbitSubscriptions
	SET DateTimeStarted = SYSDATETIME()
	WHERE RabbitQueueId = @RabbitQueueId AND MachineHosted = @MachineHosted

	IF @@ROWCOUNT = 0
	BEGIN
		INSERT INTO Messaging.RabbitSubscriptions (RabbitQueueId, MachineHosted, DateTimeStarted)
		SELECT @RabbitQueueId, @MachineHosted, SYSDATETIME()
	END
END