CREATE PROCEDURE [Messaging].[spGetActiveRabbitNamedExchangeBindings] AS

SELECT
	B.RabbitNamedExchangeBindingId,
	B.RabbitNamedExchangeId,
	B.DestinationRabbitNamedExchangeId,
	B.DestinationRabbitNamedQueueId,
	B.RoutingKey
	
FROM Messaging.RabbitNamedExchangeBindings B
	INNER JOIN Messaging.RabbitNamedExchanges E on E.RabbitNamedExchangeId = B.RabbitNamedExchangeId
	INNER JOIN Messaging.RabbitHosts H ON H.RabbitHostId = E.RabbitHostId
WHERE H.IsActive = 1

GO