/***
<Table>
	<Description>Defines the message exchanges which do not follow the EasyNetQ naming or binding conventions</Description>
	<TableType>EnvironmentConfig</TableType>
	<Columns>
		<Column Name="RabbitNamedExchangeId">
			<Description>The unique identifier for the Exchange</Description>
		</Column>
		<Column Name="ExchangeName">
			<Description>The name of the Exchange</Description>
		</Column>
		<Column Name="RabbitHostId">
			<Description>The identifier of the host</Description>
		</Column>
		<Column Name="ShouldLog">
			<Description>Indicates if we should write any published messages to a logging table/file</Description>
		</Column>
		<Column Name="RabbitExchangeTypeId">
			<Description>The identifier of the type of the exchange.</Description>
		</Column>
	</Columns>
</Table>
***/
CREATE TABLE [Messaging].[RabbitNamedExchanges](
	[RabbitNamedExchangeId] smallint NOT NULL,
	[ExchangeName] varchar(149) NOT NULL,
	[RabbitHostId] tinyint NOT NULL,
	[ShouldLog] bit NOT NULL,
	[RabbitExchangeTypeId] tinyint NOT NULL
)
ALTER TABLE [Messaging].[RabbitNamedExchanges]
	ADD CONSTRAINT [PK_RabbitNamedExchanges]
	PRIMARY KEY CLUSTERED (RabbitNamedExchangeId)
GO
ALTER TABLE [Messaging].[RabbitNamedExchanges]
	ADD CONSTRAINT FK_RabbitQueues_RabbitExchangeTypes_RabbitExchangeTypeId
	FOREIGN KEY (RabbitExchangeTypeId)
	REFERENCES [Messaging].RabbitExchangeTypes(ExchangeTypeId)
GO
ALTER TABLE [Messaging].[RabbitNamedExchanges]
	ADD CONSTRAINT FK_RabbitNamedExchanges_RabbitHosts_RabbitHostId
	FOREIGN KEY (RabbitHostId)
	REFERENCES [Messaging].RabbitHosts(RabbitHostId)
GO
CREATE UNIQUE NONCLUSTERED INDEX [UIDX_ExchangeNameRabbitHostId] 
  ON [Messaging].[RabbitNamedExchanges](ExchangeName, RabbitHostId)
GO
