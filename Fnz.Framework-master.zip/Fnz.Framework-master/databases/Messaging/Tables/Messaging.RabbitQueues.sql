/***
<Table>
	<Description>Defines all the messaging queues and the host each belongs to</Description>
	<TableType>EnvironmentConfig</TableType>
	<Columns>
		<Column Name="RabbitQueueId">
			<Description>The unique identifier for the Queue</Description>
		</Column>
		<Column Name="MessageTypeId">
			<Description>The identifier of the Message Type</Description>
		</Column>
		<Column Name="RabbitHostId">
			<Description>The identifier of the host</Description>
		</Column>
		<Column Name="ShouldLog">
			<Description>Indicates if we should write the message to a logging table/file</Description>
		</Column>
		<Column Name="ShouldSendAckMessage">
			<Description>Indicates if we should send ack event message</Description>
		</Column>
		<Column Name="ShouldSubscribe">
			<Description>Indicates if we should subscribe to this message type on the given rabbit host</Description>
		</Column>
		<Column Name="SingleSubscriptionOnly">
			<Description>Indicates if only a single messaging host can subscribe to this rabbit queue</Description>
		</Column>
		<Column Name="SubscriberMaxThreadCount">
			<Description>The number of concurrent threads that can deal with messages from this queue. Null or 1 indicates that we are using the IBus.Subscribe. More than one indicates we are using IBus.SubscribeAsync</Description>
		</Column>
		<Column Name="Topic">
			<Description>Indicates if the subscription for this queue should be also based on an optional topic</Description>
		</Column>
		<Column Name="SubscriptionId">
			<Description>Indicates if the subscription for this queue should be based on a preset subscriptionId or one will be generated</Description>
		</Column>
		<Column Name="Priority">
			<Description>
				The priority messages are published to the queue with. Larger number indicates higher priority, while messages, default priority is 0.
				Priority queue is queue with priority higher than 0. Max. supported priority is 5.
			</Description>
		</Column>
		<Column Name="PrefetchCount">
			<Description>Maximum number of messages to be pre-fetched. Default value in EasyNetQ is 50</Description>
		</Column>
	</Columns>
</Table>
***/
CREATE TABLE [Messaging].[RabbitQueues](
	[RabbitQueueId] smallint NOT NULL,
	[MessageTypeId] smallint NOT NULL, 
	[RabbitHostId] tinyint NOT NULL,
	[ShouldLog] bit NOT NULL,
	[ShouldSendAckMessage] bit NOT NULL  CONSTRAINT DF_RabbitQueues_ShouldSendAckMessage DEFAULT (0),
	[ShouldSubscribe] bit NOT NULL CONSTRAINT DF_RabbitQueues_ShouldSubscribe DEFAULT (1),
	[SingleSubscriptionOnly] bit NOT NULL CONSTRAINT DF_RabbitQueues_SingleSubscriptionOnly DEFAULT (0),
	[SubscriberMaxThreadCount] tinyint NULL CONSTRAINT DF_RabbitQueues_SubscriberMaxThreadCount DEFAULT (1),
	[Topic] varchar(20) NULL,
	[SubscriptionId] varchar(20) NULL,
	[Priority] tinyint NOT NULL CONSTRAINT DF_RabbitQueues_Priority DEFAULT (0),
	[PrefetchCount] tinyint NOT NULL CONSTRAINT [DF_RabbitQueues_PrefetchCount] DEFAULT (50)
)
ALTER TABLE [Messaging].[RabbitQueues]
	ADD CONSTRAINT [PK_RabbitQueues]
	PRIMARY KEY CLUSTERED (RabbitQueueId)
GO
ALTER TABLE [Messaging].[RabbitQueues]
	ADD CONSTRAINT FK_RabbitQueues_RabbitMessageTypes_MessageTypeId
	FOREIGN KEY (MessageTypeId)
	REFERENCES [Messaging].RabbitMessageTypes(MessageTypeId)
GO
ALTER TABLE [Messaging].[RabbitQueues]
	ADD CONSTRAINT FK_RabbitQueues_RabbitHosts_RabbitHostId
	FOREIGN KEY (RabbitHostId)
	REFERENCES [Messaging].RabbitHosts(RabbitHostId)
GO
ALTER TABLE [Messaging].[RabbitQueues]
	ADD CONSTRAINT [UQ_RabbitQueues_MessageTypeId_RabbitHostId]
	UNIQUE (MessageTypeId, RabbitHostId)
GO
ALTER TABLE [Messaging].[RabbitQueues] 
	ADD CONSTRAINT [Chk_RabbitQueues_PriorityIsValid] CHECK ([Priority] BETWEEN 0 AND 5)
GO
