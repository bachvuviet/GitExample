/***
<Table>
  <Description>Logs the publishing and receiving of messages</Description>
  <TableType>Logging</TableType>
  <Columns>
    <Column Name="MessageLogId">
      <Description>The id of the log entry</Description>
      <Service />
      <Feature />
      <PrivacyLevel>Unrestricted</PrivacyLevel>
    </Column>
    <Column Name="DateTimeLogged">
      <Description>The date and time the message has been published/received</Description>
      <Service />
      <Feature />
      <PrivacyLevel>Unrestricted</PrivacyLevel>
    </Column>
    <Column Name="MessageType">
      <Description>The class name of the message that was published/received</Description>
      <Service />
      <Feature />
      <PrivacyLevel>Unrestricted</PrivacyLevel>
    </Column>
    <Column Name="MessageAction">
      <Description>P for Published a message, R for Received a message, S for subscribing to a message type, RA for Received and Acknowledged a message</Description>
      <Service />
      <Feature />
      <PrivacyLevel>Unrestricted</PrivacyLevel>
    </Column>
    <Column Name="Host">
      <Description>The machine that the the message was published/received in</Description>
      <Service />
      <Feature />
      <PrivacyLevel>Unrestricted</PrivacyLevel>
    </Column>
    <Column Name="Message">
      <Description>The content of the message that was published/received </Description>
      <Service />
      <Feature />
      <PrivacyLevel>Confidential</PrivacyLevel>
    </Column>
    <Column Name="RoutingKey">
      <Description>The RabbitMQ routing key of the message</Description>
      <Service />
      <Feature />
      <PrivacyLevel>Unrestricted</PrivacyLevel>
    </Column>
    <Column Name="ElapsedTimeInMs"> 
       <Description>The time (in milliseconds) it took to perform the publish (only used for Publish in order to time how long publishes are taking)</Description> 
    </Column> 
  </Columns>
  <FunctionalStream />
</Table>
***/
CREATE TABLE [Messaging].[MessageLog]
(
	[MessageLogId] [int] NOT NULL IDENTITY(1, 1) NOT FOR REPLICATION, 
	[DateTimeLogged] DateTime NOT NULL DEFAULT (getdate()),
	[MessageType] varchar(255) NOT NULL,
	[MessageAction] varchar(2) NOT NULL,
	[Host] varchar(100) NOT NULL,
	[Message] varchar(max) NULL,
	[PropositionId] int NULL,	
	[RoutingKey] varchar(50) NULL,	
	[ElapsedTimeInMs] [int] NULL
)
GO
ALTER TABLE [Messaging].[MessageLog]
	ADD CONSTRAINT [PK_MessageLog]
	PRIMARY KEY CLUSTERED (MessageLogId)
GO