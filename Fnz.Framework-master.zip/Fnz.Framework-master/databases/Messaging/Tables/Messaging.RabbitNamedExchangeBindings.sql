/***
<Table>
	<Description>
		Defines the bindings for exchanges which do not follow the EasyNetQ naming or binding conventions.
		An RabbitMQ exchange can be bound to either another exchange or a queue, so one of the destination columns needs to be populated.
	</Description>
	<TableType>EnvironmentConfig</TableType>
	<Columns>
		<Column Name="RabbitNamedExchangeBindingId">
			<Description>The unique identifier for the exchange binding</Description>
		</Column>
		<Column Name="RabbitNamedExchangeId">
			<Description>The unique identifier for the Exchange being bound</Description>
		</Column>
		<Column Name="DestinationRabbitNamedExchangeId">
			<Description>The identifier of the destination exchange</Description>
		</Column>
		<Column Name="DestinationRabbitNamedQueueId">
			<Description>The identifier of the destination queue</Description>
		</Column>
		<Column Name="RoutingKey">
			<Description>The routing key to apply to the binding</Description>
		</Column>
	</Columns>
</Table>
***/
CREATE TABLE [Messaging].[RabbitNamedExchangeBindings](
	[RabbitNamedExchangeBindingId] smallint NOT NULL,
	[RabbitNamedExchangeId] smallint NOT NULL,
	[DestinationRabbitNamedExchangeId] smallint NULL,
	[DestinationRabbitNamedQueueId] smallint NULL,
	[RoutingKey] varchar(150) NULL
)
ALTER TABLE [Messaging].[RabbitNamedExchangeBindings]
	ADD CONSTRAINT [PK_RabbitNamedExchangeBindings]
	PRIMARY KEY CLUSTERED (RabbitNamedExchangeBindingId)
GO
ALTER TABLE [Messaging].[RabbitNamedExchangeBindings]
	ADD CONSTRAINT FK_RabbitNamedExchangeBindings_RabbitNamedExchanges_RabbitNamedExchangeId
	FOREIGN KEY (RabbitNamedExchangeId)
	REFERENCES [Messaging].RabbitNamedExchanges(RabbitNamedExchangeId)
GO
ALTER TABLE [Messaging].[RabbitNamedExchangeBindings]
	ADD CONSTRAINT FK_RabbitNamedExchangeBindings_RabbitNamedExchanges_DestinationRabbitNamedExchangeId
	FOREIGN KEY (DestinationRabbitNamedExchangeId)
	REFERENCES [Messaging].RabbitNamedExchanges(RabbitNamedExchangeId)
GO
ALTER TABLE [Messaging].[RabbitNamedExchangeBindings]
	ADD CONSTRAINT FK_RabbitNamedExchangeBindings_RabbitNamedQueues_DestinationRabbitNamedQueueId
	FOREIGN KEY (DestinationRabbitNamedQueueId)
	REFERENCES [Messaging].RabbitNamedQueues(RabbitNamedQueueId)
GO
ALTER TABLE [Messaging].[RabbitNamedExchangeBindings]
	ADD CONSTRAINT [UQ_RabbitNamedExchangeBindings_RabbitNamedExchangeId_DestinationRabbitNamedExchangeId_DestinationRabbitNamedQueueId]
	UNIQUE (RabbitNamedExchangeId, DestinationRabbitNamedExchangeId, DestinationRabbitNamedQueueId)
GO
ALTER TABLE [Messaging].[RabbitNamedExchangeBindings] 
	ADD CONSTRAINT [Chk_RabbitNamedExchangeBindings_DestinationIsValid] CHECK 
	(([DestinationRabbitNamedExchangeId] IS NOT NULL AND [DestinationRabbitNamedQueueId] IS NULL)
	OR
	([DestinationRabbitNamedExchangeId] IS NULL AND [DestinationRabbitNamedQueueId] IS NOT NULL))
GO
