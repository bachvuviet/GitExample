/***
<Table>
	<Description>Stores details of queues that only have specific hosts allowed to subscribe to them</Description>
	<TableType>Transaction</TableType>
	<Columns>
		<Column Name="RabbitQueueId">
			<Description>The unique identifier for the Queue</Description>
		</Column>
		<Column Name="MachineName">
			<Description>The name of the machine that is allowed to subscribe to this queue (or attempt to in the case of single/exclusive consumers)</Description>
		</Column>
	</Columns>
</Table>
***/
CREATE TABLE [Messaging].[RabbitSpecificSubscriptions](
	[RabbitQueueId] smallint NOT NULL,
	[MachineName] varchar(100) NOT NULL
)
ALTER TABLE [Messaging].[RabbitSpecificSubscriptions]
	ADD CONSTRAINT [PK_RabbitSpecificSubscriptions]
	PRIMARY KEY CLUSTERED (RabbitQueueId, MachineName)
GO
ALTER TABLE [Messaging].[RabbitSpecificSubscriptions]
	ADD CONSTRAINT FK_RabbitSpecificSubscriptions_RabbitQueues_RabbitQueueId
	FOREIGN KEY (RabbitQueueId)
	REFERENCES [Messaging].RabbitQueues(RabbitQueueId)
GO