/***
<Table>
	<Description>Defines the message queues which do not follow the EasyNetQ naming or binding conventions</Description>
	<TableType>EnvironmentConfig</TableType>
	<Columns>
		<Column Name="RabbitNamedQueueId">
			<Description>The unique identifier for the Queue</Description>
		</Column>
		<Column Name="QueueName">
			<Description>The name of the rabbit queue</Description>
		</Column>
	</Columns>
</Table>
***/
CREATE TABLE [Messaging].[RabbitNamedQueues](
	[RabbitNamedQueueId] smallint NOT NULL,
	[QueueName] varchar(150) NOT NULL
)
ALTER TABLE [Messaging].[RabbitNamedQueues]
	ADD CONSTRAINT [PK_RabbitNamedQueues]
	PRIMARY KEY CLUSTERED (RabbitNamedQueueId)
GO
ALTER TABLE [Messaging].[RabbitNamedQueues]
	ADD CONSTRAINT FK_RabbitNamedQueues_RabbitQueues_RabbitQueueId
	FOREIGN KEY (RabbitNamedQueueId)
	REFERENCES [Messaging].RabbitQueues(RabbitQueueId)
GO

