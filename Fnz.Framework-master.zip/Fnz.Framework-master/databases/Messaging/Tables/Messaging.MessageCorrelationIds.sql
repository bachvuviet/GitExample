/***
<Table>
  <Description>Logs any message correlation for a message log entry. This ties together the message publisher and consumer.</Description>
  <TableType>Logging</TableType>
  <Columns>
    <Column Name="MessageLogId">
      <Description>The id of the message log entry</Description>
      <PrivacyLevel>Unrestricted</PrivacyLevel>
    </Column>
    <Column Name="CorrelationId"> 
      <Description>The message correlationId for the message log entry</Description> 
      <PrivacyLevel>Unrestricted</PrivacyLevel>
    </Column> 
  </Columns>
</Table>
***/
CREATE TABLE [Messaging].[MessageCorrelationIds]
(
	[MessageLogId] [int] NOT NULL, 
	[CorrelationId] [uniqueidentifier] NOT NULL
)
GO

ALTER TABLE [Messaging].[MessageCorrelationIds]
	ADD CONSTRAINT [PK_MessageCorrelationIds]
	PRIMARY KEY CLUSTERED (MessageLogId)
GO

ALTER TABLE [Messaging].[MessageCorrelationIds]
	ADD CONSTRAINT [FK_MessageLog_MessageLogId]
	FOREIGN KEY (MessageLogId) REFERENCES [Messaging].[MessageLog]([MessageLogId])
GO

CREATE NONCLUSTERED INDEX IDX_CorrelationId ON [Messaging].[MessageCorrelationIds]([CorrelationId])

GO