/***
<Table>
  <Description>Defines any additional message types that will be received via a RabbitNamedQueue</Description>
  <TableType>EnvironmentConfig</TableType>
  <Columns>
    <Column Name="RabbitNamedQueueId">
      <Description>The unique identifier for the named queue</Description>
    </Column>
    <Column Name="MessageTypeId">
      <Description>The unique identifier for the message type</Description>
    </Column>
  </Columns>
</Table>
***/
CREATE TABLE [Messaging].[RabbitNamedQueueAdditionalMessageTypes](
	[RabbitNamedQueueId] smallint NOT NULL,
	[MessageTypeId] smallint NOT NULL
)
ALTER TABLE [Messaging].[RabbitNamedQueueAdditionalMessageTypes]
	ADD CONSTRAINT [PK_RabbitNamedQueueAdditionalMessageTypes]
	PRIMARY KEY CLUSTERED (RabbitNamedQueueId, MessageTypeId)
GO
ALTER TABLE [Messaging].[RabbitNamedQueueAdditionalMessageTypes]
	ADD CONSTRAINT FK_RabbitNamedQueueAdditionalMessageTypes_RabbitNamedQueues_RabbitNamedQueueId
	FOREIGN KEY (RabbitNamedQueueId)
	REFERENCES [Messaging].RabbitNamedQueues(RabbitNamedQueueId)
GO
ALTER TABLE [Messaging].[RabbitNamedQueueAdditionalMessageTypes]
	ADD CONSTRAINT FK_RabbitNamedQueueAdditionalMessageTypes_RabbitMessageTypes_MessageTypeId
	FOREIGN KEY (MessageTypeId)
	REFERENCES [Messaging].RabbitMessageTypes(MessageTypeId)
GO