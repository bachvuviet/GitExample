/***
<Table>
  <Description>Contains the messages that are to be published to the messaging bus (RabbitMQ). 
     This table is written to in the same DB transaction as other data is being updated so we can ensure that messaging publishing 
	 (for integration events) are published after other data has been saved in the database.
  </Description>
  <TableType>Transaction</TableType>
  <Columns>
    <Column Name="OutboxId">
      <Description>The id of the outbox entry</Description>
    </Column>
    <Column Name="CreationDateTime">
      <Description>The date and time the entry was created</Description>
    </Column>
    <Column Name="MessageTypeAssemblyName">
      <Description>The assembly name of the message that is to be published</Description>
    </Column>
	<Column Name="MessageType">
      <Description>The class name of the message that is to be published</Description>
    </Column>
    <Column Name="Message">
      <Description>The content of the message that is to be published (JSON)</Description>
	  <PrivacyLevel>Confidential</PrivacyLevel>
    </Column>
	<Column Name="ContextGuid">
      <Description>The unique Id of the context where the message is to be published from (optional). Similar to a batchID. Allows us to identify where a group of messages were published from</Description>
    </Column>
	<Column Name="PropositionId">
      <Description>The Id of the platform that is publishing the message (optional)</Description>
    </Column>
    <Column Name="RoutingKey">
      <Description>The RabbitMQ routing key of the message (optional)</Description>
    </Column>
	<Column Name="OnHold"> 
       <Description>True if an attempt was made to publish the message but it failed 3 times. If this is set to False the message will not be published</Description> 
    </Column> 
    <Column Name="RetriesRemaining"> 
       <Description>If the publish failed this is the last time it was attempted</Description> 
    </Column> 
	<Column Name="LastAttempt"> 
       <Description>If the publish failed this is the last time it was attempted</Description> 
    </Column> 
	<Column Name="FailureMessage"> 
	   <PrivacyLevel>Confidential</PrivacyLevel>
       <Description>The last error message if the message failed to be publish</Description> 
    </Column> 
  </Columns>
</Table>
***/
CREATE TABLE [Messaging].[Outbox]
(
	[OutboxId] BIGINT NOT NULL IDENTITY(1, 1), 
	[CreationDateTime] DATETIME2(3) NOT NULL DEFAULT (getdate()),
	[MessageTypeAssemblyName] varchar(100) NOT NULL,
	[MessageType] varchar(255) NOT NULL,
	[Message] nvarchar(max) NOT NULL,
	[ContextGuid] uniqueidentifier NULL,
	[PropositionId] int NULL,	
	[RoutingKey] varchar(50) NULL,
	[OnHold] bit NOT NULL DEFAULT (0),
	[AttemptCount] int NOT NULL DEFAULT (0),
	[RetriesRemaining] int NOT NULL DEFAULT (3),
	[LastAttempt] DATETIME2(3) NULL, 
	[FailureMessage] varchar(500) NULL
)
GO
ALTER TABLE [Messaging].[Outbox]
	ADD CONSTRAINT [PK_Outbox]
	PRIMARY KEY CLUSTERED (OutboxId)
GO

CREATE NONCLUSTERED INDEX IDX_ContextGuid ON Messaging.Outbox(ContextGuid)
GO

CREATE NONCLUSTERED INDEX IDX_OnHold ON Messaging.Outbox(OnHold)
GO
