/***
<Table>
	<Description>Defines all the proposition specific RabbitMQ queues</Description>
	<TableType>EnvironmentConfig</TableType>
	<Columns>
		<Column Name="RabbitHostId">
			<Description>The unique identifier for the Host</Description>
		</Column>
		<Column Name="PropositionId">
			<Description>The Proposition identifier. Used to name the IBus in castle</Description>
		</Column>		
	</Columns>
</Table>
***/
CREATE TABLE [Messaging].[RabbitPropositionHosts](
	[RabbitHostId] tinyint NOT NULL,
	[PropositionId] smallint NOT NULL	
)
ALTER TABLE [Messaging].[RabbitPropositionHosts]
	ADD CONSTRAINT [PK_RabbitPropositionHosts]
	PRIMARY KEY CLUSTERED (RabbitHostId)
GO
ALTER TABLE [Messaging].[RabbitPropositionHosts]
	ADD CONSTRAINT FK_RabbitPropositionHosts_RabbitHostId
	FOREIGN KEY (RabbitHostId)
	REFERENCES [Messaging].RabbitHosts(RabbitHostId)
GO
ALTER TABLE [Messaging].[RabbitPropositionHosts]
	ADD CONSTRAINT [UQ_RabbitPropositionHosts_PropositionId]
	UNIQUE (PropositionId)
GO