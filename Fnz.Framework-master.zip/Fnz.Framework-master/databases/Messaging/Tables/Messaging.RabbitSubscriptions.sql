/***
<Table>
	<Description>Stores the number of subscriptions each queue has</Description>
	<TableType>Transaction</TableType>
	<Columns>
		<Column Name="RabbitQueueId">
			<Description>The unique identifier for the Queue</Description>
		</Column>
		<Column Name="MachineHosted">
			<Description>The name of the machine that is hosting this queue</Description>
		</Column>
		<Column Name="DateTimeStarted">
			<Description>The datetime the machine started to subscribe to the queue</Description>
		</Column>
	</Columns>
</Table>
***/
CREATE TABLE [Messaging].[RabbitSubscriptions](
	[RabbitQueueId] smallint NOT NULL,
	[MachineHosted] varchar(100) NOT NULL,
	[DateTimeStarted] datetime2(3) NOT NULL CONSTRAINT [DF_RabbitSubscriptions_DateTimeStarted] DEFAULT (SYSDATETIME())
)
ALTER TABLE [Messaging].[RabbitSubscriptions]
	ADD CONSTRAINT [PK_RabbitSubscriptions]
	PRIMARY KEY CLUSTERED (RabbitQueueId, MachineHosted)
GO
ALTER TABLE [Messaging].[RabbitSubscriptions]
	ADD CONSTRAINT FK_RabbitSubscriptions_RabbitQueues_RabbitQueueId
	FOREIGN KEY (RabbitQueueId)
	REFERENCES [Messaging].RabbitQueues(RabbitQueueId)
GO