/***
<Table>
  <Description>Defines all the exchange types used with the RabbitNamedExchanges</Description>
  <TableType>SystemSetting</TableType>
  <Columns>
    <Column Name="ExchangeTypeId">
      <Description>The unique identifier for the exchange type</Description>
      <PrivacyLevel>Unrestricted</PrivacyLevel>
    </Column>
    <Column Name="ExchangeType">
      <Description>The RabbitMQ exchange type</Description>
      <PrivacyLevel>Unrestricted</PrivacyLevel>
    </Column>
  </Columns>
</Table>
***/
CREATE TABLE [Messaging].[RabbitExchangeTypes](
	[ExchangeTypeId] tinyint NOT NULL,
	[ExchangeType] varchar(150) NOT NULL
)
ALTER TABLE [Messaging].[RabbitExchangeTypes]
	ADD CONSTRAINT [PK_RabbitExchangeTypes]
	PRIMARY KEY CLUSTERED (ExchangeTypeId)
GO
ALTER TABLE [Messaging].[RabbitExchangeTypes]
	ADD CONSTRAINT [UQ_RabbitExchangeTypes_ExchangeType]
	UNIQUE (ExchangeType)
GO