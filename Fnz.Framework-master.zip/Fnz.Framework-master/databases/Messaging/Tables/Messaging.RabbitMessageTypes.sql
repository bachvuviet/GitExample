/***
<Table>
  <Description>Defines all the messaging types that will be passed to or from RabbitMQ</Description>
  <TableType>SystemSetting</TableType>
  <Columns>
    <Column Name="MessageTypeId">
      <Description>The unique identifier for the Message Type</Description>
      <Service />
      <Feature />
      <PrivacyLevel>Unrestricted</PrivacyLevel>
    </Column>
    <Column Name="MessageType">
      <Description>The Message Type</Description>
      <Service />
      <Feature />
      <PrivacyLevel>Unrestricted</PrivacyLevel>
    </Column>
  </Columns>
  <FunctionalStream />
</Table>
***/
CREATE TABLE [Messaging].[RabbitMessageTypes](
	[MessageTypeId] smallint NOT NULL,
	[MessageType] varchar(150) NOT NULL
)
ALTER TABLE [Messaging].[RabbitMessageTypes]
	ADD CONSTRAINT [PK_RabbitMessageTypes]
	PRIMARY KEY CLUSTERED (MessageTypeId)
GO
ALTER TABLE [Messaging].[RabbitMessageTypes]
	ADD CONSTRAINT [UQ_RabbitMessageTypes_MessageType]
	UNIQUE (MessageType)
GO