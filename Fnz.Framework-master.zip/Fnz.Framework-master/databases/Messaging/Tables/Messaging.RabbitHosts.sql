/***
<Table>
	<Description>Defines all the messaging hosts including any virtual hosts that will need to be registered for a product</Description>
	<TableType>EnvironmentConfig</TableType>
	<Columns>
		<Column Name="RabbitHostId">
			<Description>The unique identifier for the host</Description>
		</Column>
		<Column Name="Host">
			<PrivacyLevel>Confidential</PrivacyLevel>
			<Description>The server where the RabbitMQ is hosted</Description>
		</Column>
		<Column Name="PublisherConfirms">
			<Description>Indicates if the publishes from this messaging host uses publisher confirms or not</Description>
		</Column>
		<Column Name="VirtualHost">
			<PrivacyLevel>Confidential</PrivacyLevel>
			<Description>The virtual host that is used by the platform</Description>
		</Column>
		<Column Name="Username">
			<PrivacyLevel>Confidential</PrivacyLevel>
			<Description>The username used by the virtual host</Description>
		</Column>
		<Column Name="Password">
			<PrivacyLevel>Confidential</PrivacyLevel>
			<Description>The password used by the virtual host</Description>
		</Column>
		<Column Name="IsActive">
			<Description>Indicates if the host is active and to be used or not</Description>
		</Column>
		<Column Name="ConnectOnStartUp">
			<Description>Whether to connect (for publishing) on app startup, rather than first message. Should be set for the environment virtual host.</Description>
		</Column>
	</Columns>
</Table>
***/
CREATE TABLE [Messaging].[RabbitHosts]
(
	[RabbitHostId] tinyint NOT NULL,	
	[Host] varchar(50) NOT NULL,
	[PublisherConfirms] bit NOT NULL,
	[VirtualHost] varchar(30) NOT NULL,
	[Username] varchar(30) NOT NULL,
	[Password] varchar(30) NOT NULL,
	[IsActive] bit NOT NULL,
	[ConnectOnStartUp] bit NOT NULL CONSTRAINT [DF_RabbitHosts_ConnectOnStartup] DEFAULT (1)
)
ALTER TABLE [Messaging].[RabbitHosts]
	ADD CONSTRAINT [PK_RabbitHosts]
	PRIMARY KEY CLUSTERED (RabbitHostId)
GO
ALTER TABLE [Messaging].[RabbitHosts]
	ADD CONSTRAINT [UQ_RabbitHosts_Host_VirtualHost]
	UNIQUE (RabbitHostId, Host, VirtualHost)
GO
