/***
<Synonym>
	<Description>Maps subaccounts to their head accounts</Description>
	<Columns>
		<Column Name="ApplicationName">
			<Description>Name of Application</Description>
			<DataType>VarChar(20)</DataType>
		</Column>
		<Column Name="StubGateway">
			<Description>Stub Gateway</Description>
			<DataType>smallint</DataType>
		</Column>
		<Column Name="WebServiceName">
			<Description>Name of Web Service</Description>
			<DataType>VarChar(30)</DataType>
		</Column>
		<Column Name="WebServiceEnvironment">
			<Description>The Web Service environment</Description>
			<DataType>VarChar(30)</DataType>
		</Column>
		<Column Name="MessageName">
			<Description>Name of Message</Description>
			<DataType>VarChar(64)</DataType>
		</Column>
	</Columns>
</Synonym>
***/
CREATE SYNONYM [Messaging].[XMLBusinessService] FOR [Discovery].[dbo].[XMLBusinessService]
GO