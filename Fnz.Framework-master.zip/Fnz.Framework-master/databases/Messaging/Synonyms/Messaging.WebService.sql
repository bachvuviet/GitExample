/***
<Synonym>
	<Description>Maps subaccounts to their head accounts</Description>
	<Columns>
		<Column Name="Url">
			<Description>Uniform Resource Locator</Description>
			<DataType>VarChar(20)</DataType>
		</Column>
		<Column Name="RequestHeaderValue">
			<Description>Header value of request</Description>
			<DataType>smallint</DataType>
		</Column>
		<Column Name="Name">
			<Description>Name of Web Service</Description>
			<DataType>VarChar(30)</DataType>
		</Column>
		<Column Name="Environment">
			<Description>The Web Service environment</Description>
			<DataType>VarChar(30)</DataType>
		</Column>
	</Columns>
</Synonym>
***/
CREATE SYNONYM [Messaging].[WebService] FOR [Discovery].[dbo].[WebService]
GO