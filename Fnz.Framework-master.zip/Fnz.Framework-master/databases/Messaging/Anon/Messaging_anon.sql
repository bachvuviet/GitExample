UPDATE Messaging.RabbitHosts
SET Host = '', VirtualHost = '', Username = '', Password = ''
WHERE 1=1

DELETE FROM Messaging.Outbox

DECLARE @DropFK NVARCHAR(MAX)
SELECT @DropFK = 'ALTER TABLE Messaging.MessageCorrelationIds DROP CONSTRAINT ' + fk.name
FROM sys.foreign_keys fk
	INNER JOIN sys.objects po ON po.object_id = fk.parent_object_id
	INNER JOIN sys.objects ro ON ro.object_id = fk.referenced_object_id
WHERE po.name = 'MessageCorrelationIds'
	AND ro.name = 'MessageLog' IF @DropFK IS NOT NULL
BEGIN
	EXEC(@DropFK)
END

TRUNCATE TABLE Messaging.MessageCorrelationIds
TRUNCATE TABLE Messaging.MessageLog

ALTER TABLE [Messaging].[MessageCorrelationIds]
	ADD CONSTRAINT [FK_MessageLog_MessageLogId]
	FOREIGN KEY (MessageLogId) REFERENCES [Messaging].[MessageLog]([MessageLogId])