/***
<Schema>
	<Description>Contains objects for the RabbitMQ service</Description>
	<Service>Messaging</Service>
	<Feature>Messaging</Feature>
</Schema>
***/
CREATE SCHEMA [Messaging] AUTHORIZATION [dbo]
GO
