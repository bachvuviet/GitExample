/***
<Synonym>
	<Description>Contains the user session ifnormation which Saml uses for logon or off </Description>
	<Service>Users</Service>
	<Feature>Saml</Feature>
	<Columns>
		<Column Name="ClientID">
			<Description>ID of the person logging in</Description>
			<DataType>int</DataType>
		</Column>
		<Column Name="WebSessionID">
			<Description>The ID of the session in the browser</Description>
			<DataType>uniqueidentifier</DataType>
		</Column>
		<Column Name="LastLogonDate">
			<Description>The last time this user logged on</Description>
			<DataType>datetime</DataType>
		</Column>
		<Column Name="LogonExpires">
			<Description>When the logon will be terminated</Description>
			<DataType>datetime</DataType>
		</Column>
		<Column Name="SessionExpires">
			<Description>When the session will be terminated if the user is idle</Description>
			<DataType>datetime</DataType>
		</Column>
	</Columns>
</Synonym>
***/
CREATE SYNONYM [Saml].[UserSession] FOR [ClientDB3].[dbo].[TblClients]
GO
