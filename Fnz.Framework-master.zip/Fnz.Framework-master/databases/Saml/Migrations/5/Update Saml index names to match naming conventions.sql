

EXEC SchemaMigration.spRenameIndex @Schema = N'Saml', @Table = N'Configurations', @OldIndexName = N'idx_ConfigurationKey', @NewIndexName = N'UIDX_ConfigurationKey'
