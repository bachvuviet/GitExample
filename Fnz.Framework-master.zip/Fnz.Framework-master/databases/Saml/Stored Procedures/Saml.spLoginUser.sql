/***
<StoredProcedure>
    <Description>Updates the table that indicates that the specified user is logged on and sets the logon/session expiry dates</Description>
	<Service>Users</Service>
	<Feature>Saml</Feature>
    <Parameters>
        <Parameter Name="@UserId">
            <Description>The ID of the user who is logging on</Description>
        </Parameter>
        <Parameter Name="@WebSessionId">
            <Description>The web sesssion ID of the user who is logging on</Description>
        </Parameter>
    </Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE [Saml].[spLoginUser]
(
	@UserId INT,
    @WebSessionId uniqueidentifier
)
AS
	UPDATE [Saml].[UserSession]
	SET WebSessionID = @WebSessionID, 
	    LastLogonDate = GetDate(), 
	    LogonExpires = DATEADD(hour,18,GetDate()),  
	    SessionExpires = DATEADD(minute,1,GetDate()) -- only need enough time to land on the next page
	WHERE ClientID = @UserId

GO