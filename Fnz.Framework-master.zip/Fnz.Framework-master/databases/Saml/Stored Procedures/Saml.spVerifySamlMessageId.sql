/***
<StoredProcedure>
    <Description>Ringfences given amount of scrip for given client as specified by the parameters. Returns ID of the ringfencing if successful or 0 of not.</Description>
	<Service>Users</Service>
	<Feature>Saml</Feature>
    <Parameters>
        <Parameter Name="@ConfigurationId">
            <Description>The ID of the SAML configuration</Description>
        </Parameter>
        <Parameter Name="@MessageId">
            <Description>The SAML ID of the message just received</Description>
        </Parameter>
        <Parameter Name="@ExpiresAt">
            <Description>The date and time the ID expires. Old IDs can be deleted</Description>
        </Parameter>
    </Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE [Saml].[spVerifySamlMessageId]
(
    @ConfigurationId INT,
    @MessageId VARCHAR(45),
	@ExpiresAt DATETIME
)
AS

	DELETE 
	FROM Saml.IDStore 
	WHERE ExpiresAt < GETDATE()
	
	BEGIN TRY
		INSERT INTO Saml.IDStore 
		(ConfigurationId, MessageId, ExpiresAt) 
		VALUES (@ConfigurationId, @MessageId, @ExpiresAt)
		
		SELECT 1 AS Success
	END TRY
	BEGIN CATCH
		SELECT 0 AS Success
	END CATCH

GO