/***
<Table>
    <Description>Contains objects for the SAML configuration</Description>
    <Service>Users</Service>
    <Feature>Saml</Feature>
</Table>
***/
CREATE SCHEMA [Saml] AUTHORIZATION [dbo]
GO