/***
<Table>
  <Description>SAML role types. Either Service Provider or Identity Provider</Description>
  <TableType>SystemSetting</TableType>
  <Columns>
    <Column Name="RoleTypeId">
      <Description>Role type Id PK</Description>
    </Column>
    <Column Name="RoleTypeName">
      <Description>Role type description</Description>
    </Column>
  </Columns>
</Table>
***/
CREATE TABLE [Saml].[RoleTypes]
(
	[RoleTypeId] [tinyint] NOT NULL,
	[RoleTypeName] [varchar] (30) NOT NULL,
	CONSTRAINT [PK_RoleTypes] PRIMARY KEY CLUSTERED ([RoleTypeId] ASC)
)
