/***
<Table>
  <Description>SAML ID store to detect replay attacks</Description>
  <TableType>Transaction</TableType>
</Table>
***/
CREATE TABLE [Saml].[IDStore]
(
	[ConfigurationId] INT NOT NULL,
	[MessageID] varchar(45) NOT NULL,
	[ExpiresAt] datetime NOT NULL,
 CONSTRAINT [PK_IDStore] PRIMARY KEY CLUSTERED ( [MessageID], [ConfigurationId] ASC )
)
go