/***
<Table>
  <Description>SAML identity providers</Description>
  <TableType>SystemSetting</TableType>
  <Columns>
    <Column Name="IdentityProviderId">
      <Description>ID of the identity provider settings</Description>
    </Column>
    <Column Name="Name">
      <Description>Description of this identity provider, not shown anywhere</Description>
    </Column>
    <Column Name="SingleLogoutServiceUrl">
      <Description>The URL of the SLO service endpoint with the identity provider</Description>
    </Column>
    <Column Name="SingleLogoutServiceResponseUrl">
      <Description>If the URL for the SLO responses is different, then include here, otherwise leave null</Description>
    </Column>
    <Column Name="AuthenticationRequestsUrl">
      <Description>The URL for the authentication requests service endpoint with the identity provider</Description>
    </Column>
    <Column Name="MetadataUrl">
      <Description>The URL for the identity provider as a whole. This is used in the issuer/destination property in the SAML token</Description>
    </Column>
    <Column Name="SigningCertificateId">
      <Description>The certificate used to sign the SAML tokens. If the local role is SP, then this will be the SP's public key</Description>
    </Column>
    <Column Name="EncryptionCertificateId">
      <Description>The ID of the certificate used to encrypt the SAML tokens</Description>
    </Column>
    <Column Name="DecryptionCertificateId">
      <Description>The ID of the certificate used to decrypt the SAML tokens</Description>
    </Column>
  </Columns>
</Table>
***/
CREATE TABLE [Saml].[IdentityProviders](
	[IdentityProviderId] [int] NOT NULL,
	[Name] [varchar] (100) NOT NULL,
	[SingleLogoutServiceUrl] [varchar] (100) NULL,
	[SingleLogoutServiceResponseUrl] [varchar] (100) NULL,
	[AuthenticationRequestsUrl] [varchar] (100) NULL,
	[MetadataUrl] [varchar] (100) NULL,
	[SigningCertificateId] [int] NULL,
	[EncryptionCertificateId] [int] NULL,
	[DecryptionCertificateId] [int] NULL,
 CONSTRAINT [PK_IdentityProviders] PRIMARY KEY CLUSTERED ( [IdentityProviderId] ASC ),
 CONSTRAINT FK_IdentityProviders_SigningCertificateId FOREIGN KEY (SigningCertificateId) REFERENCES Saml.Certificates(CertificateId),
 CONSTRAINT FK_IdentityProviders_EncryptionCertificateId FOREIGN KEY (EncryptionCertificateId) REFERENCES Saml.Certificates(CertificateId),
 CONSTRAINT FK_IdentityProviders_DecryptionCertificateId FOREIGN KEY (DecryptionCertificateId) REFERENCES Saml.Certificates(CertificateId)
)
