/***
<Table>
  <Description>Stores primary configuration for a SAML system</Description>
  <TableType>SystemSetting</TableType>
  <Columns>
    <Column Name="ConfigurationId">
      <Description>Unique identifier for this configuration</Description>
    </Column>
    <Column Name="ConfigurationKey">
      <Description>Unique name for the configuration, used to identify it in service calls</Description>
    </Column>
    <Column Name="LocalRoleTypeId">
      <Description>Whether the local environment is a service provider or an identity provider</Description>
    </Column>
    <Column Name="ServiceProviderId">
      <Description>ID of the service provider configuration settings</Description>
    </Column>
    <Column Name="IdentityProviderId">
      <Description>ID of the identity provider configuration settings</Description>
    </Column>
    <Column Name="UserIdentifierTypeId">
      <Description>The type of the user identifier: external user ID, FNZ user ID or customer ID</Description>
    </Column>
  </Columns>
</Table>
***/
CREATE TABLE [Saml].[Configurations]
(
	[ConfigurationId] [int] NOT NULL,
	[ConfigurationKey] [varchar] (25) NOT NULL,
 	[LocalRoleTypeId] [tinyint] NOT NULL,
	[ServiceProviderId] [int] NOT NULL,
	[IdentityProviderId] [int] NOT NULL,
 	[UserIdentifierTypeId] [tinyint] NOT NULL,
	CONSTRAINT [PK_Configurations] PRIMARY KEY CLUSTERED ( [ConfigurationId] ASC ),
	CONSTRAINT FK_Configurations_LocalRoleTypeId FOREIGN KEY (LocalRoleTypeId) REFERENCES Saml.RoleTypes(RoleTypeId),
	CONSTRAINT FK_Configurations_IdentityProviderId FOREIGN KEY (IdentityProviderId) REFERENCES Saml.IdentityProviders(IdentityProviderId),
	CONSTRAINT FK_Configurations_ServiceProviderId FOREIGN KEY (ServiceProviderId) REFERENCES Saml.ServiceProviders(ServiceProviderId),
	CONSTRAINT FK_Configurations_UserIdentifierTypeId FOREIGN KEY (UserIdentifierTypeId) REFERENCES Saml.UserIdentifierTypes(UserIdentifierTypeId)
)
GO
CREATE UNIQUE NONCLUSTERED INDEX [UIDX_ConfigurationKey] ON [Saml].[Configurations] (ConfigurationKey)
GO
