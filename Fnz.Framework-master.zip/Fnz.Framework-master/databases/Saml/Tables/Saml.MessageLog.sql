/***
<Table>
  <Description>SAML log for all messages</Description>
  <TableType>Logging</TableType>
</Table>
***/
CREATE TABLE [Saml].[MessageLog]
(
	[LogId] INT NOT NULL IDENTITY (1,1) CONSTRAINT [PK_MessageLog] PRIMARY KEY CLUSTERED,
	[SamlMessageId] varchar(150) NULL,
	[LogDateTime] datetime NOT NULL,
	[UserId] int NULL,
	[ExternalUserId] varchar(150) NULL,
	[ActionType] tinyint NULL,
	[Success] tinyint NULL,
	[Exception] varchar(500) NULL,
	[Message] varchar(max) NULL,
)
GO