/***
<Table>
  <Description>SAML service providers</Description>
  <TableType>SystemSetting</TableType>
  <Columns>
    <Column Name="ServiceProviderId">
      <Description>Service provider configuration ID</Description>
    </Column>
    <Column Name="Name">
      <Description>Description of this service provider, not shown anywhere</Description>
    </Column>
    <Column Name="AssertionConsumerServiceUrl">
      <Description>The URL for the assertion consumer service endpoint at the service provider</Description>
    </Column>
    <Column Name="SingleLogoutServiceUrl">
      <Description>The URL for the SLO service endpoint at the service provider</Description>
    </Column>
    <Column Name="SingleLogoutServiceResponseUrl">
      <Description>The URL for the SLO service endpoint for logout responses if different, otherwise leave at null</Description>
    </Column>
    <Column Name="MetadataUrl">
      <Description>The URL for the service provider as a whole. This is used in the issuer/destination property in the SAML token</Description>
    </Column>
    <Column Name="SigningCertificateId">
      <Description>The ID of the certificate used to sign the SAML tokens. If the local role is SP, then this will be the SPs private key</Description>
    </Column>
    <Column Name="EncryptionCertificateId">
      <Description>The ID of the certificate used to encrypt the SAML tokens</Description>
    </Column>
    <Column Name="DecryptionCertificateId">
      <Description>The ID of the certificate used to decrypt the SAML tokens</Description>
    </Column>
  </Columns>
</Table>
***/
CREATE TABLE [Saml].[ServiceProviders]
(
	[ServiceProviderId] [int] NOT NULL,
	[Name] [varchar] (100) NOT NULL,
	[AssertionConsumerServiceUrl] [varchar] (100) NULL,
	[SingleLogoutServiceUrl] [varchar] (100) NULL,
	[SingleLogoutServiceResponseUrl] [varchar] (100) NULL,
	[MetadataUrl] [varchar] (100) NULL,
	[SigningCertificateId] [int] NULL,
	[EncryptionCertificateId] [int] NULL,
	[DecryptionCertificateId] [int] NULL,
 CONSTRAINT [PK_ServiceProviders] PRIMARY KEY CLUSTERED ( [ServiceProviderId] ASC ),
 CONSTRAINT FK_ServiceProviders_SigningCertificateId FOREIGN KEY (SigningCertificateId) REFERENCES Saml.Certificates(CertificateId),
 CONSTRAINT FK_ServiceProviders_EncryptionCertificateId FOREIGN KEY (EncryptionCertificateId) REFERENCES Saml.Certificates(CertificateId),
 CONSTRAINT FK_ServiceProviders_DecryptionCertificateId FOREIGN KEY (DecryptionCertificateId) REFERENCES Saml.Certificates(CertificateId)
)