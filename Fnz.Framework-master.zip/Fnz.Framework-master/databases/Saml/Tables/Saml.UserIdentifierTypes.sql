/***
<Table>
  <Description>User Identifier Types. Specifies what the shared user identifier is in a SAML configuration, for example FNZ UserID or ExternalUserId</Description>
  <TableType>SystemSetting</TableType>
  <Columns>
    <Column Name="UserIdentifierTypeId">
      <Description>User identifier type PK</Description>
    </Column>
    <Column Name="UserIdentifierTypeName">
      <Description>User identifier description, not shown anywhere</Description>
    </Column>
  </Columns>
</Table>
***/
CREATE TABLE [Saml].[UserIdentifierTypes]
(
	[UserIdentifierTypeId] [tinyint] NOT NULL,
	[UserIdentifierTypeName] [varchar] (30) NOT NULL,
	CONSTRAINT [PK_UserIdentifierTypes] PRIMARY KEY CLUSTERED ( [UserIdentifierTypeId] ASC )
)
GO
