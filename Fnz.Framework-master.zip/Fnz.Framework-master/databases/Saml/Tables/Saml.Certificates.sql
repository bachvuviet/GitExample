/***
<Table>
  <Description>SAML certificates</Description>
  <TableType>SystemSetting</TableType>
  <Columns>
    <Column Name="CertificateId">
      <Description>Certificate Id PK</Description>
    </Column>
    <Column Name="Description">
      <Description>Human-readable name for the certificate, not displayed anywhere</Description>
    </Column>
    <Column Name="Password">
      <Description>Password for the certificate file if required, otherwise null</Description>
      <PrivacyLevel>Confidential</PrivacyLevel>
    </Column>
    <Column Name="Certificate">
      <Description>The certificate binary, either a pfx or cer format</Description>
      <PrivacyLevel>Confidential</PrivacyLevel>
    </Column>
  </Columns>
</Table>
***/
CREATE TABLE [Saml].[Certificates]
(
	[CertificateId] [int] NOT NULL,
	[Description] [varchar] (100) NOT NULL,
	[Password] [varchar] (100) NULL,
	[Certificate] [varbinary] (max) NOT NULL,
	CONSTRAINT [PK_Certificates] PRIMARY KEY CLUSTERED ([CertificateId] ASC)
)
GO