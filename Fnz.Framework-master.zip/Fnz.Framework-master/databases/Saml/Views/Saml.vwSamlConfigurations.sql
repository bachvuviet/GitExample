CREATE VIEW [Saml].[vwSamlConfigurations] AS 

	SELECT		Config.ConfigurationKey,
				Config.ConfigurationId,
				Config.LocalRoleTypeId,
				Config.UserIdentifierTypeId,
				IdP.SingleLogoutServiceUrl AS IdPSingleLogoutServiceUrl,
				IdP.SingleLogoutServiceResponseUrl AS IdPSingleLogoutServiceResponseUrl,
				IdP.MetadataUrl AS IdPMetadataUrl,
				SP.SingleLogoutServiceUrl AS SPSingleLogoutServiceUrl,
				SP.SingleLogoutServiceResponseUrl AS SPSingleLogoutServiceResponseUrl,
				SP.MetadataUrl AS SPMetadataUrl,
				SP.AssertionConsumerServiceUrl AS SPAssertionConsumerServiceUrl,
				SPSigningCert.Certificate AS SPSigningCertificate,
				SPSigningCert.Password AS SPSigningCertificatePassword,
				SPEncryptionCert.Certificate AS SPEncryptionCertificate,
				SPEncryptionCert.Password AS SPEncryptionCertificatePassword,
				SPDecryptionCert.Certificate AS SPDecryptionCertificate,
				SPDecryptionCert.Password AS SPDecryptionCertificatePassword,
				IdPSigningCert.Certificate AS IdPSigningCertificate,
				IdPSigningCert.Password AS IdPSigningCertificatePassword,
				IdPEncryptionCert.Certificate AS IdPEncryptionCertificate,
				IdPEncryptionCert.Password AS IdPEncryptionCertificatePassword,
				IdPDecryptionCert.Certificate AS IdPDecryptionCertificate,
				IdPDecryptionCert.Password AS IdPDecryptionCertificatePassword
	FROM		[Saml].Configurations Config
		INNER JOIN	[Saml].[IdentityProviders] IdP	ON Config.IdentityProviderId = IdP.IdentityProviderId
		INNER JOIN	[Saml].[ServiceProviders] SP ON Config.ServiceProviderId = SP.ServiceProviderId
		LEFT JOIN	[Saml].[Certificates] SPSigningCert ON SP.SigningCertificateId = SPSigningCert.CertificateId
		LEFT JOIN	[Saml].[Certificates] SPEncryptionCert ON SP.EncryptionCertificateId = SPEncryptionCert.CertificateId
		LEFT JOIN	[Saml].[Certificates] SPDecryptionCert ON SP.DecryptionCertificateId = SPDecryptionCert.CertificateId
		LEFT JOIN	[Saml].[Certificates] IdPSigningCert ON IdP.SigningCertificateId = IdPSigningCert.CertificateId
		LEFT JOIN	[Saml].[Certificates] IdPEncryptionCert ON IdP.EncryptionCertificateId = IdPEncryptionCert.CertificateId
		LEFT JOIN	[Saml].[Certificates] IdPDecryptionCert ON IdP.DecryptionCertificateId = IdPEncryptionCert.CertificateId

GO
