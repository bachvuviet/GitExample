UPDATE Saml.Certificates
SET Password = '', Certificate =  CONVERT(varbinary(1), N'')
