/***
<Table>
	<Description>	 
				Stores details of all documents that have been migrated from 
				the old documents table (documents.dbo.DocumentImages) to the new documents table (platform.documents.documents)
	</Description>
	<TableType>Logging</TableType>
	<Columns>	    
		<Column Name="DocumentId">
			<Description>The Id of the document in the old DocumentImages table AND the new platform.documents.documents table</Description>
		</Column>
		<Column Name="DateTimeMigrated">
			<Description>The date the document was migrated. Non-editable once set, but should be initially provided by the application</Description>
			<ReadOnly>true</ReadOnly>
		</Column>
		<Column Name="DateTimeOriginallyAdded">
			<Description>The date the document was originally added to the DocumentImage table. Non-editable once set, but should be initially provided by the application</Description>
		</Column>
		<Column Name="Filename">
			<Description>Unique, system generated filename for the document. Will be the filename in the storage platform (HCP) and is used to support legacy interfaces</Description>
		</Column>
		<Column Name="FilestoreId">
			<Description>The FilestoreId of the document - null if it was stored in the DocumentImages table rather than the filestore</Description>
		</Column>
	</Columns>
</Table> 
***/
CREATE TABLE [DocumentsLogging].[DocumentsMigratedFromDocumentImages] 
(
    [LogId] INT IDENTITY(1,1) NOT NULL CONSTRAINT [PK_DocumentsMigratedFromDocumentImages] PRIMARY KEY CLUSTERED,
    [DocumentId] INT NOT NULL CONSTRAINT [FK_DocumentsMigratedFromDocumentImages_Documents_DocumentId] FOREIGN KEY REFERENCES [Documents].[Documents]([DocumentId]),
    [DateTimeMigrated] DATETIME NOT NULL DEFAULT (GETDATE()),
	[DateTimeOriginallyAdded] DATETIME NOT NULL,
    [Filename] VARCHAR(100) NOT NULL,
	[FilestoreId] INT NULL 
)
GO

CREATE UNIQUE NONCLUSTERED INDEX [UIDX_Filename] ON [DocumentsLogging].[DocumentsMigratedFromDocumentImages]([Filename])
GO
