/***
<Table>
  <Description>Top level document category</Description>
  <TableType>SystemSetting</TableType>
  <Columns>
    <Column Name="DocumentCategoryId">
      <Description>Unique identifier for the document category</Description>
    </Column>
    <Column Name="DocumentCategoryName">
      <Description>Unique name for the document category</Description>
    </Column>
    <Column Name="RetentionClassId">
      <Description>The retention class which documents in this category should be added to the HCP filestore with</Description>
    </Column>
  </Columns>
  <TOMLevel1>Documents</TOMLevel1>
  <TOMLevel2>Document Control</TOMLevel2>
</Table>
***/
CREATE TABLE [Documents].[DocumentCategories]
(
    DocumentCategoryId TINYINT NOT NULL CONSTRAINT [PK_DocumentCategories] PRIMARY KEY CLUSTERED,
    DocumentCategoryName VARCHAR(100) NOT NULL,
    RetentionClassId TINYINT NULL CONSTRAINT [FK_DocumentCategories_RetentionClass_RetentionClassId] FOREIGN KEY REFERENCES [Documents].[RetentionClasses]([RetentionClassId])
)
GO

CREATE UNIQUE NONCLUSTERED INDEX [UIDX_DocumentCategoryName] ON [Documents].[DocumentCategories] ([DocumentCategoryName])
GO
