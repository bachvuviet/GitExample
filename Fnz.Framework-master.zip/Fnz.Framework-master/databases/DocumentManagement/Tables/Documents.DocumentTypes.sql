/***
<Table>
  <Description>List of types of documents which can be stored on the platform</Description>
  <TableType>SystemSetting</TableType>
  <Columns>
    <Column Name="DocumentTypeId">
      <Description>Unique identifier for the document type</Description>
    </Column>
    <Column Name="DocumentTypeName">
      <Description>Unique name for the document type</Description>
    </Column>
    <Column Name="DocumentSubCategoryId">
      <Description>FK to the subcategory the document belongs to</Description>
    </Column>
  </Columns>
  <TOMLevel1>Documents</TOMLevel1>
  <TOMLevel2>Document Control</TOMLevel2>
  <FunctionalStream />
</Table>
***/
CREATE TABLE [Documents].[DocumentTypes]
(
	DocumentTypeId SMALLINT NOT NULL  CONSTRAINT [PK_DocumentTypes] PRIMARY KEY CLUSTERED,
	DocumentTypeName VARCHAR(100) NOT NULL,
	DocumentSubCategoryId SMALLINT NOT NULL CONSTRAINT [FK_DocumentTypes_DocumentSubCategories_DocumentSubCategoryId] FOREIGN KEY REFERENCES [Documents].[DocumentSubCategories]([DocumentSubCategoryId])
)
GO

CREATE UNIQUE NONCLUSTERED INDEX [UIDX_DocumentTypeName] ON [Documents].[DocumentTypes] ([DocumentTypeName])
GO
