/***
<Table>
  <Description>Second level of document categories</Description>
  <TableType>SystemSetting</TableType>
  <Columns>
    <Column Name="DocumentSubCategoryId">
      <Description>Unique identifier for the document sub category</Description>
    </Column>
    <Column Name="DocumentSubCategoryName">
      <Description>Unique name for the document sub category</Description>
    </Column>
    <Column Name="DocumentCategoryId">
      <Description>The document category of which this is a sub-category</Description>
    </Column>
  </Columns>
  <TOMLevel1>Documents</TOMLevel1>
  <TOMLevel2>Document Control</TOMLevel2>
</Table>
***/
CREATE TABLE [Documents].[DocumentSubCategories]
(
    DocumentSubCategoryId SMALLINT NOT NULL CONSTRAINT [PK_DocumentSubCategories] PRIMARY KEY CLUSTERED,
    DocumentSubCategoryName VARCHAR(100) NOT NULL,
    DocumentCategoryId TINYINT NOT NULL CONSTRAINT [FK_DocumentSubCategories_DocumentCategories_DocumentCategoryId] FOREIGN KEY REFERENCES [Documents].[DocumentCategories]([DocumentCategoryId])
)
GO

CREATE UNIQUE NONCLUSTERED INDEX [UIDX_DocumentSubCategoryName] ON [Documents].[DocumentSubCategories] ([DocumentSubCategoryName])
GO
