/***
<Table>
	<Description>	HCP Documents Table. 
				Stores HCP specific details of all documents stored by the platform if using HCP
	</Description>
	<TableType>Transaction</TableType>
	<Columns>
		<Column Name="DocumentId">
			<Description>Unique document identifier, also the foreign key to the Documents.Documents table</Description>
		</Column>
		<Column Name="HcpPath">
			<Description>The path in the HCP server where the document is stored (ommits the root folder which is the environment name)</Description>
		</Column>
	</Columns>
</Table>
***/
CREATE TABLE [Documents].[HCPDocuments]
(

    [DocumentId] INT NOT NULL 
                           CONSTRAINT [PK_HCPDocuments] PRIMARY KEY CLUSTERED
                           CONSTRAINT [FK_HCPDocuments_Documents_DocumentId] FOREIGN KEY REFERENCES [Documents].[Documents]([DocumentId]),
    [HcpPath] VarChar(150) NOT NULL
)
GO
GO

--Path should be unique
CREATE UNIQUE NONCLUSTERED INDEX [UIDX_HcpPath] ON [Documents].[HCPDocuments]([HcpPath])
GO
