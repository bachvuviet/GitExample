/***
<Table>
  <Description>
    Maps taskIds to document types. 
    Entries in here will cause documents automatically saved by the task runner framework to be identified as the mapped Document Type
  </Description>
  <TableType>SystemSetting</TableType>
  <Columns>
    <Column Name="TaskId">
      <Description>The TaskId which we are mapping documents automatically saved by to a document type</Description>
    </Column>
    <Column Name="DocumentTypeId">
      <Description>The document type of the taskId we are mapping</Description>
    </Column>
  </Columns>
  <TOMLevel1>Documents</TOMLevel1>
  <TOMLevel2>Document Control</TOMLevel2>
</Table>
***/
CREATE TABLE [Documents].[TaskDocumentTypes]
(
    TaskId INT NOT NULL CONSTRAINT [PK_TaskDocumentTypes] PRIMARY KEY CLUSTERED,
    DocumentTypeId SMALLINT NOT NULL CONSTRAINT [FK_TaskDocumentTypes_DocumentTypes_DocumentTypeId] FOREIGN KEY REFERENCES [Documents].[DocumentTypes]([DocumentTypeId])
)
GO
