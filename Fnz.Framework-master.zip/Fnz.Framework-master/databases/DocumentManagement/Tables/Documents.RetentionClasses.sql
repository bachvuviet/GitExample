/***
<Table>
  <Description>List of retention classes set in HCP filestore which documents can be categorised as</Description>
  <TableType>SystemSetting</TableType>
  <Columns>
    <Column Name="RetentionClassId">
      <Description>Unique id for a given retention class</Description>
    </Column>
    <Column Name="RetentionClassName">
      <Description>Unique name for the retention class. Must match the name setup in HCP filestore</Description>
    </Column>
  </Columns>
  <TOMLevel1>Documents</TOMLevel1>
  <TOMLevel2>Document Control</TOMLevel2>
</Table>
***/
CREATE TABLE [Documents].[RetentionClasses]
(
    RetentionClassId TINYINT NOT NULL CONSTRAINT [PK_RetentionClasses] PRIMARY KEY CLUSTERED,
    RetentionClassName VARCHAR(100) NOT NULL
)
GO

CREATE UNIQUE NONCLUSTERED INDEX [UIDX_RetentionClassName] ON [Documents].[RetentionClasses] ([RetentionClassName])
GO
