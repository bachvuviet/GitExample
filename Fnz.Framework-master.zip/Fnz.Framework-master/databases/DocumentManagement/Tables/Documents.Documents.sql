/***
<Table>
	<Description>	Main Documents Table. 
				Stores details of all documents stored by the platform if using the new system (documents stored in HCP) 
				Replaces DocumentImages.
	</Description>
	<TableType>Transaction</TableType>
	<Columns>
		<Column Name="DocumentId">
			<Description>Unique document identifier, any references to documents elsewhere should use this Id</Description>
		</Column>
		<Column Name="DateTimeAdded">
			<Description>The date the document was added to the system. Also used to determine where the document is stored within the HCP file-system. Non-editable once set, but should be initially provided by the application</Description>
			<ReadOnly>true</ReadOnly>
		</Column>
		<Column Name="Filename">
			<Description>Unique, system generated filename for the document. Will be the filename in the storage platform (HCP) and is used to support legacy interfaces</Description>
		</Column>
		<Column Name="DisplayFilename">
			<Description>Display Filename for the document. To be used for display purposes or setting a filename for downloads, etc. Non-unique, so should never be used to look up a document</Description>
		</Column>
	</Columns>
</Table>
***/
CREATE TABLE [Documents].[Documents] 
(
    DocumentId INT IDENTITY(1,1) NOT NULL CONSTRAINT [PK_Documents] PRIMARY KEY CLUSTERED,
    DateTimeAdded DATETIME NOT NULL DEFAULT (GETDATE()),
    [Filename] VARCHAR(100) NOT NULL,
    [DisplayFilename] VARCHAR(100) NULL
)
GO

CREATE UNIQUE NONCLUSTERED INDEX [UIDX_Filename] ON [Documents].[Documents]([Filename])
GO