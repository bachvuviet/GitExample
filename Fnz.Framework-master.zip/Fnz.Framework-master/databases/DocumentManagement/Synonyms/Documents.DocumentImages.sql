/***
<Synonym>
	<Description>Contains client's documents</Description>
	<Columns>
		<Column Name="DocId">
			<Description>ID for the document binary</Description>
			<DataType>int</DataType>
			<IsIdentity>true</IsIdentity>
		</Column>
		<Column Name="FileName">
			<Description>The filename of the doc record</Description>
			<DataType>varchar(100)</DataType>
		</Column>
		<Column Name="DocImage">
			<Description>the document binary</Description>
			<DataType>image</DataType>
		</Column>
		<Column Name="FilestoreId">
			<Description>reference to external document store</Description>
			<DataType>int</DataType>
		</Column>
		<Column Name="DateTimeAdded">
			<Description>Date and time the document was added</Description>
			<DataType>datetime</DataType>
		</Column>
	</Columns>
</Synonym>
***/
CREATE SYNONYM [Documents].[DocumentImages] FOR [Documents].[dbo].[DocumentImages]
GO
