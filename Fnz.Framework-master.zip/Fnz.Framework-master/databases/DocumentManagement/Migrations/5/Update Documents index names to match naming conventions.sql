
EXEC SchemaMigration.spRenameIndex @Schema = N'Documents', @Table = N'DocumentCategories', @OldIndexName = N'idx_DocumentCategories_DocumentCategoryName', @NewIndexName = N'UIDX_DocumentCategoryName'
EXEC SchemaMigration.spRenameIndex @Schema = N'Documents', @Table = N'Documents', @OldIndexName = N'idx_Documents_Filename', @NewIndexName = N'UIDX_Filename'
EXEC SchemaMigration.spRenameIndex @Schema = N'Documents', @Table = N'DocumentSubCategories', @OldIndexName = N'idx_DocumentSubCategories_DocumentSubCategoryName', @NewIndexName = N'UIDX_DocumentSubCategoryName'
EXEC SchemaMigration.spRenameIndex @Schema = N'Documents', @Table = N'DocumentTypes', @OldIndexName = N'idx_DocumentTypes_DocumentTypeName', @NewIndexName = N'UIDX_DocumentTypeName'
EXEC SchemaMigration.spRenameIndex @Schema = N'Documents', @Table = N'HCPDocuments', @OldIndexName = N'UIDX_HCPDocuments_HcpPath', @NewIndexName = N'UIDX_HcpPath'
EXEC SchemaMigration.spRenameIndex @Schema = N'Documents', @Table = N'RetentionClasses', @OldIndexName = N'idx_RetentionClasses_RetentionClassName', @NewIndexName = N'UIDX_RetentionClassName'
EXEC SchemaMigration.spRenameIndex @Schema = N'DocumentsLogging', @Table = N'DocumentsMigratedFromDocumentImages', @OldIndexName = N'idx_DocumentsMigratedFromDocumentImages_Filename', @NewIndexName = N'UIDX_Filename'
