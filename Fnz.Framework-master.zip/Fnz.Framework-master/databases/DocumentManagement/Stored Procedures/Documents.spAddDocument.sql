/***
<StoredProcedure>
	<Description>Adds a document entry and returns the documentId</Description>
	<Parameters>
		<Parameter Name="@Filename">
			<Description>Unique system filename for the document</Description>
		</Parameter>
		<Parameter Name="@DateTimeAdded">
			<Description>The system DateTimeAdded for the newly added document</Description>
		</Parameter>
		<Parameter Name="@HcpPath">
			<Description>The path in the HCP server where the document has been stored - or null if this is not stored in the HCP server</Description>
		</Parameter>
		<Parameter Name="@DocumentId">
			<Description>Outputs the DocumentId for the newly added document</Description>
		</Parameter>
	</Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE [Documents].[spAddDocument] @Filename AS VARCHAR(100),  @DateTimeAdded AS DATETIME, @HcpPath AS VARCHAR(150) = null, @DocumentId AS INT OUTPUT AS
    
    INSERT INTO [Documents].[Documents]
    (DateTimeAdded, [Filename])
    SELECT @DateTimeAdded, @Filename
    
    SET @DocumentId = SCOPE_IDENTITY()

    IF (@HcpPath IS NOT NULL)	
	BEGIN
		INSERT INTO [Documents].[HcpDocuments]
    	(DocumentId, [HcpPath])
    	SELECT @DocumentId, @HcpPath
	END

GO