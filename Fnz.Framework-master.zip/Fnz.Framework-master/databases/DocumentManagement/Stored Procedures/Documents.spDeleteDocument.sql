/***
<StoredProcedure>
	<Description>Adds a document entry and returns the documentId</Description>
	<Parameters>
		<Parameter Name="@DocumentId">
			<Description>Unique system filename for the document</Description>
		</Parameter>
	</Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE [Documents].[spDeleteDocument]( @DocumentId AS INT) AS
BEGIN    
	DELETE FROM [Documents].[HcpDocuments]
	WHERE DocumentId = @DocumentId

    DELETE FROM [Documents].[Documents]
	WHERE DocumentId = @DocumentId
END
GO