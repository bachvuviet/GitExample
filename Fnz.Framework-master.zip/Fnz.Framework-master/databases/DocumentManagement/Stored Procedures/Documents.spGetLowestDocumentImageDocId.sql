/***
<StoredProcedure>
	<Description>Gets the lowest DocId from DocumentImages table. Used to get latest starting point for document migrations.</Description>
</StoredProcedure>
***/
CREATE PROCEDURE Documents.spGetLowestDocumentImageDocId AS

    SELECT MIN(DocId) LowestDocId
    FROM Documents.DocumentImages
	WHERE DocImage IS NOT NULL
	OR FileStoreId IS NOT NULL

GO
