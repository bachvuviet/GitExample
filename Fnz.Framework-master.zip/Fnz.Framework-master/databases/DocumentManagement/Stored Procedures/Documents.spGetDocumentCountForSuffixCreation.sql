/***
<StoredProcedure>
	<Description>Produces a suffix for the file that will make the file unique based on the name</Description>
	<Parameters>
		<Parameter Name="@Filename">
			<Description>The Filename of the document record you want to look up without the suffix</Description>
		</Parameter>
		<Parameter Name="@Extension">
			<Description>The file extension which will ensure a more accurate unique suffix creation</Description>
		</Parameter>
	</Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE [Documents].[spGetDocumentCountForSuffixCreation] ( @Filename AS VARCHAR(100), @Extension AS Varchar(10) )
AS
    
    SELECT Count(*) [Count]
    FROM [Documents].[Documents]
    WHERE [Filename] LIKE @Filename + '%.' + @Extension

GO