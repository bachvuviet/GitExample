/***
<StoredProcedure>
	<Description>Gets the DocumentTypeId for documents which are automatically saved by a given @TaskId</Description>
	<Parameters>
		<Parameter Name="@TaskId">
			<Description>The TaskId to retreive the document type id for</Description>
		</Parameter>
	</Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE [Documents].[spGetTaskDocumentTypeId] @TaskId INT AS

    SELECT DocumentTypeId
    FROM Documents.TaskDocumentTypes
    WHERE TaskId = @TaskId

GO