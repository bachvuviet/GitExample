/***
<StoredProcedure>
	<Description>Gets the configured retention class for a given document type</Description>
	<Parameters>
		<Parameter Name="@DocumentTypeId">
			<Description>The document type to retrieve the retention class for</Description>
		</Parameter>
	</Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE [Documents].[spGetDocumentTypeRetentionClass] @DocumentTypeId SMALLINT AS
    
    SELECT rc.RetentionClassName
    FROM Documents.DocumentTypes dt
	   INNER JOIN Documents.DocumentSubCategories dsc ON dt.DocumentSubCategoryId = dsc.DocumentSubCategoryId   
	   INNER JOIN Documents.DocumentCategories dc ON dsc.DocumentCategoryId = dc.DocumentCategoryId
	   INNER JOIN Documents.RetentionClasses rc ON dc.RetentionClassId = rc.RetentionClassId
    WHERE dt.DocumentTypeId = @DocumentTypeId

GO