/***
<StoredProcedure>
    <Description>
		Delete a row in the DocumentImages table 
	</Description>
    <Parameter Name="@FileName">
		<Description>The Filename of the document to delete</Description>
	</Parameter>
</StoredProcedure>
***/
CREATE PROCEDURE [Documents].[spDeleteLegacyDocumentImage](@FileName as varchar(100)) AS
BEGIN
	DELETE FROM Documents.DocumentImages 
	WHERE FILENAME = @FileName
END

