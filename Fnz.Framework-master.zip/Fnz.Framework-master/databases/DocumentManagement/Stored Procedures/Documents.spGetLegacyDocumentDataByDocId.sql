/***
<StoredProcedure>
	<Description>Gets a document entry (from the legacy DocumentImages table) and returns its DocImage (data) together with its other columns </Description>
	<Parameters>
		<Parameter Name="@DocId">
			<Description>DocId of the document record you want to look up</Description>
		</Parameter>
	</Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE [Documents].[spGetLegacyDocumentDataByDocId] @DocId AS Int AS
    
    SELECT [DocId], [FileName], [DocImage], [FilestoreId], [DateTimeAdded]
    FROM [Documents].[DocumentImages]
    WHERE [DocId] = @DocId

GO
