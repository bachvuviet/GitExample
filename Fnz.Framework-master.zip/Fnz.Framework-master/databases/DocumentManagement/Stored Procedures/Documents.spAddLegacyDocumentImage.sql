/***
<StoredProcedure>
    <Description>
		Insert a new row in the DocumentImages table (which is where we used to store document meta-data and data).
	</Description>
    <Parameters>
		<Parameter Name="@Filename">
			<Description>Unique system filename for the document</Description>
		</Parameter>
		<Parameter Name="@DateTimeAdded">
			<Description>The system DateTimeAdded for the newly added document</Description>
		</Parameter>
		<Parameter Name="@DocImage">
			<Description>The document data</Description>
		</Parameter>
		<Parameter Name="@DocId">
			<Description>Outputs the Id for the newly added document</Description>
		</Parameter>
	</Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE [Documents].[spAddLegacyDocumentImage](@FileName as varchar(100), @DateTimeAdded as DateTime, @DocImage as Image, @DocId as int output) AS
BEGIN
	INSERT INTO Documents.DocumentImages ([FileName],[DocImage],[DateTimeAdded])
	VALUES (@FileName,@DocImage,@DateTimeAdded)

	SET @DocId = SCOPE_IDENTITY()
END

