/***
<StoredProcedure>
	<Description>Gets a list of document Ids\filenames, starting at @StartingId and </Description>
	<Parameters>
		<Parameter Name="@StartingId">
			<Description>The DocId in document images to start loading filenames from</Description>
		</Parameter>
		<Parameter Name="@BatchSize">
			<Description>The maximum number of records to return</Description>
		</Parameter>
	</Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE Documents.spGetFilenamesToMigrate @StartingId INT, @BatchSize INT AS

    SELECT DocId, [FileName]
    FROM Documents.DocumentImages
    WHERE DocId BETWEEN @StartingId AND @StartingId + @BatchSize - 1
		AND (DocImage IS NOT NULL OR FileStoreId IS NOT NULL)

GO

