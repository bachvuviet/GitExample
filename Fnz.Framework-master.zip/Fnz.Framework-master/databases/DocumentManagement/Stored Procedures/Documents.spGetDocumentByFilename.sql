/***
<StoredProcedure>
	<Description>Gets a document entry and returns the DateTimeAdded and DocumentId</Description>
	<Parameters>
		<Parameter Name="@Filename">
			<Description>The Filename of the document record you want to look up</Description>
		</Parameter>
	</Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE [Documents].[spGetDocumentByFilename] @Filename AS VARCHAR(100) AS
    
    SELECT DocumentId, DateTimeAdded, @Filename as Filename
    FROM [Documents].[Documents]
    WHERE [Filename] = @Filename

GO