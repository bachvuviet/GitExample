/***
<StoredProcedure>
	<Description>Gets a document entry (from the legacy DocumentImages table) and returns all its columns except for the DocImage</Description>
	<Parameters>
		<Parameter Name="@DocId">
			<Description>The DocId of the document record you want to look up</Description>
		</Parameter>
	</Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE [Documents].[spGetLegacyDocumentByDocId] @DocId AS INT AS
    
    SELECT [DocId], [FileName], [FilestoreId], [DateTimeAdded]
    FROM [Documents].[DocumentImages]
    WHERE [DocId] = @DocId

GO