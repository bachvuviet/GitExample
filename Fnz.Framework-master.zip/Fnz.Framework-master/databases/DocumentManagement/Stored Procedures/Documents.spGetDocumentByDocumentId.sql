/***
<StoredProcedure>
	<Description>Gets a document entry and returns the DateTimeAdded and Filename</Description>
	<Parameters>
		<Parameter Name="@DocumentId">
			<Description>The DocumentId of the document record you want to look up</Description>
		</Parameter>
	</Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE [Documents].[spGetDocumentByDocumentId] @DocumentId AS INT AS
    
    SELECT [Filename], DateTimeAdded, @DocumentId as DocumentId
    FROM [Documents].[Documents]
    WHERE DocumentId = @DocumentId

GO