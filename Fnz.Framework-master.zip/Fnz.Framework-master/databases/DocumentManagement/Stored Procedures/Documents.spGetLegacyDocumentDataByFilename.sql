/***
<StoredProcedure>
	<Description>Gets a document entry (from the legacy DocumentImages table) and returns its DocImage (data) together with its other columns </Description>
	<Parameters>
		<Parameter Name="@Filename">
			<Description>The Filename of the document record you want to look up</Description>
		</Parameter>
	</Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE [Documents].[spGetLegacyDocumentDataByFilename] @Filename AS VARCHAR(100) AS
    
    SELECT [DocId], [FileName], [DocImage], [FilestoreId], [DateTimeAdded]
    FROM [Documents].[DocumentImages]
    WHERE [Filename] = @Filename

GO