/***
<StoredProcedure>
	<Description>Copies a document entry from the DocumentImages table to the new  documents table</Description>
	<Parameters>
		<Parameter Name="@Filename">
			<Description>Unique system filename for the document to be migrated</Description>
		</Parameter>
		<Parameter Name="@DateTimeAdded">
			<Description>The system DateTimeAdded for the newly added document</Description>
		</Parameter>
		<Parameter Name="@DateTimeOriginallyAdded">
			<Description>The date the document was originally added to the DocumentImage table. Non-editable once set, but should be initially provided by the application</Description>
		</Parameter>
		<Parameter Name="@HcpPath">
			<Description>The path in the HCP server where the document has been stored </Description>
		</Parameter>
		<Parameter Name="@DocumentImagesId">
			<Description>The id of this document in the DocumentImages table</Description>
		</Parameter>
		<Parameter Name="@OldFilestoreId">
			<Description>The FilestoreId of the document - null if it was stored in the DocumentImages table rather than the filestore</Description>
		</Parameter>
	</Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE [Documents].[spAddMigratedDocument] @Filename AS VARCHAR(100), @DateTimeAdded AS DATETIME, @DateTimeOriginallyAdded AS DATETIME, @HcpPath AS VARCHAR(150), @DocumentImagesId AS INT, @OldFilestoreId AS INT = null with execute as owner AS
	-- Copy the document meta data to the new document meta data table, note that
	-- we retain the old id from the document images table when we migrate to the new table
	SET IDENTITY_INSERT Documents.Documents ON
	
	INSERT INTO Documents.Documents
	(DocumentId, DateTimeAdded, [Filename])
	SELECT @DocumentImagesId, @DateTimeAdded, @Filename

	SET IDENTITY_INSERT Documents.Documents OFF
    
    IF (@HcpPath IS NOT NULL)	
	BEGIN
		INSERT INTO [Documents].[HcpDocuments]
	    (DocumentId, HcpPath)
	    SELECT @DocumentImagesId, @HcpPath
	END

	-- Log what we migrated
	INSERT INTO [DocumentsLogging].[DocumentsMigratedFromDocumentImages]
    (DocumentId, DateTimeMigrated, DateTimeOriginallyAdded, [Filename], FilestoreId)
    SELECT @DocumentImagesId, @DateTimeAdded, @DateTimeOriginallyAdded, @Filename, @OldFilestoreId
GO 

