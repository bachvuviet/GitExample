/***
<StoredProcedure>
	<Description>Gets an HCPdocument entry and returns the HcpPath</Description>
	<Parameters>
		<Parameter Name="@Filename">
			<Description>The Filename of the document record you want to look up</Description>
		</Parameter>
	</Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE [Documents].[spGetHcpDocumentByFilename] @Filename AS VARCHAR(100) AS
    
    SELECT hcpDocs.DocumentId, hcpDocs.HcpPath
    FROM [Documents].[HcpDocuments] hcpDocs
	INNER JOIN [Documents].[Documents] docs on hcpDocs.DocumentId = docs.DocumentId
    WHERE docs.[Filename] = @Filename

GO