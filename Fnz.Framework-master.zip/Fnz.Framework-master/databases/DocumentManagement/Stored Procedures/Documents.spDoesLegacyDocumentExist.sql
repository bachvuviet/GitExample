/***
<StoredProcedure>
	<Description>Returns true if a document entry exists in the legacy DocumentImages table with the specified filename</Description>
	<Parameters>
		<Parameter Name="@Filename">
			<Description>The Filename of the document record you want to look up</Description>
		</Parameter>
	</Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE [Documents].[spDoesLegacyDocumentExist] @Filename AS VARCHAR(100), @DoesExist as bit output AS
    
    IF EXISTS (SELECT 1 FROM [Documents].[DocumentImages] WHERE [Filename] = @Filename)
        SET @DoesExist = 1
    ELSE
        SET @DoesExist = 0
    
GO 