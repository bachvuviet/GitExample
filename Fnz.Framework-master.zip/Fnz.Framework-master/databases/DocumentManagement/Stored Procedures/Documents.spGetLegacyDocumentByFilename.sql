/***
<StoredProcedure>
	<Description>Gets a document entry (from the legacy DocumentImages table) and returns all its columns except for the DocImage </Description>
	<Parameters>
		<Parameter Name="@Filename">
			<Description>The Filename of the document record you want to look up</Description>
		</Parameter>
	</Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE [Documents].[spGetLegacyDocumentByFilename] @Filename AS VARCHAR(100) AS
    
    SELECT [DocId], [FileName], [FilestoreId], [DateTimeAdded]
    FROM [Documents].[DocumentImages]
    WHERE [Filename] = @Filename

GO