/***
<StoredProcedure>
	<Description>Gets a document entry and returns the HCP Path where that document resides</Description>
	<Parameters>
		<Parameter Name="@DocumentId">
			<Description>The DocumentId of the document record you want to look up</Description>
		</Parameter>
	</Parameters>
</StoredProcedure>
***/
CREATE PROCEDURE [Documents].[spGetHcpDocumentByDocumentId] @DocumentId AS INT AS
    
    SELECT [HcpPath], @DocumentId as DocumentId
    FROM [Documents].[HcpDocuments]
    WHERE DocumentId = @DocumentId

GO