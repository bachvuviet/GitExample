CREATE VIEW [Documents].[vwDocumentTypes] AS
    SELECT
		dt.DocumentTypeId,
		dt.DocumentTypeName,
		tdt.TaskId
    FROM Documents.DocumentTypes AS dt
	LEFT JOIN Documents.TaskDocumentTypes AS tdt on dt.DocumentTypeId = tdt.DocumentTypeId