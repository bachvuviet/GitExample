/***
<Schema>
	<Description>default schema</Description>
	<Service>Unknown</Service>
	<Feature>Unknown</Feature>
</Schema>
***/