/***
<Schema>
	<Description>Contains objects for the Documents service logging</Description>
	<Service>Documents</Service>
	<Feature>Migration</Feature>
</Schema>
***/
CREATE SCHEMA [DocumentsLogging] AUTHORIZATION [dbo]
GO
