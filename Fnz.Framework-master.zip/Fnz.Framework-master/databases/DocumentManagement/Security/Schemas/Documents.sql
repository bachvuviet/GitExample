/***
<Schema>
	<Description>Contains objects for the Documents service</Description>
	<Service>Documents</Service>
	<Feature>Documents</Feature>
</Schema>
***/
CREATE SCHEMA [Documents] AUTHORIZATION [dbo]
GO
