/***
<Table>
  <Description>Defines the metadata, such as labels, fontsize etc, that are used in the generic report. If a setting is NULL it means use the default.</Description>
  <TableType>ClientConfig</TableType>
  <Columns>
    <Column Name="ID">
      <Description>Unique identifier for a CoySetting row</Description>
    </Column>
    <Column Name="GenericReportID">
      <Description>The generic report that these CoySettings apply to</Description>
    </Column>
    <Column Name="Company">
      <Description>The company that these CoySettings apply to. There might be different settings for a company which might differ from the default</Description>
    </Column>
    <Column Name="ReportTitle">
      <Description>The text that is the title of the report</Description>
    </Column>
    <Column Name="Logo">
      <Description>The logo shown on the report (top right corner) - DEF usually means use the FNZ logo, Null means no logo. The value here is used as a lookup to the vwCombinedOptions view</Description>
    </Column>
    <Column Name="TotalLabel">
      <Description>The Total Label</Description>
    </Column>
    <Column Name="SubTotalLabel">
      <Description>The SubTotal Label</Description>
    </Column>
    <Column Name="ShowHeadings">
      <Description>1 to show headings</Description>
    </Column>  
    <Column Name="FontSize">
      <Description>Size of the font e.g. 12</Description>
    </Column>  
    <Column Name="DataStartRow">
      <Description>The number for the Excel row where the data starts to be shown on the spreadsheet (with the title just above) </Description>
    </Column>  
    <Column Name="HeadingFontSize">
      <Description>Size of the font for the heading e.g. 12</Description>
    </Column>  
    <Column Name="SubTotalCriteria">
      <Description>Provides an optional way of grouping the data when calculating subtotals. More than one parameter is specified by the pipe character e.g. AccountName, FromBankAccountName|ToBankAccountName</Description>
    </Column> 
    <Column Name="TotalLabelPlacement">
      <Description>The column where the total label is shown</Description>
    </Column>
    <Column Name="HeaderText">
      <Description>The header label TODO - cannot see this being used in the Flexcel code</Description>
    </Column>
    <Column Name="HeaderFontSize">
      <Description>The header font size</Description>
    </Column>
    <Column Name="FooterText">
      <Description>The footer label</Description>
    </Column>
    <Column Name="FooterFontSize">
      <Description>The footer font size TODO - cannot see this being used in the Flexcel code </Description>
    </Column>
    <Column Name="PageNumberStyle">
      <Description>The Excel style for the Page Number cell i.e. Italic, Italic TODO - cannot see this being used in the Flexcel code</Description>
    </Column>
    <Column Name="PageNumberAlignment">
      <Description>The Excel alignment of the Logo cell - L for left, C for Center or R for Right TODO - cannot see this being used in the Flexcel code</Description>
    </Column>
    <Column Name="SheetOrientation">
      <Description>The Excel worksheet orientation - Landscape or Portrait</Description>
    </Column>
    <Column Name="LogoAlignment">
      <Description>The Excel alignment of the Logo cell - L for left, C for Center or R for Right</Description>
    </Column>
    <Column Name="PageNumberFontSize">
      <Description>The Excel font size for the the Page Number cell TODO - cannot see this being used in the Flexcel code</Description>
    </Column>
    <Column Name="StaticParameters">
      <Description>Not sure what this does TODO</Description>
    </Column>
    <Column Name="ShowCount">
      <Description>Not sure what this does TODO - cannot see this being used in the Flexcel code</Description>
    </Column>
    <Column Name="ShowSubTotalHeading">
      <Description>If 1 then it shows a heading for the sub total</Description>
    </Column>
    <Column Name="RepeatColumnHeaderCriteria">
      <Description>TNot sure what this does  ODO - cannot see this being used in the Flexcel code</Description>
    </Column>
    <Column Name="AutoFormatColumnWidths">
      <Description>Not sure what this does  TODO - cannot see this being used in the Flexcel code</Description>
    </Column>
    <Column Name="FooterImage">
      <Description>The logo shown at the bottom of the report - DEF usually means use the FNZ logo, Null means no logo. The value here is used as a lookup to the vwCombinedOptions view</Description>
    </Column>
    <Column Name="StaticText">
      <Description>Any static text that should be displayed TODO - cannot see this being used in the Flexcel code</Description>
    </Column>
    <Column Name="HeadingFontStyle">
      <Description>The Excel style for the Heading cell i.e. Italic, Italic</Description>
    </Column>
    <Column Name="IncludeSubTotalFormatting">
      <Description>TODO - cannot see this being used in the flexcel code</Description>
    </Column>
    <Column Name="StaticTextPlacement">
      <Description>TODO - cannot see this being used in the flexcel code!!!</Description>
    </Column>
    <Column Name="StaticTextAlignment">
      <Description>The Excel alignment of the StaticText cell - L for left, C for Center or R for Right TODO - cannot see this being used in the flexcel code!!!</Description>
    </Column>
    <Column Name="FitToPageWidthForPrint">
      <Description>TODO - cannot see this being used in the flexcel code!!!</Description>
    </Column>
    <Column Name="SheetLabel">
      <Description>The label to show on the Excel worksheet tab</Description>
    </Column>
    <Column Name="LeaveGap">
      <Description>TODO - cannot see this being used in the Flexcel code</Description>
    </Column>
    <Column Name="ReportTitleHorizontalAlignment">
      <Description>The Excel alignment of the ReportTitle cell - L for left, C for Center or R for Right TODO - cannot see this being used in the flexcel code!!!</Description>
    </Column>
    <Column Name="ShowSummaryRows">
      <Description>Not sure what this does TODO - cannot see this being used in the flexcel code!!!</Description>
    </Column>
    <Column Name="SecondarySubTotalCriteria">
      <Description>Not sure what this does TODO - cannot see this being used in the flexcel code!!!</Description>
    </Column>
    <Column Name="SecondarySubTotalLabel">
      <Description>Not sure what this does  TODO - cannot see this being used in the flexcel code!!!</Description>
    </Column>
    <Column Name="ColorSubTotalHeading">
      <Description>Not sure what this does  TODO - cannot see this being used in the flexcel code!!!</Description>
    </Column>
    <Column Name="TotalMustHaveValue">
      <Description>Not sure what this does  TODO - cannot see this being used in the flexcel code!!!</Description>
    </Column>
  </Columns>
  <TOMLevel1>Reporting</TOMLevel1>
</Table>
***/
CREATE TABLE [GenericReports].[GenericReportsCoySetting](
  [ID] [int] IDENTITY(1,1) NOT FOR REPLICATION NOT NULL,
  [GenericReportID] [int] NULL,
  [Company] [varchar](20) NULL,
  [ReportTitle] [varchar](200) NULL,
  [Logo] [varchar](20) NULL,
  [TotalLabel] [varchar](100) NULL,
  [SubTotalLabel] [varchar](200) NULL,
  [ShowHeadings] [int] NULL,
  [FontSize] [numeric](10, 1) NULL,
  [DataStartRow] [int] NULL,
  [HeadingFontSize] [int] NULL,
  [SubTotalCriteria] [varchar](100) NULL,
  [TotalLabelPlacement] [int] NULL,
  [HeaderText] [varchar](max) NULL,
  [HeaderFontSize] [int] NULL,
  [FooterText] [varchar](max) NULL,
  [FooterFontSize] [int] NULL,
  [PageNumberStyle] [varchar](10) NULL,
  [PageNumberAlignment] [varchar](10) NULL,
  [SheetOrientation] [varchar](9) NULL,
  [LogoAlignment] [varchar](1) NULL,
  [PageNumberFontSize] [int] NULL,
  [StaticParameters] [varchar](max) NULL,
  [ShowCount] [int] NULL,
  [ShowSubTotalHeading] [int] NULL,
  [RepeatColumnHeaderCriteria] [varchar](100) NULL,
  [AutoFormatColumnWidths] [int] NULL,
  [FooterImage] [varchar](100) NULL,
  [StaticText] [varchar](max) NULL,
  [HeadingFontStyle] [varchar](50) NULL,
  [IncludeSubTotalFormatting] [tinyint] NULL,
  [StaticTextPlacement] [varchar](20) NULL,
  [StaticTextAlignment] [varchar](6) NULL,
  [FitToPageWidthForPrint] [tinyint] NOT NULL,
  [SheetLabel] [varchar](200) NULL,
  [LeaveGap] [tinyint] NULL,
  [ReportTitleHorizontalAlignment] [varchar](50) NULL,
  [ShowSummaryRows] [bit] NULL,
  [SecondarySubTotalCriteria] [varchar](100) NULL,
  [SecondarySubTotalLabel] [varchar](200) NULL,
  [ColorSubTotalHeading] [bit] NULL,
  [TotalMustHaveValue] [bit] NULL,
 CONSTRAINT [PK_GenericReportsCoySetting] PRIMARY KEY CLUSTERED 
(
  [ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [GenericReports].[GenericReportsCoySetting] ADD  CONSTRAINT [DF__GenericRe__FitTo__7FE1A6F4]  DEFAULT ((0)) FOR [FitToPageWidthForPrint]
GO

