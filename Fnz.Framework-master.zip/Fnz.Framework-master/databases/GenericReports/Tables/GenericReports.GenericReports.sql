/***
<Table>
  <Description>The generic report worksheet</Description>
  <TableType>ClientConfig</TableType>
  <Columns>
    <Column Name="ID">
      <Description>Unique identifier for a GenericReports row</Description>
    </Column>
    <Column Name="ParamsType">
      <Description>Recordset or Simple TODO describe this further</Description>
    </Column>
    <Column Name="ClassName">
      <Description>Name of the assembly and class where the data will be obtained from</Description>
    </Column>
    <Column Name="FunctionName">
      <Description>Name of the method that will be called to obtain the data</Description>
    </Column>
    <Column Name="GenericReportID">
      <Description>The ID that is used as a foreign key when other tables refere to a generic report (they use this rather than the ID column)</Description>
    </Column>
    <Column Name="ReportType">
      <Description>The category of the report - this effects some formatting. Valid values are "BankRecSummary", "ClientMoneySummary", "GenericSummary", "Glossary", "Management"</Description>
    </Column>    
</Columns>
  <TOMLevel1>Reporting</TOMLevel1>
</Table>
***/
CREATE TABLE [GenericReports].[GenericReports](
  [ID] [int] IDENTITY(1,1) NOT FOR REPLICATION NOT NULL,
  [ParamsType] [varchar](9) NULL,
  [ClassName] [varchar](150) NULL,
  [FunctionName] [varchar](50) NULL,
  [GenericReportID] [int] NULL,
  [ReportType] [varchar](50) NULL,
 CONSTRAINT [PK_GenericReports] PRIMARY KEY CLUSTERED 
(
  [ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY]
) ON [PRIMARY]

