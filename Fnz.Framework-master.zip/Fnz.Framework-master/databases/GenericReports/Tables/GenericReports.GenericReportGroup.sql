/***
<Table>
  <Description>Defines the generic report worksheets that combined together make up the generic report workbook</Description>
  <TableType>ClientConfig</TableType>
  <Columns>
    <Column Name="id">
      <Description>Id of the generic report group</Description>
    </Column>
    <Column Name="Company">
      <Description>The company that uses this generic report group</Description>
    </Column>
    <Column Name="GenericReportGroupID">
      <Description>Used in the generic report task to identify a generic report to run</Description>
    </Column>
    <Column Name="GenericReportID">
      <Description>The generic report (worksheet) that belongs in this grouping</Description>
    </Column>
    <Column Name="PageOrder">
      <Description>Starting with 1 (and incrementing for each worksheet for a generic report group), it defines the order that this specific worksheet</Description>
    </Column>
  </Columns>
  <TOMLevel1>Reporting</TOMLevel1>
</Table>
***/
CREATE TABLE [GenericReports].[GenericReportGroup](
  [id] [int] IDENTITY(1,1) NOT FOR REPLICATION NOT NULL,
  [Company] [varchar](20) NOT NULL,
  [GenericReportGroupID] [int] NOT NULL,
  [GenericReportID] [int] NOT NULL,
  [PageOrder] [int] NOT NULL,
  CONSTRAINT [PK_GenericReportGroup] PRIMARY KEY CLUSTERED 
    (
      [id] ASC
    ) 
  WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY]
  ) ON [PRIMARY]
GO