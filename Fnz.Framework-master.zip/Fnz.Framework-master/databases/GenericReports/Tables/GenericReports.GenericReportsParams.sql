/***
<Table>
  <Description>Defines the fields that appear as the heading of the report and where the values are shown on the spreadsheet</Description>
  <TableType>ClientConfig</TableType>
  <Columns>
    <Column Name="ID">
      <Description>Unique identifier for a GenericReportsParams row</Description>
    </Column>
    <Column Name="Company">
      <Description>The company that these GenericReportsParams apply to. This is because there might be parameters for a company which might differ from the default</Description>
    </Column>
    <Column Name="GenericReportID">
      <Description>The generic report that these GenericReportsParams apply to</Description>
    </Column>
    <Column Name="Parameter">
      <Description>The name of the parameter</Description>
    </Column>
    <Column Name="ParameterOrder">
      <Description>The order the parameter appears on the generic report. Starts at 1 and must be different for each GenericReportsParams row for a generic report</Description>
    </Column>
    <Column Name="ParameterLabel">
      <Description>The label shown on the spreadsheet (null defaults to the parameter name)</Description>
    </Column>
    <Column Name="LabelPlacement">
      <Description>The Excel cell where the parameter label is to be laced e.g. K1 or B2:D2</Description>
    </Column>
    <Column Name="ParameterPlacement">
      <Description>The Excel cell where the parameter value is to be laced e.g. K1 or B2:D2</Description>
    </Column>
    <Column Name="LabelAlignment">
      <Description>Alignment of the Label cell - Left, Center or Right</Description>
    </Column>
    <Column Name="ParameterAlignment">
      <Description>Alignment of the Parameter cell - Left, Center or Right</Description>
    </Column>
    <Column Name="ParameterNumberFormat">
      <Description>The Excel format of the cell if the parameter is a number e.g. d-mmm-yyyy</Description>
    </Column>
    <Column Name="ParameterType">
      <Description>Indicates where the value of the parameter is to be found on the Dal Recordset - Param or InternalData (InternalData should no longer be used for any new reports). TODO - cannot see this being used in the Flexcel code properly - ut</Description>
    </Column>
    <Column Name="ParameterAlias">
      <Description>TODO - cannot see this being used in the Flexcel code</Description>
    </Column>
    <Column Name="HideIfEmpty">
      <Description>If true the value is not shown</Description>
    </Column>
    <Column Name="WrapText">
      <Description>1 if the cell that shows the value of the parameter is to be wrapped if the text is too big for the cell</Description>
    </Column>
</Columns>
  <TOMLevel1>Reporting</TOMLevel1>
</Table>
***/
CREATE TABLE [GenericReports].[GenericReportsParams](
  [ID] [int] IDENTITY(1,1) NOT FOR REPLICATION NOT NULL,
  [Company] [varchar](20) NULL,
  [GenericReportID] [int] NULL,
  [Parameter] [varchar](50) NULL,
  [ParameterOrder] [int] NULL,
  [ParameterLabel] [varchar](150) NULL,
  [LabelPlacement] [varchar](5) NULL,
  [ParameterPlacement] [varchar](20) NULL,
  [LabelAlignment] [varchar](6) NULL,
  [ParameterAlignment] [varchar](6) NULL,
  [ParameterNumberFormat] [varchar](20) NULL,
  [ParameterType] [varchar](12) NULL,
  [ParameterAlias] [varchar](50) NULL,
  [HideIfEmpty] [tinyint] NOT NULL,
  [WrapText] [bit] NULL,
 CONSTRAINT [PK_GenericReportsParams] PRIMARY KEY CLUSTERED 
(
  [ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [GenericReports].[GenericReportsParams] ADD  CONSTRAINT [DF_GenericReportsParams_HideIfEmpty]  DEFAULT ((0)) FOR [HideIfEmpty]
GO
