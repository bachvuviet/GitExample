/***
<Table>
  <Description>Defines the columns that appear on the generic report and their settings</Description>
  <TableType>ClientConfig</TableType>
  <Columns>
    <Column Name="ID">
      <Description>Unique identifier for the column</Description>
    </Column>
    <Column Name="GenericReportID">
      <Description>The generic report that this column belongs to</Description>
    </Column>
    <Column Name="Company">
      <Description>The company that this column belongs to. There might be different settings for a company which might differ from the default</Description>
    </Column>
    <Column Name="FieldName">
      <Description>Name of the field from the data source</Description>
    </Column>
    <Column Name="ColumnHeading">
      <Description>The heading text of the column</Description>
    </Column>
    <Column Name="NumberFormat">
      <Description>Any special Excel formatting for the vale cells for dates and numbers. See Excel - Format - Cells - Numbers - Custom for valid values.</Description>
    </Column>
    <Column Name="ColumnOrder">
      <Description>The order that the columns appear on the generic report (starts with 1 and increments by 1 for each column for that generic report)</Description>
    </Column>
    <Column Name="ShowSubTotals">
      <Description>1 to show subtotals, 0 to not show them</Description>
    </Column>
    <Column Name="ShowGrandTotal">
      <Description>1 to show a grand totl, 0 to not show it</Description>
    </Column>
    <Column Name="HeadingAlignment">
      <Description>Rigth, Center or Left</Description>
    </Column>
    <Column Name="ColumnWidth">
      <Description>The Excel width of the column e.g. 12.00</Description>
    </Column>
    <Column Name="WrapText">
      <Description>1 if the cell that shows the value is to be wrapped if the text is too big for the cell</Description>
    </Column>
    <Column Name="DefaultValue">
      <Description>the value to use for the column if there is not data for it. Null or empty indicates that no value would be shown for this column</Description>
    </Column>
    <Column Name="ShowTotalsOnly">
      <Description>If set to 1 then only the totals are shown</Description>
    </Column>
    <Column Name="HideColumnIfEmpty">
      <Description>If 1 and all the rows for this column are empty then this column is not shown</Description>
    </Column>
    <Column Name="ShowSecondarySubTotals">
      <Description>If 1 then secondary sub totals are shown TODO - cannot see this being used in the flexcel code at all!!! Can we delete this</Description>
    </Column>
    <Column Name="ValuesExcludedFromTotal">
      <Description>1 if the values in this column should not be included in the totals TODO - cannot see this being used in the flexcel code at all!!! Can we delete this</Description>
    </Column>
    <Column Name="Border">
      <Description>TODO - cannot see this being used in the flexcel code at all!!</Description>
    </Column>
  </Columns>
  <TOMLevel1>Reporting</TOMLevel1>
</Table>
***/
CREATE TABLE [GenericReports].[GenericReportsColumns](
  [ID] [int] IDENTITY(1,1) NOT FOR REPLICATION NOT NULL,
  [GenericReportID] [int] NULL,
  [Company] [varchar](20) NULL,
  [FieldName] [varchar](100) NULL,
  [ColumnHeading] [varchar](100) NULL,
  [NumberFormat] [varchar](30) NULL,
  [ColumnOrder] [int] NULL,
  [ShowSubTotals] [int] NULL,
  [ShowGrandTotal] [int] NULL,
  [HeadingAlignment] [varchar](6) NULL,
  [ColumnWidth] [decimal](18, 2) NULL,
  [WrapText] [int] NULL,
  [DefaultValue] [varchar](50) NULL,
  [ShowTotalsOnly] [int] NULL,
  [HideColumnIfEmpty] [tinyint] NOT NULL,
  [ShowSecondarySubTotals] [int] NULL,
  [ValuesExcludedFromTotal] [varchar](100) NULL,
  [Border] [varchar](10) NULL,
 CONSTRAINT [PK_GenericReportsColumns] PRIMARY KEY CLUSTERED 
(
  [ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [GenericReports].[GenericReportsColumns] ADD  CONSTRAINT [DF_GenericReportsColumns_ShowTotalsOnly]  DEFAULT ((0)) FOR [ShowTotalsOnly]
GO

ALTER TABLE [GenericReports].[GenericReportsColumns] ADD  CONSTRAINT [DF_GenericReportsColumns_HideColumnIfEmpty]  DEFAULT ((0)) FOR [HideColumnIfEmpty]
GO

ALTER TABLE [GenericReports].[GenericReportsColumns] ADD  CONSTRAINT [DF_GenericReportsColumns_ValuesExcludedFromTotal]  DEFAULT (NULL) FOR [ValuesExcludedFromTotal]
GO