/***
<Schema>
	<Description>Contains objects for the GenericReports</Description>
	<Service>GenericReports</Service>
	<Feature>GenericReports</Feature>
</Schema>
***/
CREATE SCHEMA [GenericReports] AUTHORIZATION [dbo]
GO