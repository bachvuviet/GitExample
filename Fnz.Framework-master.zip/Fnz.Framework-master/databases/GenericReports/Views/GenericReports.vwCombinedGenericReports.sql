CREATE VIEW [GenericReports].[vwCombinedGenericReports] AS
	SELECT HIGH.GenericReportID, HIGH.ParamsType, HIGH.ClassName, COY.ReportTitle, COY.Logo, COY.TotalLabel, COY.ShowHeadings, COY.Company, 
	COY.SubTotalLabel, COY.FontSize, COY.HeadingFontSize, COY.DataStartRow, COY.SubTotalCriteria, COY.TotalLabelPlacement, PAR.Parameter, 
	PAR.ParameterOrder, PAR.ParameterLabel, PAR.LabelPlacement, PAR.ParameterPlacement, PAR.LabelAlignment, PAR.ParameterAlignment, 
	PAR.ParameterNumberFormat, PAR.WrapText, HIGH.FunctionName, COY.HeaderText, COY.HeaderFontSize, COY.FooterText, COY.FooterFontSize, 
	COY.PageNumberAlignment, COY.PageNumberStyle, HIGH.ReportType, PAR.ParameterType, COY.SheetOrientation, COY.LogoAlignment, 
	COY.PageNumberFontSize, COY.HeadingFontStyle, COY.IncludeSubTotalFormatting, PAR.ParameterAlias, COY.StaticParameters, COY.ShowCount, 
	COY.ShowSubTotalHeading, COY.RepeatColumnHeaderCriteria, COY.AutoFormatColumnWidths, COY.FooterImage, COY.StaticText,
	COY.StaticTextPlacement, COY.StaticTextAlignment, COY.FitToPageWidthForPrint, COY.SheetLabel, COY.LeaveGap,
	COY.ReportTitleHorizontalAlignment, COY.ShowSummaryRows, COY.SecondarySubTotalCriteria, COY.SecondarySubTotalLabel, COY.ColorSubTotalHeading,
	COY.TotalMustHaveValue
	FROM GenericReports.GenericReports AS HIGH INNER JOIN
	GenericReports.GenericReportsCoySetting AS COY ON HIGH.GenericReportID = COY.GenericReportID LEFT OUTER JOIN
	GenericReports.GenericReportsParams AS PAR ON COY.GenericReportID = PAR.GenericReportID AND COY.Company = PAR.Company

GO