/***
<StoredProcedure>
    <Description>
		Insert a new row into the Archiving Audit Log stats table - this happens on archive process completion
	</Description>
    <Service>Archiving</Service>
    <Feature>Archiving</Feature>
</StoredProcedure>
***/
CREATE PROCEDURE [Archiving].[spInsertAuditLogStats] (@AuditLogId INT, @ElapsedTimeToArchiveInSeconds INT, @RowsDeleted INT) AS
BEGIN
	INSERT INTO [Archiving].[AuditLogStats]
	(AuditLogId, ElapsedTimeToArchiveInSeconds, RowsDeleted)
	SELECT @AuditLogId, @ElapsedTimeToArchiveInSeconds, @RowsDeleted
END