/***
<StoredProcedure>
    <Description>
		Delete ALL rows from XMLServicesLog between a given ID range. The FromDate/ToDate parameters are just additional safety measure.
	</Description>
    <Service>Archiving</Service>
    <Feature>Archiving</Feature>
</StoredProcedure>
***/
CREATE PROCEDURE [Archiving].[spDeleteXMLServicesLog] (@FromId as int, @ToID as int, @FromDate as datetime, @ToDate as datetime, @DeletedRowCount as int output) AS
BEGIN
	DELETE FROM Logging.Services
	WHERE Id >= @FromId
	AND Id <= @ToId
	AND LogTime >= @FromDate
	AND LogTime <= @ToDate
	SET @DeletedRowCount = @@ROWCOUNT
END