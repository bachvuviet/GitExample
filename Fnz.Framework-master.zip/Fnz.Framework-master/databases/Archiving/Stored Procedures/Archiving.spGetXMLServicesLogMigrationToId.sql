/***
<StoredProcedure>
    <Description>
		Retrieve the row with the newest ID that falls on a given day - used to prevent a large + unindexed lookup by logdate in the XMLServicesLog archiving task.
		i.e. if we have the following rows, @EndId would be set to 5 if we called the SP with @LogDate = '2015-06-29'
		logid | logdate
		------+-----------------
		  2   | 2015-06-28 11:00
		  3   | 2015-06-29 09:00
		  4   | 2015-06-29 12:00
		  5   | 2015-06-29 19:00
		  6   | 2015-06-30 01:00
	</Description>
    <Service>Archiving</Service>
    <Feature>Archiving</Feature>
</StoredProcedure>
***/
CREATE PROCEDURE [Archiving].[spGetXMLServicesLogMigrationToId] (@LogDate As DateTime, @EndId As Int OUTPUT) AS
BEGIN
	SET @EndId = COALESCE((SELECT TOP 1 Id FROM Logging.ServicesLegacy WHERE LogTime < @LogDate ORDER BY Id DESC), -1)
END