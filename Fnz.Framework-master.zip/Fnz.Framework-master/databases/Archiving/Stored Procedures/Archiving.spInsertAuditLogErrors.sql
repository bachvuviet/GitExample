/***
<StoredProcedure>
    <Description>
		Insert a new row into the Archiving Audit Log stats table - this happens on archive process completion
	</Description>
    <Service>Archiving</Service>
    <Feature>Archiving</Feature>
</StoredProcedure>
***/
CREATE PROCEDURE [Archiving].[spInsertAuditLogErrors] (@AuditLogId INT, @ErrorString VARCHAR(256)) AS
BEGIN
	INSERT INTO [Archiving].[AuditLogErrors]
	(AuditLogId, ErrorString)
	SELECT @AuditLogId, @ErrorString
END