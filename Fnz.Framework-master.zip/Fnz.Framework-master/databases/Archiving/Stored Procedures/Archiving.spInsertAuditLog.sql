/***
<StoredProcedure>
    <Description>
		Insert a new row into the Archiving Audit Log table
	</Description>
    <Service>Archiving</Service>
    <Feature>Archiving</Feature>
</StoredProcedure>
***/
CREATE PROCEDURE [Archiving].[spInsertAuditLog] (@ProcessName as VARCHAR(50), @ArchiveDate as SMALLDATETIME, @AuditLogId as int output) AS
BEGIN
	INSERT INTO [Archiving].[AuditLog]
	(ProcessName, ArchiveDate)
	SELECT @ProcessName, @ArchiveDate
	SET @AuditLogId = SCOPE_IDENTITY();
END