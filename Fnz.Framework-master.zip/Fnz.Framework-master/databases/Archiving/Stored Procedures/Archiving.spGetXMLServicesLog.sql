/***
<StoredProcedure>
    <Description>
		Retrieve at most @NumberOfRows from XMLServicesLog between the given From\ToId and From\ToDate ranges (the latter is a failsafe
		to prevent any massive errors occurring - the lookup is primarily by ID, calculated before the SP is called).

		The NULL selects are because BCP requires a format file, and we've removed a handful of columns - which may not have propagated
		through all databases so they may be present in the format file we generate.
	</Description>
    <Service>Archiving</Service>
    <Feature>Archiving</Feature>
</StoredProcedure>
***/
CREATE PROCEDURE [Archiving].[spGetXMLServicesLog] (@NumberOfRows As int, @FromId as int, @ToID as int, @FromDate as datetime, @ToDate as datetime) AS
BEGIN
	SELECT TOP (@NumberOfRows) Id, LogTime,Request,Response,Url,UserId,ServiceName,OperationName,Method,ServiceReference,ResponseTimeInMs,StatusCode,NULL as WizardSessionId,NULL as AccountNumber,RequestId,NULL as SessionId,ApplicationName,NULL as LogGuid,Host,ErrorMessage,OnBehalfOf
	FROM Logging.Services
	WHERE Id >= @FromId 
	AND Id <= @ToId
	AND LogTime >= @FromDate
	AND LogTime < @ToDate
	ORDER BY Id
END