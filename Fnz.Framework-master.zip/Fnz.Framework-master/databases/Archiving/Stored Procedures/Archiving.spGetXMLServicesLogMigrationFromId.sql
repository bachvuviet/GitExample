/***
<StoredProcedure>
    <Description>
		Retrieve the row with the oldest ID for a given day - used to prevent a large + unindexed lookup by logdate in the XMLServicesLog archiving task.
		i.e. if we have the following rows, @EndId would be set to 3 if we called the SP with @LogDate = '2015-06-29'
		logid | logdate
		------+-----------------
		  2   | 2015-06-28 11:00
		  3   | 2015-06-29 09:00
		  4   | 2015-06-29 12:00
		  5   | 2015-06-29 19:00
		  6   | 2015-06-30 01:00
	</Description>
    <Service>Archiving</Service>
    <Feature>Archiving</Feature>
</StoredProcedure>
***/
CREATE PROCEDURE [Archiving].[spGetXMLServicesLogMigrationFromId] (@LogDate As DateTime, @StartId As Int OUTPUT) AS
BEGIN
	SET @StartId = COALESCE((SELECT TOP 1 Id FROM Logging.ServicesLegacy WHERE LogTime >= @LogDate ORDER BY Id), -1)
END