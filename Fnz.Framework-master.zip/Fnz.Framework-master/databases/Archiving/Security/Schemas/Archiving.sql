/***
<Schema>
	<Description>Contains objects related to the task of archiving DB tables in the HCP filestore</Description>
	<Service>Services</Service>
	<Feature>Archiving</Feature>
</Schema>
***/
CREATE SCHEMA [Archiving] AUTHORIZATION [dbo]
GO
