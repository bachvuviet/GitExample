/***
<View>
	<Description>
		View to collate the information on archiving runs from Archiving.AuditLog, Archiving.AuditStats and Archiving.AuditLogErrors.
		A "Status" can be derived from the state of these tables, and has been included to make it easier to see what is going on:
		* If we have an error string, the process has failed somehow ("Failed")
		* Otherwise if we don't have anything in the AuditLogStats table (which is populated when the archive process completes) it's "In Progress"
		* Otherwise it was succesful and has status "Completed"
		This should NOT be called from code.
	</Description>
</View>
***/
CREATE VIEW Archiving.vwAuditLogDetail
AS
	SELECT AuditLog.AuditLogId,
		AuditLog.ProcessName, 
		AuditLog.ArchiveDate,
		CASE 
			WHEN AuditLogErrors.ErrorString IS NOT NULL THEN 'Failed'
			WHEN AuditLogStats.RowsDeleted IS NULL THEN 'In Progress'
			ELSE 'Completed'
		END AS [Status],
		AuditLogStats.ElapsedTimeToArchiveInSeconds,
		AuditLogStats.RowsDeleted,
		AuditLogErrors.ErrorString
	FROM Archiving.AuditLog AuditLog
	LEFT JOIN Archiving.AuditLogStats AuditLogStats on AuditLogStats.AuditLogId = AuditLog.AuditLogId
	LEFT JOIN Archiving.AuditLogErrors AuditLogErrors on AuditLogErrors.AuditLogId = AuditLog.AuditLogId