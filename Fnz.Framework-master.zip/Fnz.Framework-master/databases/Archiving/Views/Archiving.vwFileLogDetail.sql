/***
<View>
	<Description>
		View to make it easier to tie the files uploaded to HCP back to the archive process.
		This should NOT be called from code
	</Description>
</View>
***/
CREATE VIEW Archiving.vwFileLogDetail
AS
	SELECT AuditLog.AuditLogId,
		AuditLog.ProcessName, 
		AuditLog.ArchiveDate,
		FileLog.[FileName],
		FileLog.MinId,
		FileLog.MaxId,
		FileLog.RowsArchived,
		FileLog.DateTimeArchived
	FROM Archiving.AuditLog AuditLog
	LEFT JOIN Archiving.FileLog FileLog  on FileLog.AuditLogId = AuditLog.AuditLogId