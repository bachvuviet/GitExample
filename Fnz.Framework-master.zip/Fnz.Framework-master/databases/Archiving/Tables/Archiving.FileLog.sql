/***
<Table>
	<Description>Archiving file log - one row each archive file uploaded to HCP</Description>
	<TableType>Transaction</TableType>
</Table>
***/
CREATE TABLE Archiving.FileLog 
(
	[FileLogId] INT NOT NULL IDENTITY(1,1),
	[FileName] VARCHAR(100),
	[AuditLogId] [int] NOT NULL ,
	[MinId] INT NOT NULL,
	[MaxId] INT NOT NULL,
	[RowsArchived] INT NOT NULL,
	[DateTimeArchived] DATETIME NOT NULL,
	CONSTRAINT [PK_FileLog] PRIMARY KEY CLUSTERED ([FileLogId]),
	CONSTRAINT [FK_AuditLogId] FOREIGN KEY ([AuditLogId]) REFERENCES Archiving.AuditLog(AuditLogId),
)