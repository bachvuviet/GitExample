/***
<Table>
	<Description>Error log for archive processes - not necessarily always present, only when a problem occurs during archiving</Description>
	<TableType>Transaction</TableType>
</Table>
***/
CREATE TABLE Archiving.AuditLogErrors
(
	[AuditLogId] INT NOT NULL,
	[ErrorString] varchar(256) NOT NULL,
	CONSTRAINT [PK_AuditLogErrors] PRIMARY KEY CLUSTERED ([AuditLogId]),
	CONSTRAINT [FK_AuditLogErrorId] FOREIGN KEY (AuditLogId) REFERENCES Archiving.AuditLog(AuditLogId),
)