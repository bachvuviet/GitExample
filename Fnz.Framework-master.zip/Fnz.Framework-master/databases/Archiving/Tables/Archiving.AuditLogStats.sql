/***
<Table>
	<Description>Audit log for archive completion - one row each Archiving.AuditLog entry, created on archive process completion </Description>
	<TableType>Transaction</TableType>
</Table>
***/
CREATE TABLE Archiving.AuditLogStats
(
	[AuditLogId] INT NOT NULL,
	[ElapsedTimeToArchiveInSeconds] INT NOT NULL,
	[RowsDeleted] INT NOT NULL,
	CONSTRAINT [PK_AuditLogStats] PRIMARY KEY CLUSTERED ([AuditLogId]),
	CONSTRAINT [FK_AuditLogStatsId] FOREIGN KEY (AuditLogId) REFERENCES Archiving.AuditLog(AuditLogId),
)