/***
<Table>
	<Description>Audit log for archiving - one row each time a process runs</Description>
	<TableType>Transaction</TableType>
</Table>
***/
CREATE TABLE Archiving.AuditLog 
(
	[AuditLogId] INT NOT NULL IDENTITY(1,1),
	[ProcessName] VARCHAR(50) NOT NULL,
	[ArchiveDate] SMALLDATETIME NOT NULL,
	CONSTRAINT [PK_AuditLog] PRIMARY KEY CLUSTERED ([AuditLogId]),
	CONSTRAINT [FK_ProcessName] FOREIGN KEY ([ProcessName]) REFERENCES Archiving.Processes([ProcessName]),
)