/***
<Table>
	<Description>Used to specify run-time configurable parameters for DB table archiving</Description>
	<TableType>Transaction</TableType>
</Table>
***/
CREATE TABLE Archiving.Migrations 
(
	[ProcessName] VARCHAR(50) NOT NULL,
	[RowsPerFile] INT NOT NULL CHECK ([RowsPerFile]>0),
	[ArchivingOrder] INT NOT NULL,
	[Enabled] BIT NOT NULL,
	[NextArchiveDate] SMALLDATETIME NOT NULL,
	[FinalArchiveDate] SMALLDATETIME NOT NULL,
	CONSTRAINT [PK_Migrations] PRIMARY KEY CLUSTERED ([ProcessName]),
    CONSTRAINT [UIDX_MigrationArchivingOrder] UNIQUE ([ArchivingOrder])
)