
The folders in here are "logical" database and do not reflect how they are or should be deployed.

