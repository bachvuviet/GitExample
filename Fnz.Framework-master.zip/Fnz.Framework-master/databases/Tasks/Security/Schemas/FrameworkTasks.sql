/*
<Schema>
	<Description>Contains objects related to database versioning and deployment</Description>
	<Service>Framework</Service>
	<Feature>TaskSchedulers</Feature>
</Schema>
*/
CREATE SCHEMA [FrameworkTasks] AUTHORIZATION [dbo]
GO
