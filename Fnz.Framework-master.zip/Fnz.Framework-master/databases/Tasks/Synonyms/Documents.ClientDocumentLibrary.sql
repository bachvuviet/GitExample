/***
<Synonym>
	<Description>Contains client's documents</Description>
	<Columns>
		<Column Name="Id">
			<Description>Id of the client's document</Description>
			<DataType>int</DataType>
		</Column>
		<Column Name="CLAccountId">
			<Description>Account Id</Description>
			<DataType>Varchar(20)</DataType>
		</Column>
		<Column Name="Filename">
			<Description>Filename of the document (if not generated via task request)</Description>
			<DataType>Varchar(100)</DataType>
		</Column>
		<Column Name="TaskRequestId">
			<Description>Id of the task request that generated the client's document</Description>
			<DataType>int</DataType>
		</Column>
		<Column Name="ClientId">
			<Description>Id of client</Description>
			<DataType>int</DataType>
		</Column>
		<Column Name="DocumentName">
			<Description>Name of document</Description>
			<DataType>Varchar(150)</DataType>
		</Column>
		<Column Name="DateTimeAdded">
			<Description>DateTime of when document was added</Description>
			<DataType>datetime</DataType>
		</Column>
		<Column Name="Category">
			<Description>Category of document</Description>
			<DataType>Varchar(50)</DataType>
		</Column>
		<Column Name="DocStatus">
			<Description>Document status</Description>
			<DataType>Varchar(50)</DataType>
		</Column>
	</Columns>
</Synonym>
***/
CREATE SYNONYM [Documents].[ClientDocumentLibrary] FOR [Documents].[dbo].[ClientDocumentLibrary]
GO
