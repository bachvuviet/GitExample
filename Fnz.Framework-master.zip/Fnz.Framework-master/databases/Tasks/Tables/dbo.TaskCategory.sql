/***
<Table>
  <Description>Task Management</Description>
  <TableType>SystemSetting</TableType>
  <Columns>
    <Column Name="ID">
      <Description>Identity Column</Description>
    </Column>
    <Column Name="TaskCategory">
      <Description>Task Category definition</Description>
    </Column>
  </Columns>
  <TOMLevel1>Services</TOMLevel1>
  <FunctionalStream>PE - Technical</FunctionalStream>
</Table>
***/
CREATE TABLE [dbo].[TaskCategory]
(
[ID] [int] NOT NULL IDENTITY(1, 1),
[TaskCategory] [varchar] (20) NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[TaskCategory] ADD CONSTRAINT [PK_TaskCategory] PRIMARY KEY CLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE UNIQUE NONCLUSTERED INDEX [IDX_TaskCategory] ON [dbo].[TaskCategory] ([TaskCategory]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
