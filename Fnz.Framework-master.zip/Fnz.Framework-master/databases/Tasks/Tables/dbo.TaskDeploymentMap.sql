/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<Table>
    <Description>C32B3F205CC1A00D81E637E815A4F9B0</Description>
	<TableType>Logging|Static|Transaction|Config|ETL</TableType>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</Table>
***/
CREATE TABLE [dbo].[TaskDeploymentMap]
(
[TaskId] [int] NOT NULL,
[Deployment] [varchar] (3) NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[TaskDeploymentMap] ADD CONSTRAINT [FK__TaskDeplo__TaskI__2CB38214] FOREIGN KEY ([TaskId]) REFERENCES [dbo].[Tasks2] ([ID])
GO
