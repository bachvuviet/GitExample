/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<Table>
    <Description>D1875EE014FFF46A6246ED7C1DF54817</Description>
	<TableType>Logging|Static|Transaction|Config|ETL</TableType>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</Table>
***/
CREATE TABLE [dbo].[ReleaseEnvironments]
(
[ID] [int] NOT NULL IDENTITY(1, 1),
[Environment] [varchar] (50) NULL,
[Multi] [tinyint] NULL,
[TestEnvironment] [tinyint] NULL,
[DisplayOrder] [int] NULL,
[ShowWarning] [tinyint] NULL,
[ReleaseDestination] [tinyint] NULL CONSTRAINT [DF_ReleaseEnvironments_ReleaseDestination] DEFAULT ((0))
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[ReleaseEnvironments] ADD CONSTRAINT [PK_ReleaseEnvironments_1] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
