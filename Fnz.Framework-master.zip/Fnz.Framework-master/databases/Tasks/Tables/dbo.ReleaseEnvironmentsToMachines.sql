/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<Table>
    <Description>A65AED38D240DABD7D98E4CA0E3997FA</Description>
	<TableType>Logging|Static|Transaction|Config|ETL</TableType>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</Table>
***/
CREATE TABLE [dbo].[ReleaseEnvironmentsToMachines]
(
[ID] [int] NOT NULL IDENTITY(1, 1),
[MachineID] [int] NULL,
[EnvironmentID] [int] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[ReleaseEnvironmentsToMachines] ADD CONSTRAINT [PK_ReleaseEnvironmentsToMachines] PRIMARY KEY NONCLUSTERED  ([ID]) ON [PRIMARY]
GO
CREATE UNIQUE CLUSTERED INDEX [IX_EnvMachine] ON [dbo].[ReleaseEnvironmentsToMachines] ([MachineID], [EnvironmentID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[ReleaseEnvironmentsToMachines] ADD CONSTRAINT [FK_ReleaseEnvironmentsToMachines_ReleaseEnvironments] FOREIGN KEY ([EnvironmentID]) REFERENCES [dbo].[ReleaseEnvironments] ([ID])
GO
ALTER TABLE [dbo].[ReleaseEnvironmentsToMachines] ADD CONSTRAINT [FK_ReleaseEnvironmentsToMachines_ReleaseMachines] FOREIGN KEY ([MachineID]) REFERENCES [dbo].[ReleaseMachines] ([ID])
GO
