/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<Table>
    <Description>1ECB056AECD279CE7B1653B37940BCB9</Description>
	<TableType>Logging|Static|Transaction|Config|ETL</TableType>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</Table>
***/
CREATE TABLE [dbo].[TaskLog]
(
[LogID] [int] NOT NULL IDENTITY(1, 1),
[TaskID] [int] NULL,
[LogDateTime] [datetime] NOT NULL CONSTRAINT [DF_TaskLog_LogDateTime] DEFAULT (getdate()),
[TaskDate] [datetime] NULL,
[Parameters] [varchar] (8000) NULL,
[Status] [varchar] (50) NULL,
[Finish] [datetime] NULL,
[LoaderID] [smallint] NULL,
[RequestID] [int] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[TaskLog] ADD CONSTRAINT [PK_TaskLog] PRIMARY KEY CLUSTERED  ([LogID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
