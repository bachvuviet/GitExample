/***
<Table>
  <Description>Defines tasks dependencies</Description>
  <TableType>SystemSetting</TableType>
  <Columns>
    <Column Name="task_id">
      <Description>task_id - [tasks2]</Description>
    </Column>
    <Column Name="pretask_id">
      <Description>pretask_id - [Tasks2]</Description>
    </Column>
  </Columns>
  <TOMLevel1>Services</TOMLevel1>
  <FunctionalStream>PE - Technical</FunctionalStream>
</Table>
***/
CREATE TABLE [dbo].[Prereq_Tasks]
(
[task_id] [int] NOT NULL,
[pretask_id] [int] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Prereq_Tasks] ADD CONSTRAINT [PK_prereq_tasks_1__15] PRIMARY KEY CLUSTERED  ([task_id], [pretask_id]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [idx_pretaskid] ON [dbo].[Prereq_Tasks] ([pretask_id]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
