-- Stops the running of the same task twice at the same time.
/***
<Table>
	<Description>Logs the tasks that were running on a loader when it died</Description>
	<TableType>Logging</TableType>
</Table>
***/
CREATE TABLE FrameworkTasks.TasksRunningWhenLoaderDiedLog
(
	[Id] [INT] NOT NULL IDENTITY(1,1) PRIMARY KEY CLUSTERED,
	[TaskId] [INT] NOT NULL FOREIGN KEY REFERENCES dbo.Tasks2(Id),
	[TaskRequestId] [INT] NULL FOREIGN KEY REFERENCES dbo.TaskRequests(Id),
	[LoaderId] [INT] NOT NULL FOREIGN KEY REFERENCES dbo.Loaders(Id),
	[StartedRunning] [DATETIME] NOT NULL,
	[Released] [DATETIME] NOT NULL DEFAULT (GETDATE())
)

create nonclustered index idx_taskId on FrameworkTasks.TasksRunningWhenLoaderDiedLog(TaskId)
go