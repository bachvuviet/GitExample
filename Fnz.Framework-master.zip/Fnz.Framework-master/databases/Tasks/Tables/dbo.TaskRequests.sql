/***
<Table>
  <Description>A list of all system or user generated requests to run Ad-Hoc tasks</Description>
  <TableType>Transaction</TableType>
</Table>
***/
CREATE TABLE [dbo].[TaskRequests]
(
[Id] [int] NOT NULL IDENTITY(1, 1) NOT FOR REPLICATION,
[TaskId] [int] NOT NULL,
[Parameters] [varchar] (8000) NULL CONSTRAINT [DF_TaskRequests_parameters] DEFAULT (''),
[Status] [varchar] (20) NULL,
[Priority] [int] NULL CONSTRAINT [DF_TaskRequests_priority] DEFAULT ((0)),
[ErrorDescription] [varchar] (255) NULL,
[Start] [datetime] NULL,
[Finish] [datetime] NULL,
[RequestClientID] [int] NULL,
[ClAccountID] [varchar] (20) NULL,
[CallState] [varchar] (8000) NULL,
[RecipientAddress] [varchar] (100) NULL,
[RequestDateTime] [datetime] NULL CONSTRAINT [DF_TaskRequests_RequestDateTime] DEFAULT (getdate()),
[Parameters2] [varchar] (255) NULL,
[FileName] [varchar] (100) NULL,
[Company] [varchar] (30) NULL CONSTRAINT [DF_TaskRequests_Company] DEFAULT ('FNZS'),
[TransactionId] [varchar] (255) NULL,
[RetriesRemaining] [int] NULL,
[NextAttempt] [datetime] NULL CONSTRAINT [DF_TaskRequests_LastAttemptDateTime] DEFAULT ('1/1/1900'),
[AttemptCount] [int] NULL,
[ReportId] [int] NULL,
[OwnerName] [varchar] (50) NULL,
[OwnerType] [varchar] (20) NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[TaskRequests] ADD CONSTRAINT [PK_TaskRequests2] PRIMARY KEY CLUSTERED  ([id]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [idx_ClAccountID] ON [dbo].[TaskRequests] ([ClAccountID], [taskid]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [idx_RequestClientID] ON [dbo].[TaskRequests] ([FileName], [RequestClientID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [idx_RequestDateTime] ON [dbo].[TaskRequests] ([RequestDateTime], [taskid]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [idx_status] ON [dbo].[TaskRequests] ([status]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [idx_Search] ON [dbo].[TaskRequests] ([taskid], [status]) ON [PRIMARY]
GO
