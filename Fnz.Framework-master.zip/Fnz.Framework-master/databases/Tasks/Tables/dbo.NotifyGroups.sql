/***
<Table>
  <Description>Obsolete. Do not use.Alert NotificationRemove John from the list</Description>
  <TableType>SystemSetting</TableType>
  <Columns>
    <Column Name="ID">
      <Description>Identity Column</Description>
    </Column>
    <Column Name="GroupID">
      <Description>Identifier field</Description>
    </Column>
    <Column Name="RecipientName">
      <Description>Name of Recipient</Description>
    </Column>
    <Column Name="RecipientEmail">
      <Description>Email of Recipient</Description>
    </Column>
  </Columns>
  <TOMLevel1>Services</TOMLevel1>
  <FunctionalStream>PE - FNZ One</FunctionalStream>
</Table>
***/
CREATE TABLE [dbo].[NotifyGroups]
(
[ID] [int] NOT NULL IDENTITY(1, 1),
[GroupID] [int] NOT NULL CONSTRAINT [DF_NotifyGroups_GroupID] DEFAULT ((1)),
[RecipientName] [varchar] (50) NOT NULL CONSTRAINT [DF_NotifyGroups_RecipientName] DEFAULT ('Adrian'),
[RecipientEmail] [varchar] (50) NOT NULL CONSTRAINT [DF_NotifyGroups_RecipientEmail] DEFAULT ('adrian.durham@csfb.com')
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[NotifyGroups] ADD CONSTRAINT [PK_NotifyGroups] PRIMARY KEY CLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [idx_groupid] ON [dbo].[NotifyGroups] ([GroupID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
