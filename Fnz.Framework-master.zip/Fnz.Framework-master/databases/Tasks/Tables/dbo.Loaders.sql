/***
<Table>
  <Description>Task Management</Description>
  <TableType>EnvironmentConfig</TableType>
  <Columns>
    <Column Name="id">
      <Description>Identity Column</Description>
    </Column>
    <Column Name="HostName">
      <Description>Host Name of loader</Description>
    </Column>
    <Column Name="Type">
      <Description>Loader Type</Description>
    </Column>
    <Column Name="Enabled">
      <Description>Is loader Enabled</Description>
    </Column>
    <Column Name="Status">
      <Description>Loader Status</Description>
    </Column>
    <Column Name="Client">
      <Description>Client application executed on the loader</Description>
    </Column>
    <Column Name="SpecificPermissioning">
      <Description>Reqire Specific Permissioning</Description>
    </Column>
    <Column Name="ClientTaskID">
      <Description>Client Task ID - [tasks2]</Description>
    </Column>
    <Column Name="CallState">
      <Description>Call State in a XML format</Description>
    </Column>
    <Column Name="TaskParameters">
      <Description>Task Parameters in XML format</Description>
    </Column>
    <Column Name="AllocationOrder">
      <Description>Order of loader allocation</Description>
    </Column>
    <Column Name="TypePriority">
      <Description>Type Priority - DLL/EXCEL</Description>
    </Column>
    <Column Name="SchedulingPrecedence">
      <Description>Scheduling Precedence - dependency</Description>
    </Column>
    <Column Name="ConsecutiveFailures">
      <Description>Consecutive Failures indicator</Description>
    </Column>
    <Column Name="ProcessId">
      <Description>Process Id on server</Description>
    </Column>
    <Column Name="ClientTaskRequestId">
      <Description>ClientTaskRequestId - [TaskRequests]</Description>
    </Column>
  </Columns>
  <TOMLevel1>Services</TOMLevel1>
  <FunctionalStream>PE - Technical</FunctionalStream>
</Table>
***/
CREATE TABLE [dbo].[Loaders]
(
[id] [int] NOT NULL IDENTITY(1, 1),
[HostName] [varchar] (30) NULL,
[Type] [char] (10) NULL,
[Enabled] [varchar] (5) NULL,
[Status] [varchar] (20) NULL,
[Client] [varchar] (255) NULL CONSTRAINT [DF_Loaders_Client] DEFAULT ('None'),
[SpecificPermissioning] [int] NULL CONSTRAINT [DF_Loaders_SpecificPermissioning] DEFAULT ((0)),
[ClientTaskID] [int] NULL,
[CallState] [varchar] (max) NULL,
[TaskParameters] [varchar] (max) NULL,
[AllocationOrder] [int] NULL CONSTRAINT [DF_Loaders_AllocationOrder] DEFAULT ((0)),
[TypePriority] [varchar] (50) NULL,
[SchedulingPrecedence] [varchar] (20) NULL,
[ConsecutiveFailures] [int] NULL,
[ProcessId] [int] NULL,
[ClientTaskRequestId] [int] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[Loaders] ADD CONSTRAINT [PK_Loaders] PRIMARY KEY CLUSTERED  ([id]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
