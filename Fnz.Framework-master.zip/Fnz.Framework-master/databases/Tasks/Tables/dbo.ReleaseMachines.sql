/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<Table>
    <Description>4D43F57B09D4ED5D4FF607CF9EA65AC1</Description>
	<TableType>Logging|Static|Transaction|Config|ETL</TableType>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</Table>
***/
CREATE TABLE [dbo].[ReleaseMachines]
(
[ID] [int] NOT NULL IDENTITY(1, 1),
[Machine] [varchar] (50) NULL,
[MachineType] [varchar] (50) NULL,
[Cluster] [varchar] (50) NULL,
[IPAddress] [varchar] (50) NULL,
[Provider] [varchar] (20) NULL
) ON [PRIMARY]
GO
CREATE UNIQUE NONCLUSTERED INDEX [PK_ReleaseMachines] ON [dbo].[ReleaseMachines] ([ID]) ON [PRIMARY]
GO
CREATE UNIQUE CLUSTERED INDEX [IX_Machine] ON [dbo].[ReleaseMachines] ([Machine]) ON [PRIMARY]
GO
