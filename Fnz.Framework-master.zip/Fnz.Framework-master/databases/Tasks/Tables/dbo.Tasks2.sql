/***
<Table>
  <Description>Task Management</Description>
  <TableType>EnvironmentConfig</TableType>
  <Columns>
    <Column Name="ID">
      <Description>Identity Column</Description>
    </Column>
    <Column Name="task_name">
      <Description>Task Name:     Should Follow Format - [Describe task in a few concise words] [Wrap Platform] [Frequency] [Presentation Format]</Description>
    </Column>
    <Column Name="task_type">
      <Description>Task Type:     [DLL/EXCEL]</Description>
    </Column>
    <Column Name="task_category">
      <Description>Task Category: [Alerts/Notifications, AssetWatch, Cash, Cash Payments, Cash Reconciliation, Customer/User Mgmt, Document Management, Error Management, FTP/File Transfer, Margin Lending, Market Data/Research, Migration, Orders/Trading, Portfolio Management, Risk &amp; Compliance, Services &amp; Fees, Testing, Workflow</Description>
    </Column>
    <Column Name="classname">
      <Description>Class/report Name</Description>
    </Column>
    <Column Name="rpt_email">
      <Description>Email the report</Description>
    </Column>
    <Column Name="rpt_print">
      <Description>Print the report</Description>
    </Column>
    <Column Name="enabled">
      <Description>Is task enabled</Description>
    </Column>
    <Column Name="time">
      <Description>Time for task to Run (Note: Not Needed for Interdaily and Ad-Hoc Tasks)</Description>
    </Column>
    <Column Name="frequency">
      <Description>Frequency:     [Ad-Hoc (A), Daily (W), Intraday (I), Monthly (M), Quarterly (Q), Yearly (Y)]</Description>
    </Column>
    <Column Name="mon">
      <Description>Mon [1/0]</Description>
    </Column>
    <Column Name="tue">
      <Description>Tue [1/0]</Description>
    </Column>
    <Column Name="wed">
      <Description>Wed [1/0]</Description>
    </Column>
    <Column Name="thu">
      <Description>Thu [1/0]</Description>
    </Column>
    <Column Name="fri">
      <Description>Fri [1/0]</Description>
    </Column>
    <Column Name="sat">
      <Description>Sat [1/0]</Description>
    </Column>
    <Column Name="sun">
      <Description>Sun [1/0]</Description>
    </Column>
    <Column Name="publicholiday">
      <Description>Public Holiday [1/0]</Description>
    </Column>
    <Column Name="first_last">
      <Description>First_last - [F/L] Run on the First or Last Day of the Month</Description>
    </Column>
    <Column Name="day_bday1">
      <Description>For (Monthly) task, this is a switch saying whether a task is to run on a day or business-day in a month.</Description>
    </Column>
    <Column Name="day_bday2">
      <Description>For (Monthly) task, this is a switch saying whether a task is to run on a day or business-day in a month.</Description>
    </Column>
    <Column Name="description">
      <Description>Description:   Please include types of users/accounts/LEs affected, whether tasks makes any updates to the system</Description>
    </Column>
    <Column Name="completed">
      <Description>time the task completed by last time</Description>
    </Column>
    <Column Name="pubid">
      <Description>Distribution lists are used for Client Research/Report Distribution by Research Administrators, Task Report Distribution by tasks which send emails upon their completion. This is controlled by the pubid field in taskdb.dbo.tasks2, which contains the settings for tasks, and Ad Hoc Client Lists. The fieldconstant for the pubid field in tasks2 is is listid.</Description>
    </Column>
    <Column Name="newpubid">
      <Description>Distribution lists are used for Client Research/Report Distribution by Research Administrators, Task Report Distribution by tasks which send emails upon their completion. This is controlled by the pubid field in taskdb.dbo.tasks2, which contains the settings for tasks, and Ad Hoc Client Lists. The fieldconstant for the pubid field in tasks2 is is listid.</Description>
    </Column>
    <Column Name="computer">
      <Description>Host the task can be executed on [NULL means can run on any host]</Description>
    </Column>
    <Column Name="status">
      <Description>Status [running/complete/Failed]</Description>
    </Column>
    <Column Name="errordescription">
      <Description>error message</Description>
    </Column>
    <Column Name="procedurename">
      <Description>Procedure/function Name</Description>
    </Column>
    <Column Name="intradayinterval">
      <Description>Intraday Interval:  Number of Minutes between Task Being Re-run</Description>
    </Column>
    <Column Name="intradayopen">
      <Description>Intraday Open:      Time of day Intraday Task should Start</Description>
    </Column>
    <Column Name="intradayclose">
      <Description>Intraday Close:     Time of day Intraday Task should End</Description>
    </Column>
    <Column Name="rerunfrom">
      <Description>rerun task from date</Description>
    </Column>
    <Column Name="rerunto">
      <Description>rerun task to date</Description>
    </Column>
    <Column Name="parameters">
      <Description>Parameters:    (Any parameters which are sent to the task.  Please ensure that task can accept parameters, when appropriate, which allow it to be re-run if task fails completely, partially, or fails to run in the given time frame)</Description>
    </Column>
    <Column Name="maxretries">
      <Description>Max Retries after failure (MaxRetries)</Description>
    </Column>
    <Column Name="retryinterval">
      <Description>Number of seconds between retries (RetryInterval)</Description>
    </Column>
    <Column Name="lastattempt">
      <Description>last time the task scheduler attempt to run the task</Description>
    </Column>
    <Column Name="notifygroupid">
      <Description>email Group ID to Notify</Description>
    </Column>
    <Column Name="busytimeout">
      <Description>Maximum number of seconds Task Should Run Given expected Account and Customer Load outlined in NFR is present (BusyTimeout)</Description>
    </Column>
    <Column Name="numberofretries">
      <Description>number of retries while failure</Description>
    </Column>
    <Column Name="lasttimeoutnotify">
      <Description>Datetime of Last Time out Notified</Description>
    </Column>
    <Column Name="reenableinterval">
      <Description>Time after Maximum Number of Failures that Task is Allowed to Restart (ReEnableInterval)</Description>
    </Column>
    <Column Name="enablefrom">
      <Description>Date/Time the task become avaliable</Description>
    </Column>
    <Column Name="fileextension">
      <Description>File Extension: If Task Produces File, what Extension is appropriate</Description>
    </Column>
    <Column Name="taskOwner">
      <Description>business owner</Description>
    </Column>
    <Column Name="WordTemplateID">
      <Description>Word document WordTemplateID</Description>
    </Column>
    <Column Name="WordEnabled">
      <Description>Word document Enabled</Description>
    </Column>
    <Column Name="Notes">
      <Description>Notes:         Please note any tasks or other events which must occur before this task can be executed and update taskdb..prereq_tasks table accordingly</Description>
    </Column>
    <Column Name="LibraryKeywords">
      <Description>Client document Library Key Words</Description>
    </Column>
    <Column Name="LibraryCategory">
      <Description>Client document Library Category</Description>
    </Column>
    <Column Name="ProdEnabled">
      <Description>enable it in Production</Description>
    </Column>
    <Column Name="AllowConcurrent">
      <Description>Is Concurrent Allowed</Description>
    </Column>
    <Column Name="MustCompleteBy">
      <Description>MustCompleteBy:  Time of Day Task Must Complete By</Description>
    </Column>
    <Column Name="Reset">
      <Description>Reset the task</Description>
    </Column>
    <Column Name="TaskPriority">
      <Description>TaskPriority:  [appropriate Task Priority for Tasks between ad-hoc and scheduled]</Description>
    </Column>
  </Columns>
  <TOMLevel1>Services</TOMLevel1>
  <FunctionalStream>PE - Technical</FunctionalStream>
</Table>
***/
CREATE TABLE [dbo].[Tasks2]
(
[Id] [int] NOT NULL IDENTITY(1, 1),
[Task_Name] [varchar] (100) NULL CONSTRAINT [DF_tasks2_task_name] DEFAULT ('none'),
[Task_Type] [varchar] (20) NULL CONSTRAINT [DF_tasks2_task_type] DEFAULT ('DLL'),
[Task_Category] [varchar] (20) NULL CONSTRAINT [DF_tasks2_task_category] DEFAULT ('none'),
[ClassName] [varchar] (150) NULL CONSTRAINT [DF_tasks2_classname] DEFAULT ('none'),
[Rpt_Email] [int] NULL CONSTRAINT [DF_tasks2_rpt_email] DEFAULT ((0)),
[Rpt_Print] [int] NULL CONSTRAINT [DF_tasks2_rpt_print] DEFAULT ((0)),
[Enabled] [int] NULL CONSTRAINT [DF_tasks2_enabled] DEFAULT ((0)),
[Time] [datetime] NOT NULL CONSTRAINT [DF_tasks2_time] DEFAULT ('1 jan 2000 09:00:00'),
[Frequency] [char] (1) NOT NULL CONSTRAINT [DF_tasks2_frequency] DEFAULT ('W'),
[Mon] [int] NULL CONSTRAINT [DF_tasks2_mon] DEFAULT ((1)),
[Tue] [int] NULL CONSTRAINT [DF_tasks2_tue] DEFAULT ((1)),
[Wed] [int] NULL CONSTRAINT [DF_tasks2_wed] DEFAULT ((1)),
[Thu] [int] NULL CONSTRAINT [DF_tasks2_thu] DEFAULT ((1)),
[Fri] [int] NULL CONSTRAINT [DF_tasks2_fri] DEFAULT ((1)),
[Sat] [int] NULL CONSTRAINT [DF_tasks2_sat] DEFAULT ((1)),
[Sun] [int] NULL CONSTRAINT [DF_tasks2_sun] DEFAULT ((1)),
[PublicHoliday] [int] NULL,
[First_Last] [char] (1) NULL CONSTRAINT [DF_tasks2_first_last] DEFAULT ('F'),
[Day_Bday1] [char] (1) NULL CONSTRAINT [DF_tasks2_day_bday1] DEFAULT ('D'),
[Day_Bday2] [char] (1) NULL CONSTRAINT [DF_tasks2_day_bday2] DEFAULT ('D'),
[Description] [varchar] (255) NULL CONSTRAINT [DF_tasks2_description] DEFAULT ('none'),
[Completed] [datetime] NOT NULL CONSTRAINT [DF_tasks2_completed] DEFAULT ('1 jan 2000 09:00:00'),
[Pubid] [int] NULL CONSTRAINT [DF_tasks2_pubid] DEFAULT ((0)),
[NewPubId] [int] NULL CONSTRAINT [DF_tasks2_newpubid] DEFAULT ((0)),
[Computer] [varchar] (255) NULL,
[Status] [varchar] (20) NULL CONSTRAINT [DF_tasks2_status] DEFAULT ('Complete'),
[ErrorDescription] [varchar] (255) NULL,
[ProcedureName] [varchar] (50) NULL CONSTRAINT [DF_tasks2_procedurename] DEFAULT ('none'),
[IntradayInterval] [int] NULL CONSTRAINT [DF_tasks2_intradayinterval] DEFAULT ((0)),
[IntradayOpen] [datetime] NOT NULL CONSTRAINT [DF_tasks2_intradayopen] DEFAULT ('00:00:00'),
[IntradayClose] [datetime] NOT NULL CONSTRAINT [DF_tasks2_intradayclose] DEFAULT ('23:59:59'),
[ReRunFrom] [datetime] NOT NULL CONSTRAINT [DF_tasks2_rerunfrom] DEFAULT ('2 jan 2000'),
[ReRunTo] [datetime] NOT NULL CONSTRAINT [DF_tasks2_rerunto] DEFAULT ('1 jan 2000'),
[Parameters] [varchar] (300) NULL,
[MaxRetries] [int] NOT NULL CONSTRAINT [DF_tasks2_MaxRetries] DEFAULT ((5)),
[RetryInterval] [int] NULL CONSTRAINT [DF_tasks2_RetryInterval] DEFAULT ((300)),
[LastAttempt] [datetime] NOT NULL CONSTRAINT [DF_tasks2_LastAttempt] DEFAULT ('1 jan 2000 09:00:00'),
[NotifyGroupId] [int] NOT NULL CONSTRAINT [DF_tasks2_NotifyGroupID] DEFAULT ((1)),
[BusyTimeout] [int] NOT NULL CONSTRAINT [DF_tasks2_BusyTimeout] DEFAULT ((120)),
[NumberOfRetries] [int] NOT NULL CONSTRAINT [DF_tasks2_NumberOfRetries] DEFAULT ((0)),
[LastTimeoutNotify] [datetime] NOT NULL CONSTRAINT [DF_tasks2_LastTimeoutNotify] DEFAULT ('1 jan 2000 09:00:00'),
[ReEnableInterval] [int] NULL CONSTRAINT [DF_tasks2_ReEnableInterval] DEFAULT ((300)),
[EnableFrom] [datetime] NULL CONSTRAINT [DF_tasks2_EnableFrom] DEFAULT ('1 Jan 2001'),
[FileExtension] [varchar] (10) NULL,
[TaskOwner] [varchar] (50) NOT NULL,
[WordTemplateID] [int] NULL CONSTRAINT [DF_Tasks2_WordTemplateID] DEFAULT ((0)),
[WordEnabled] [int] NULL CONSTRAINT [DF_Tasks2_WordEnabled] DEFAULT ((0)),
[Notes] [varchar] (255) NULL,
[LibraryKeyWords] [varchar] (250) NULL,
[LibraryCategory] [varchar] (50) NULL,
[ProdEnabled] [int] NULL,
[AllowConcurrent] [tinyint] NULL,
[MustCompleteBy] [datetime] NULL,
[Reset] [int] NULL,
[TaskPriority] [tinyint] NOT NULL CONSTRAINT [DF_Tasks2_TaskPriority] DEFAULT ((100))
) ON [PRIMARY]
GO

CREATE TRIGGER [dbo].[protectData_Tasks2] ON dbo.Tasks2 
WITH EXECUTE AS OWNER 
FOR DELETE AS 
BEGIN
     DECLARE @Count int
     SET @Count = (select count(*) from deleted);
         
     IF @Count >= (
                                  SELECT SUM(row_count)
                                  FROM sys.dm_db_partition_stats 
                                   WHERE OBJECT_ID = OBJECT_ID('Tasks2') AND index_id = 1
                                  )
     BEGIN
         RAISERROR('Cannot perform this action against all rows',16,1) 
         ROLLBACK TRANSACTION
         RETURN;
     END
END
GO

ALTER TABLE [dbo].[Tasks2] ADD CONSTRAINT [chkTasks2_ValidFrequency] CHECK (([Frequency]='A' OR [Frequency]='I' OR [Frequency]='Q' OR [Frequency]='M' OR [Frequency]='W' OR [Frequency]='Y'))
GO

ALTER TABLE [dbo].[Tasks2] ADD CONSTRAINT [PK_TaskID2] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [idx_Enabled] ON [dbo].[Tasks2] ([Enabled]) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [idx_EnabledFrequencyEnableFromCompletedLastAttempt] ON [dbo].[Tasks2] ([Enabled], [Frequency], [EnableFrom], [Completed], [LastAttempt]) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [idx_EnableFrom] ON [dbo].[Tasks2] ([EnableFrom]) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [idx_Frequency] ON [dbo].[Tasks2] ([Frequency]) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [idx_ProcedureName] ON [dbo].[Tasks2] ([ProcedureName]) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [idx_Status] ON [dbo].[Tasks2] ([Status]) ON [PRIMARY]
GO

CREATE UNIQUE NONCLUSTERED INDEX [uidx_task_name] ON [dbo].[Tasks2] ([task_name]) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Tasks2] ADD CONSTRAINT [FK_Tasks2_TaskCategory] FOREIGN KEY ([task_category]) REFERENCES [dbo].[TaskCategory] ([TaskCategory])
GO