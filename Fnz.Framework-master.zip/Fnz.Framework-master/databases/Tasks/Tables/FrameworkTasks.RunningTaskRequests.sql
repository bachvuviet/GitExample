/***
<Table>
	<Description>Status information about the current task requests that are running</Description>
	<TableType>Transaction</TableType>
</Table>
***/
CREATE TABLE FrameworkTasks.RunningTaskRequests
(
    [TaskRequestId] [INT] NOT NULL,
    [TaskId] [INT] NOT NULL,
    [LoaderId] [INT] NOT NULL,
    [StartedRunning] [DATETIME] NOT NULL CONSTRAINT [DF_RunningTaskRequests_StartedRunning] DEFAULT (GETDATE()),

    CONSTRAINT [PK_RunningTaskRequests] PRIMARY KEY CLUSTERED ([TaskRequestId]),
    CONSTRAINT [FK_RunningTaskRequests_Tasks2_Id] FOREIGN KEY (TaskId) REFERENCES dbo.Tasks2(Id),
    CONSTRAINT [FK_RunningTaskRequests_Loaders_Id] FOREIGN KEY (LoaderId) REFERENCES dbo.Loaders(Id)
)
GO

CREATE UNIQUE NONCLUSTERED INDEX [IDX_RunningTaskRequests_LoaderId] ON FrameworkTasks.RunningTaskRequests ([LoaderId])
GO
