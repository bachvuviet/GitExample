/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<Table>
  <Description>99671AECA8F8EF9FC70082BBC7B33098</Description>
  <Service>Unknown</Service>
  <Feature>Unknown</Feature>
  <TableType>EnvironmentConfig</TableType>
  <Columns>
    <Column Name="id">
      <Description>Identity Column</Description>
    </Column>
    <Column Name="Host">
      <Description>Host name</Description>
    </Column>
    <Column Name="Ping">
      <Description>Date time Ping to Host</Description>
    </Column>
    <Column Name="Enabled">
      <Description>Is host Enabled?</Description>
    </Column>
    <Column Name="Activation">
      <Description>Activation Hosts</Description>
    </Column>
    <Column Name="Status">
      <Description>Host Status</Description>
    </Column>
    <Column Name="SchedulerPing">
      <Description>Scheduled datetime to Ping</Description>
    </Column>
  </Columns>
  <TOMLevel1>Services</TOMLevel1>
  <FunctionalStream>PE - Technical</FunctionalStream>
</Table>
***/
CREATE TABLE [dbo].[Hosts]
(
[id] [int] NOT NULL IDENTITY(1, 1) NOT FOR REPLICATION,
[Host] [varchar] (20) NULL,
[Ping] [datetime] NULL,
[Enabled] [varchar] (10) NULL CONSTRAINT [DF_Hosts_Enabled3] DEFAULT ('NO'),
[Activation] [int] NULL,
[Status] [varchar] (20) NULL CONSTRAINT [DF_Hosts_Status3] DEFAULT ('INACTIVE'),
[SchedulerPing] [datetime] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Hosts] ADD CONSTRAINT [chkHostsActiveHostHasPing] CHECK (([Status]<>'Active' OR [Ping] IS NOT NULL))
GO
ALTER TABLE [dbo].[Hosts] ADD CONSTRAINT [PK_Hosts3] PRIMARY KEY CLUSTERED  ([id]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [idx_enabled3] ON [dbo].[Hosts] ([Enabled]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [idx_host3] ON [dbo].[Hosts] ([Host]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [idx_status3] ON [dbo].[Hosts] ([Status]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
