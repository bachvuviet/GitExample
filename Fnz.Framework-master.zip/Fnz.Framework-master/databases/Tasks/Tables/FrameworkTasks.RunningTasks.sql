/***
<Table>
    <Description>Stops the running of the same task twice at the same time.</Description>
	<TableType>Transaction</TableType>
</Table>
***/
CREATE TABLE FrameworkTasks.RunningTasks
(
    [TaskId] [INT] NOT NULL,
    [LoaderId] [INT] NOT NULL,
    [StartedRunning] [DATETIME] NOT NULL CONSTRAINT [DF_RunningTasks_StartedRunning] DEFAULT (GETDATE()),

    CONSTRAINT [PK_RunningTasks] PRIMARY KEY CLUSTERED ([TaskId]),
    CONSTRAINT [FK_RunningTasks_Tasks2_Id] FOREIGN KEY (TaskId) REFERENCES dbo.Tasks2(Id),
    CONSTRAINT [FK_RunningTasks_Loaders_Id] FOREIGN KEY (LoaderId) REFERENCES dbo.Loaders(Id)
)
GO

CREATE UNIQUE NONCLUSTERED INDEX [IDX_RunningTasks_LoaderId] ON FrameworkTasks.RunningTasks (LoaderId)
GO

