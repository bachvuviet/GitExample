/***
<View>
    <Description>Exposes task requests details, used by task loaders</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</View>
***/

CREATE VIEW [dbo].[vwTaskRequests] AS

SELECT  TR.RequestClientId, 
		TR.ClAccountId, 
		TR.Id,		
		T.NotifyGroupId,		
		TR.Status,		
		T.TaskPriority as Priority,		
		TR.Parameters,		
		TR.Parameters2,		
		TR.ErrorDescription,		
		TR.Start,	
		TR.Finish,		
		TR.TaskId,		
		T.Computer,		
		T.Classname,		
		T.Rpt_email,		
		T.Enabled,		
		T.Procedurename,		
		T.PubId,		
		T.Task_type,		
		T.Task_name,		
		T.Parameters AS PermanentParameters,		
		T.FileExtension,		
		T.Description,		
		T.Task_category AS TaskCategory,		
		T.TaskOwner,		
		T.Completed AS LastRun,		
		T.LastAttempt,		
		T.WordTemplateId,		
		T.WordEnabled,		
		T.RetryInterval,		
		TR.RetriesRemaining,		
		ISNULL(TR.AttemptCount,0) as AttemptCount,		
		T.MaxRetries,	
		CASE 
			WHEN CONVERT(datetime, CONVERT(varchar,COALESCE(TR.NextAttempt,TR.RequestDateTime),108)) <= CONVERT(datetime,CONVERT(varchar, T.Intradayopen, 108)) AND TR.NextAttempt != '1 Jan 1900' THEN
				CASE 
					WHEN datepart(dw, getdate()) = 1 AND T.Sun = 1 THEN CONVERT(datetime,CONVERT(varchar, getdate(), 106)) + CONVERT(datetime,CONVERT(varchar, T.Intradayopen, 108))
					WHEN datepart(dw, getdate()) = 2 AND T.Mon = 1 THEN CONVERT(datetime,CONVERT(varchar, getdate(), 106)) + CONVERT(datetime,CONVERT(varchar, T.Intradayopen, 108))
					WHEN datepart(dw, getdate()) = 3 AND T.Tue = 1 THEN CONVERT(datetime,CONVERT(varchar, getdate(), 106)) + CONVERT(datetime,CONVERT(varchar, T.Intradayopen, 108))
					WHEN datepart(dw, getdate()) = 4 AND T.Wed = 1 THEN CONVERT(datetime,CONVERT(varchar, getdate(), 106)) + CONVERT(datetime,CONVERT(varchar, T.Intradayopen, 108))
					WHEN datepart(dw, getdate()) = 5 AND T.Thu = 1 THEN CONVERT(datetime,CONVERT(varchar, getdate(), 106)) + CONVERT(datetime,CONVERT(varchar, T.Intradayopen, 108))
					WHEN datepart(dw, getdate()) = 6 AND T.Fri = 1 THEN CONVERT(datetime,CONVERT(varchar, getdate(), 106)) + CONVERT(datetime,CONVERT(varchar, T.Intradayopen, 108))
					WHEN datepart(dw, getdate()) = 7 AND T.Sat = 1 THEN CONVERT(datetime,CONVERT(varchar, getdate(), 106)) + CONVERT(datetime,CONVERT(varchar, T.Intradayopen, 108))
					ELSE CONVERT(datetime,CONVERT(varchar, dateadd(d, 1, getdate()), 106)) + CONVERT(datetime,CONVERT(varchar, T.IntraDayOpen, 108))
				END
			WHEN CONVERT(datetime, CONVERT(varchar,TR.RequestDateTime,108)) <= CONVERT(datetime,CONVERT(varchar, T.Intradayopen, 108)) AND TR.NextAttempt = '1 Jan 1900' THEN
				CASE 
					WHEN datepart(dw, getdate()) = 1 AND T.Sun = 1 THEN CONVERT(datetime,CONVERT(varchar, getdate(), 106)) + CONVERT(datetime,CONVERT(varchar, T.Intradayopen, 108))
					WHEN datepart(dw, getdate()) = 2 AND T.Mon = 1 THEN CONVERT(datetime,CONVERT(varchar, getdate(), 106)) + CONVERT(datetime,CONVERT(varchar, T.Intradayopen, 108))
					WHEN datepart(dw, getdate()) = 3 AND T.Tue = 1 THEN CONVERT(datetime,CONVERT(varchar, getdate(), 106)) + CONVERT(datetime,CONVERT(varchar, T.Intradayopen, 108))
					WHEN datepart(dw, getdate()) = 4 AND T.Wed = 1 THEN CONVERT(datetime,CONVERT(varchar, getdate(), 106)) + CONVERT(datetime,CONVERT(varchar, T.Intradayopen, 108))
					WHEN datepart(dw, getdate()) = 5 AND T.Thu = 1 THEN CONVERT(datetime,CONVERT(varchar, getdate(), 106)) + CONVERT(datetime,CONVERT(varchar, T.Intradayopen, 108))
					WHEN datepart(dw, getdate()) = 6 AND T.Fri = 1 THEN CONVERT(datetime,CONVERT(varchar, getdate(), 106)) + CONVERT(datetime,CONVERT(varchar, T.Intradayopen, 108))
					WHEN datepart(dw, getdate()) = 7 AND T.Sat = 1 THEN CONVERT(datetime,CONVERT(varchar, getdate(), 106)) + CONVERT(datetime,CONVERT(varchar, T.Intradayopen, 108))
					ELSE CONVERT(datetime,CONVERT(varchar, dateadd(d, 1, getdate()), 106)) + CONVERT(datetime,CONVERT(varchar, T.IntraDayOpen, 108))
				END
			-- is it currently after intraday close
			WHEN CONVERT(datetime, CONVERT(varchar,getdate(),108)) > CONVERT(datetime,CONVERT(varchar, T.Intradayclose, 108)) THEN
				CONVERT(datetime,CONVERT(varchar, dateadd(d, 1, getdate()), 106)) + CONVERT(datetime,CONVERT(varchar, T.Intradayopen, 108))
			-- is it currently before intraday open
			WHEN CONVERT(datetime, CONVERT(varchar,getdate(),108)) < CONVERT(datetime,CONVERT(varchar, T.Intradayopen, 108)) THEN
				CONVERT(datetime,CONVERT(varchar, getdate(), 106)) + CONVERT(datetime,CONVERT(varchar, T.Intradayopen, 108))
			ELSE 
				CASE 
					WHEN datepart(dw, getdate()) = 1 AND T.Sun = 1 THEN COALESCE(TR.NextAttempt,TR.RequestDateTime)
					WHEN datepart(dw, getdate()) = 2 AND T.Mon = 1 THEN COALESCE(TR.NextAttempt,TR.RequestDateTime)
					WHEN datepart(dw, getdate()) = 3 AND T.Tue = 1 THEN COALESCE(TR.NextAttempt,TR.RequestDateTime)
					WHEN datepart(dw, getdate()) = 4 AND T.Wed = 1 THEN COALESCE(TR.NextAttempt,TR.RequestDateTime)
					WHEN datepart(dw, getdate()) = 5 AND T.Thu = 1 THEN COALESCE(TR.NextAttempt,TR.RequestDateTime)
					WHEN datepart(dw, getdate()) = 6 AND T.Fri = 1 THEN COALESCE(TR.NextAttempt,TR.RequestDateTime)
					WHEN datepart(dw, getdate()) = 7 AND T.Sat = 1 THEN COALESCE(TR.NextAttempt,TR.RequestDateTime)
					ELSE CONVERT(datetime,CONVERT(varchar, dateadd(d, 1, getdate()), 106)) + CONVERT(datetime,CONVERT(varchar, T.IntraDayOpen, 108))
				END
		END as NextAttempt,	
		T.Rpt_print,		
		CDL.Id AS ClientDocumentLibraryID,		
		TR.FileName,		
		TR.RequestDateTime,
		'Other' AS SchedulerType
FROM	dbo.Tasks2 AS T 
			INNER JOIN dbo.TaskRequests AS TR ON TR.TaskId = T.Id 
			LEFT OUTER JOIN Documents.ClientDocumentLibrary AS CDL ON CDL.TaskRequestId = TR.Id

GO