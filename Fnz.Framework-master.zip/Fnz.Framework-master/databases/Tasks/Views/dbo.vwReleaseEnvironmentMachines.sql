/***
***************************************************************************************************************************
This object has been flagged as undocumented and\or not meeting code quality standards.
When making changes to this file please fill in the documentation header below and ensure it meets code quality standards.
***************************************************************************************************************************
<View>
    <Description>12888E6839FFC6E38A068AD58D533C73</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</View>
***/
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE VIEW [dbo].[vwReleaseEnvironmentMachines]
AS
SELECT     dbo.ReleaseEnvironments.Environment, dbo.ReleaseEnvironments.Multi, dbo.ReleaseMachines.Cluster, dbo.ReleaseMachines.MachineType, 
                      dbo.ReleaseEnvironments.DisplayOrder, dbo.ReleaseEnvironments.ShowWarning, dbo.ReleaseMachines.Machine, 
                      dbo.ReleaseEnvironmentsToMachines.EnvironmentID, dbo.ReleaseEnvironmentsToMachines.MachineID, 
                      dbo.ReleaseEnvironments.ReleaseDestination, dbo.ReleaseEnvironments.TestEnvironment
FROM         dbo.ReleaseMachines INNER JOIN
                      dbo.ReleaseEnvironmentsToMachines ON dbo.ReleaseMachines.ID = dbo.ReleaseEnvironmentsToMachines.MachineID INNER JOIN
                      dbo.ReleaseEnvironments ON dbo.ReleaseEnvironmentsToMachines.EnvironmentID = dbo.ReleaseEnvironments.ID
GO
