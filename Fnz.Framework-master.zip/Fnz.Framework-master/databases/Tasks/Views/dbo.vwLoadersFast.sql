
CREATE VIEW [dbo].[vwLoadersFast] AS

	SELECT	[CallState],
			[Client], 
			[ClientTaskID], 
			[Enabled], 
			[HostName], 
			[id], 
			[SpecificPermissioning], 
			[Status], 
			[TaskParameters],
			[Type],
			[TypePriority],
			[SchedulingPrecedence] 
	FROM	dbo.Loaders
	
GO
