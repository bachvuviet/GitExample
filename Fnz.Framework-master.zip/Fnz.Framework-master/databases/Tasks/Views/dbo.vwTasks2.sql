/***
<View>
    <Description>Exposes tasks details</Description>
    <Service>Unknown</Service>
    <Feature>Unknown</Feature>
</View>
***/

CREATE VIEW [dbo].[vwTasks2] AS

SELECT		Id,
			Task_name,
			Task_type,
			Task_category,
			Classname,
			Rpt_email,
			Rpt_print,
			Enabled,
			Time,
			Frequency,
			Mon,
			Tue,
			Wed,
			Thu,
			Fri,
			Sat,
			Sun,
			Publicholiday,
			First_last,
			Day_bday1,
			Day_bday2,
			Description,
			Completed,
			PubId,
			NewpubId,
			Computer,
			Status,
			Errordescription,
			Procedurename,
			Intradayinterval,
			Intradayopen,
			Intradayclose,
			Rerunfrom,
			Rerunto,
			Parameters,
			MaxRetries,
			RetryInterval,
			LastAttempt,
			NotifyGroupId,
			BusyTimeout,
			NumberOfRetries,
			LastTimeoutNotify,
			ReEnableInterval,
			EnableFrom,
			FileExtension,
			TaskOwner,
			WordTemplateId,
			WordEnabled,
			Notes,
			LibraryKeyWords,
			LibraryCategory,
			ProdEnabled,
			AllowConcurrent,
			'Other' AS SchedulerType
FROM	dbo.Tasks2

GO