# What's new in Fnz.Framework 5.1

Apart from some minor fixes and adjustments, 5.1 comes with some interesting features. 

## Breaking changes

### Fnz.Framework now targets net472
* Fnz.Framework assemblies now target .net 472, which means that consuming platforms also have to target at least this .net version
* Fnz.Framework.Service.Api now targets netstandard 2.0

### Fnz.Api references updated to 1.0.12
Consuming platforms need to update at least to this version. Please note that Fnz.Api 1.0.12 also targets netstandard 2.0.

### Changed signature for `ILoginRefreshCommandHandler` ([FWK-236](https://portal.fnz.com/jira/browse/FWK-236))
Support for `x-applicationName` header was added and alongside this change, signature of `ILoginRefreshCommandHandler` was slightly altered.

Token GUID is now passed via new `LoginRefreshCommand`. 

### ContextInfo added to `CSFBMaster.dbo.ErrorHandler` ([FWK-589](https://portal.fnz.com/jira/browse/FWK-589))
Fnz.Framework code now expects that ErrorHandler table and spInsertError procedure accept new ContextInfo column. Since both database objects
are still part of Platform code, you have to make following changes to them when upgrading to Fnz.Framework 5.1

1. Add new nullable ContextInfo column to `CSFBMaster.dbo.ErrorHandler`
```sql
CREATE TABLE dbo.ErrorHandler (
    -- Everything that was in the table before
    ContextInfo VARCHAR(100) NULL
)
```

2. Update `CSFBMaster.dbo.spInsertError` to accept new optional `ContextInfo` parameter. Make sure this parameter is optional, so that common libraries that still use older ilmerged Fnz.Framework can log errors.
```sql
CREATE PROCEDURE dbo.spInsertError (
	@ErrorRef AS int,
	-- all the previous stuff
	@IPAddress AS varchar(50),
    @id int = NULL OUTPUT,
	@ContextInfo AS VARCHAR(100) = NULL,
	) AS
BEGIN
	INSERT INTO [dbo].[ErrorHandler]
	(
		ErrorRef,
		-- all the previous stuff
		IPAddress,
		ContextInfo
	)
	VALUES (
		@ErrorRef,
		--all the previous stuff
		@IPAddress,
		@ContextInfo
		)
	SELECT @id = SCOPE_IDENTITY();
END

```

### RecordsetMappers are no longer registered in container ([FWK-605](https://portal.fnz.com/jira/browse/FWK-605))
Recordset mapper registration was removed from DefaultInstaller and they can no longer be injected by default. This was done 
to improve application startup times as it reduces amount of registered components. Make sure your codebase doesn't inject 
RecordsetMappers into readers (It's very uncommon, so it's possible you won't encounter many of these). 

Refer to following page when making these changes.

https://wiki.fnz.com/confluence/pages/viewpage.action?spaceKey=Architecture&title=Remove+Registering+of+RecordsetMappers+with+Castle


## New features

### Confirmation messages for RabbitMQ  ([FWK-600](https://portal.fnz.com/jira/browse/FWK-600))

You can now configure your RabbitMQ queues to send out confirmation messages after consuming and processing of a message.
This can be done by setting `ShouldSendAckMessage` flag on queue in `Messaging.RabbitQueues` tables. 

Published `MessageAcknowledgedEvent` contains original message id. 

### Yearly scheduling for tasks ([FWK-569](https://portal.fnz.com/jira/browse/FWK-569))

Adds new yearly scheduling frequency for tasks. Using Frequency of `Y` and setting `Time` column to specific date allows 
you to run given tasks with yearly frequency. 

_**NOTE:** Database schema for Tasks2 table still lives in platform, therefore  you have to make sure that
Y frequency is accepted by that table by altering constraint on Frequency column._
