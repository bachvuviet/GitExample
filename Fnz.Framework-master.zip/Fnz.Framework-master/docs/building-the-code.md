
# Building the code
Once you have run build.bat at least once it is possible to build using Visual Studio, provided that if you change the database schema you run build_database

build.bat:                   Cleans the build artifacts and rebuilds everything and runs all the tests. To build a specific solution specify it's name as the first parameter.
build_database.bat:          Restores the legacy databases, builds all framework schema (everything under .\databases\ in the DatabaseToPrePackage group in database_settings.targets) into a database called "Framework"
build_generate_metadata.bat: Regenerates the meta-data from the files under .\databases\
restore-all-databases.bat:   Fetches the latest database backups from the server, drops all legacy databases then restores them.

Test Bat files:
1. run-tests-with-ncover.bat:         Runs all tests (both unit and integration) using NCover to produce coverage output. Specify 'unit' or 'integration' as the first parameter to indicate which tests to run.
2. run-tests-for-assembly.bat:        Runs the tests in the specified assembly.
3. test_database.bat:                 Runs all of the database tests
4. test_config_scripts.bat:           Builds the schemas into a "framework" database, builds a scripts package and runs it. Stops on the first scrip that fails
4. test_config_scripts_continue.bat:  re-builds a scripts package and runs it. Starts off from where test_config_scripts.bat left off, so you can just fix the script that failed and continue


How to I ...
Nuke it from orbit: clean everything, get latest versions of all the databases, and start again

1. run restore-all-databases.bat
2. run build.bat

