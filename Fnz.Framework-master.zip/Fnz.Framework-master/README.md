The Fnz.Framework is a separate codebase from Fnz.Platform that contains core utilities and no business logic. It allows us to:

Implement functionality once, and only once, and not duplicate that code for each platform
Have good quality and well tested code with 80% test coverage.
The features it provides are:

* Database Access Layer
* General utilities
* Test utilities for building Xunit BDD tests
* Integration with an external Filestore for storing blobs outside the database (HCP)
* New task schedulers
* Instrumentation for logging performance timing information
* Generic Reports
* Messaging

For more info see here : https://wiki.fnz.com/confluence/display/Architecture/Fnz.Framework+Guide

# Building the code
See [Building the code](./docs/building-the-code.md)
