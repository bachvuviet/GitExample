--Migrate over the existing  MessageTypes (between 1 and 999)
IF NOT EXISTS(SELECT * FROM Messaging.RabbitMessageTypes WHERE MessageTypeId > 0 AND MessageTypeId < 1000)
BEGIN
	INSERT INTO Messaging.RabbitMessageTypes (MessageTypeId, MessageType)
	SELECT 1, 'Fnz.Platform.Api.Accounts.Accounts.BadDebtEvent, Fnz.Platform.Api' UNION
	SELECT 2, 'Fnz.Platform.Api.Accounts.Addresses.AddressChangeEvent, Fnz.Platform.Api' UNION
	SELECT 3, 'Fnz.Platform.Api.Accounts.SubAccounts.JisaUpcomming16thBirthdayEvent, Fnz.Platform.Api' UNION
	SELECT 4, 'Fnz.Platform.Api.Accounts.SubAccounts.JisaUpcomming18thBirthdayEvent, Fnz.Platform.Api' UNION
	SELECT 5, 'Fnz.Platform.Api.Accounts.Terms.TermsReacceptionNotification, Fnz.Platform.Api' UNION
	SELECT 6, 'Fnz.Platform.Api.Charges.AdHoc.Entities.DirectDebitFeePaymentRejectionEvent, Fnz.Platform.Api' UNION
	SELECT 7, 'Fnz.Platform.Api.Charges.AdHoc.Entities.RegularFeePaymentCollectionEvent, Fnz.Platform.Api' UNION
	SELECT 8, 'Fnz.Platform.Api.CorporateActions.CorporateActionCompletionEvent, Fnz.Platform.Api' UNION
	SELECT 9, 'Fnz.Platform.Api.CorporateActions.CorporateActionMandatoryEvent, Fnz.Platform.Api' UNION
	SELECT 10, 'Fnz.Platform.Api.CorporateActions.CorporateActionMandatoryWithOptionsEvent, Fnz.Platform.Api' UNION
	SELECT 11, 'Fnz.Platform.Api.CorporateActions.CorporateActionRejectedlIpoEvent, Fnz.Platform.Api' UNION
	SELECT 12, 'Fnz.Platform.Api.CorporateActions.CorporateActionEventReminderEvent, Fnz.Platform.Api' UNION
	SELECT 13, 'Fnz.Platform.Api.CorporateActions.CorporateActionSuccessfulIpoEvent, Fnz.Platform.Api' UNION
	SELECT 14, 'Fnz.Platform.Api.CorporateActions.CorporateActionUpdateEvent, Fnz.Platform.Api' UNION
	SELECT 15, 'Fnz.Platform.Api.CorporateActions.CorporateActionVoluntaryEvent, Fnz.Platform.Api' UNION
	SELECT 16, 'Fnz.Platform.Api.MarketData.Products.IneligibleIsaStockEvent, Fnz.Platform.Api' UNION
	SELECT 17, 'Fnz.Platform.Api.MarketData.Products.ProductAssetClassChangeEvent, Fnz.Platform.Api' UNION
	SELECT 18, 'Fnz.Platform.Api.Orders.CancelledOrderEvent, Fnz.Platform.Api' UNION
	SELECT 19, 'Fnz.Platform.Api.Orders.ExpiredOrderEvent, Fnz.Platform.Api' UNION
	SELECT 20, 'Fnz.Platform.Api.Orders.InsuffiecientFundsForRegularInvestmentEvent, Fnz.Platform.Api' UNION
	SELECT 21, 'Fnz.Platform.Api.Orders.OrderCompleteEvent, Fnz.Platform.Api' UNION
	SELECT 22, 'Fnz.Platform.Api.Orders.RejectedOrderEvent, Fnz.Platform.Api' UNION
	SELECT 23, 'Fnz.Platform.Api.Payments.DirectDebitCancellationEvent, Fnz.Platform.Api' UNION
	SELECT 24, 'Fnz.Platform.Api.Payments.DirectDebitChangeEvent, Fnz.Platform.Api' UNION
	SELECT 25, 'Fnz.Platform.Api.Payments.DirectDebitRepeatFailureEvent, Fnz.Platform.Api' UNION
	SELECT 26, 'Fnz.Platform.Api.Payments.DirectDebitSetupFailureEvent, Fnz.Platform.Api' UNION
	SELECT 27, 'Fnz.Platform.Api.Payments.FailedDirectDebitEvent, Fnz.Platform.Api' UNION
	SELECT 28, 'Fnz.Platform.Api.Payments.FasterPaymentInEvent, Fnz.Platform.Api' UNION
	SELECT 29, 'Fnz.Platform.Api.Payments.PaymentInCompleteEvent, Fnz.Platform.Api' UNION
	SELECT 30, 'Fnz.Platform.Api.Payments.PaymentInFailureEvent, Fnz.Platform.Api' UNION
	SELECT 31, 'Fnz.Platform.Api.Transfers.External.TransferInFinalNotificationEvent, Fnz.Platform.Api' UNION
	SELECT 32, 'Fnz.Platform.Api.Transfers.External.TransferInStockLineCompletionEvent, Fnz.Platform.Api' UNION
	SELECT 33, 'Fnz.Platform.Api.Transfers.External.TransferStatusUpdatedEvent, Fnz.Platform.Api' UNION
	SELECT 34, 'Fnz.Platform.Api.Users.GoneAwayClientEvent, Fnz.Platform.Api' UNION
	SELECT 35, 'Fnz.Platform.Api.Accounts.BankAccounts.BankAccountChangeEvent, Fnz.Platform.Api'
END