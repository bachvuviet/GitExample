USE TaskDB
GO

--Causes issues with platform build up if not here.
IF NOT EXISTS (SELECT 1 FROM dbo.TaskCategory WHERE TaskCategory = 'Document Management')
BEGIN
    INSERT INTO dbo.TaskCategory
    (TaskCategory)
    VALUES
    ('Document Management')
END 

--Add disabled task for document migrations
IF NOT EXISTS (SELECT 1 FROM dbo.Tasks2 WHERE ID = 151800)
BEGIN
	DECLARE @idCol AS sysname
	SELECT @idCol = c.name 
	FROM sys.columns c
		INNER JOIN sys.tables t ON t.object_id = c.object_id
	WHERE c.is_identity = 1
	AND t.name = 'Tasks2'

	IF @idCol IS NOT NULL
	BEGIN
		SET IDENTITY_INSERT TaskDB.dbo.Tasks2 ON
	END

    INSERT INTO dbo.Tasks2 (ID,task_name,task_type,task_category,classname,rpt_email,rpt_print,enabled,time,frequency,mon,tue,wed,thu,fri,sat,sun,publicholiday,first_last,day_bday1,day_bday2,description,completed,pubid,newpubid,computer,status,errordescription,procedurename,intradayinterval,intradayopen,intradayclose,rerunfrom,rerunto,parameters,MaxRetries,RetryInterval,LastAttempt,NotifyGroupID,BusyTimeout,NumberOfRetries,LastTimeoutNotify,ReEnableInterval,EnableFrom,FileExtension,TaskOwner,WordTemplateID,WordEnabled,Notes,LibraryKeyWords,LibraryCategory,ProdEnabled) 
    VALUES 
    (151800,'Migrate Documents from DocumentImages to HCP','DLL','Document Management','Fnz.Framework.DocumentRepository.DocumentMigration.IDocumentMigrationCommandHandler',0,0,0,convert(datetime,'Jan  1 2000  1:00AM'),'W',1,1,1,1,1,1,1,1,'F','D','D','Migrates any documents in DocumentImages into HCP',convert(datetime,'Jan  1 2000  9:00AM'),0,0,NULL,'Complete',NULL,'Execute',0,convert(datetime,'Jan  1 1900 12:00AM'),convert(datetime,'Jan  1 1900 11:59PM'),convert(datetime,'Jan  2 2000 12:00AM'),convert(datetime,'Jan  1 2000 12:00AM'),'BatchSize=500',5,300,convert(datetime,'Jan  1 2000  9:00AM'),1,0,0,convert(datetime,'Jan  1 2000  9:00AM'),300,convert(datetime,'Jan  1 2001 12:00AM'),NULL,'Mark Mein',0,0,NULL,NULL,NULL,1)
    
	IF @idCol IS NOT NULL
	BEGIN
		SET IDENTITY_INSERT TaskDB.dbo.Tasks2 OFF
		PRINT '2'
	END
END
ELSE
BEGIN
	UPDATE	dbo.Tasks2
	SET		ClassName='Fnz.Framework.DocumentRepository.DocumentMigration.IDocumentMigrationCommandHandler'
	WHERE ID = 151800 AND ClassName='Fnz.Platform.Documents.DocumentMigration.IDocumentMigrationCommandHandler'
END

--Add system variable to disabed document migrations
IF NOT EXISTS (SELECT 1 FROM SystemVariables.dbo.SystemVariables WHERE ID = 100758)
BEGIN
	INSERT INTO SystemVariables.dbo.SystemVariables
	(Id, Location, Application, Variable, Value)
	VALUES  
	(100758, 'Global', 'HcpMigration', 'Enabled', 'false')
END
--both of these need to get turned on in the consuming platform when they are ready to migrate to Hcp
