IF NOT EXISTS (select * from [Documents].[RetentionClasses] where [RetentionClassId] = 1)
	INSERT INTO [Documents].[RetentionClasses]
	           ([RetentionClassId]
	           ,[RetentionClassName])
	     VALUES
	           (1
	           ,'Uncategorised')


IF NOT EXISTS (select * from [Documents].[DocumentCategories] where [DocumentCategoryId] = 1)
	INSERT INTO [Documents].[DocumentCategories]
	           ([DocumentCategoryId]
	           ,[DocumentCategoryName]
	           ,[RetentionClassId])
	     VALUES
	           (1
	           ,'Uncategorised'
	           ,1)

IF NOT EXISTS (select * from [Documents].[DocumentSubCategories] where [DocumentSubCategoryId] = 1)
	INSERT INTO [Documents].[DocumentSubCategories]
	           ([DocumentSubCategoryId]
	           ,[DocumentSubCategoryName]
	           ,[DocumentCategoryId])
	     VALUES
	           (1
	           ,'Uncategorised'
	           ,1)

