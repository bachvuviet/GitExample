INSERT INTO [Saml].[UserIdentifierTypes] ([UserIdentifierTypeId], [UserIdentifierTypeName]) VALUES (0, 'FnzUserId')
INSERT INTO [Saml].[UserIdentifierTypes] ([UserIdentifierTypeId], [UserIdentifierTypeName]) VALUES (1, 'ExternalUserId')
INSERT INTO [Saml].[UserIdentifierTypes] ([UserIdentifierTypeId], [UserIdentifierTypeName]) VALUES (2, 'ExternalCustomerId')
