IF NOT EXISTS (SELECT * FROM Saml.RoleTypes)
BEGIN
	INSERT INTO [Saml].[RoleTypes] ([RoleTypeId], [RoleTypeName]) VALUES (0, 'ServiceProvider')
	INSERT INTO [Saml].[RoleTypes] ([RoleTypeId], [RoleTypeName]) VALUES (1, 'IdentityProvider')
END