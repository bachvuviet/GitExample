#!/usr/bin/env powershell
[CmdletBinding()]
param (
    [Parameter(Mandatory,Position=0)]
    [ValidateSet("build", "build-code", "build-database", "generate-metadata", "restore-databases", "test", "test-databases", "pack")]
    $Action
)

function New-BuildCommand {
    param($bootstrapProj, $mainProj, $mainTarget, $logFile)
    Write-Output @(
            '/m', 
            '/nologo', 
            "$bootstrapProj", 
            "/p:MainProject=$mainProj;MainTarget=$mainTarget", 
            "/l:FileLogger,Microsoft.Build.Engine;logfile=$logFile")
}

function New-BootstrapBuildCommand {
    param($mainTarget, $logFile)
    
    return New-BuildCommand 'bootstrap.proj' 'main.proj' $mainTarget $logFile
}

function Find-MsBuild {

   <# $path = &"${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe" -latest -requires Microsoft.Component.MSBuild -find MSBuild\**\Bin\MSBuild.exe #> 
   $path = &"${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe" -version "17" -requires Microsoft.Component.MSBuild -find MSBuild\**\Bin\MSBuild.exe 

    if(Test-Path $path) {
        Write-Host "Found MSBuild at $path"
        return $path
    }

    throw "Could not find MSBuild on machine"
}

function Invoke-MsBuild {
    param (
        [Parameter(ValueFromPipeline)]
        [string[]] $MsBuildArgs
    )

    Write-Host "Build args: $MsBuildArgs"
    $MsBuild = Find-MsBuild
    & $MsBuild $MsBuildArgs
}


function Get-BuildArgs {
    param (
        $Action
    )

    switch ($Action) {
        "build"                 { New-BootstrapBuildCommand 'Local' 'build.log' }
        "build-code"            { New-BootstrapBuildCommand 'LocalCodeBuild' 'build.log' }
        "build-database"        { New-BootstrapBuildCommand 'LocalDatabaseBuildAndTest' 'build.log' }
        "generate-metadata"     { New-BootstrapBuildCommand 'LocalGenerateMetaData' 'build.log' }
        "restore-databases"     { New-BootstrapBuildCommand 'RestoreDatabases' 'build.log' }
        "restore-databases"     { New-BootstrapBuildCommand 'RestoreDatabases' 'build.log' }
        "test"                  { New-BootstrapBuildCommand 'Tests' 'tests.log' }
        "test-databases"        { New-BootstrapBuildCommand 'TestDatabaseFiles' 'tests.log' }
        "pack"                  { New-BootstrapBuildCommand 'Pack_Local' 'build.log' }

        Default { throw "Action is not supported" }
    }
}


Clear-Host


$args = Get-BuildArgs -Action $Action

Invoke-MsBuild $args