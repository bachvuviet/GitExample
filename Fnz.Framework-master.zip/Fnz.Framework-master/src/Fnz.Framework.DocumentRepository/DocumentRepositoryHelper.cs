﻿using Fnz.Framework.DataAccess;
using Fnz.Framework.DataAccess.Logging;

namespace Fnz.Framework.DocumentRepository
{
    public static class DocumentRepositoryHelper
    {
        /// <summary>
        /// e.g. "c:\folder1/folder2\filename.txt" will be returned as "filename.txt"
        /// </summary>
        public static string TrimDocumentNameToRemoveLeadingFilepath(string documentName)
        {
            if (documentName.Contains(@":\") || documentName.Contains(":/"))
            {
                return TrimDocumentNameToRemoveLeadingFilepath(TrimDocumentNameToRemoveLeadingFilepath(documentName, @"\"), "/");    
            }

            return documentName;
        }

        private static string TrimDocumentNameToRemoveLeadingFilepath(string toTrim, string lastChars)
        {
            var fileName = toTrim;
            var index = fileName.LastIndexOf(lastChars);
            fileName = index > -1 ? fileName.Substring(index + 1, fileName.Length - index - 1) : fileName;
            return fileName;
        }

        public static void CreateAndReportError(string fileName, string errorMessage)
        {
            var error = new Error();
            error.ApplicationName = "DocumentRepository";
            error.ClassName = "DocumentRepositoryHandler";
            error.FunctionName = "GetFileDataFromFilestoreThenDb";
            error.Internals = "FileName = " + fileName;
            error.Description = errorMessage;

            var logger = new ExceptionDatabaseLogger();
            logger.LogError(error);
        }
    }
}