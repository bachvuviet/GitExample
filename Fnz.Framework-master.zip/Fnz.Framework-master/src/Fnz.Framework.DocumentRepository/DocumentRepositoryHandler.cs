﻿using System.IO;
using Fnz.Framework.DataAccess;
using Fnz.Framework.DataAccess.Logging;
using Fnz.Framework.DataAccess.QueryBuilder;
using Fnz.Framework.DocumentRepository.Api;
using Fnz.Framework.DocumentRepository.Database;
using Fnz.Framework.Legacy.Logging;
using Fnz.Framework.ReadersWriters;
using Fnz.Framework.Util;
using Fnz.Framework.Util.CodeQuality;

namespace Fnz.Framework.DocumentRepository
{
    [IgnoreEfferentCoupling]
    [IgnoreNumberOfMethods]
    public class DocumentRepositoryHandler : IDocumentRepository
    {
        private const string InfoScope = "DocumentRepositoryHandler";

        private readonly IDocumentImagesWriter _documentImagesWriter;
        private readonly IDocumentImagesReader _documentImagesReader;

        private readonly DocumentToRecordsetMapper _recordsetMapper;

        private IOperationalLogger _logger = NullLogger.Instance;

        public DocumentRepositoryHandler(IDocumentImagesReader documentImagesReader, IDocumentImagesWriter documentImagesWriter)
        {
            _documentImagesReader = documentImagesReader;
            _documentImagesWriter = documentImagesWriter;

            _recordsetMapper = new DocumentToRecordsetMapper();
        }

        /// <summary>
        /// Constructor for ease of use by the component code when creating an instance, since the component code 
        /// doesn't use an IoC container to inject dependencies.
        /// It uses the default implementation of the injected dependencies
        /// </summary>
        public DocumentRepositoryHandler()
            : this(new Dal())
        {
        }

        /// <summary>
        /// Constructor for ease of use by the component code when creating an instance, since the component code 
        /// doesn't use an IoC container to inject dependencies.
        /// It uses the default implementation of the injected dependencies
        /// </summary>
        public DocumentRepositoryHandler(IDataAccess dal)
        {
            _logger = LogFactoryCreator.GetProperLoggerFactory().CreateOperationalLogger(GetType());

            var param = new DataAccessBaseParameter(dal, new QueryBuilderFactory(dal));
            _documentImagesReader = new DocumentImagesReader(param);
            _documentImagesWriter = new DocumentImagesWriter(param);

            _recordsetMapper = new DocumentToRecordsetMapper();
        }

        [NamedLoggerKey(LoggingConstants.Filestore)]
        public IOperationalLogger Logger
        {
            get { return _logger; }
            set { _logger = value; }
        }

        /// <summary>
        /// Save a document - note this implementation ignores the documentTypeId
        /// </summary>
        [IgnoreNumberOfOverloads]
        public Document SaveDocument(Stream data, string filename, short documentTypeId)
        {
            return SaveDocument(data, filename, SaveActionEnum.Unknown);
        }

        /// <summary>
        /// Save a document - note this implementation ignores the retentionClass
        /// </summary>
        [IgnoreNumberOfOverloads]
        public Document SaveDocument(Stream data, string filename, string retentionClass)
        {
            return SaveDocument(data, filename, SaveActionEnum.Unknown);
        }

        [IgnoreNumberOfOverloads]
        public void SaveTaskDocument(string filePath, string filename, int taskId, DocumentStoreType saveDestination)
        {
            // This IDocumentRepository does not know how to deal with documentCategories (and retention periods), so
            // we just save the document without trying to work out if the task can map to a document category
            SaveDocument(filePath, filename, SaveActionEnum.Create, saveDestination);
        }

        [IgnoreNumberOfOverloads]
        public Document SaveDocument(byte[] data, string filename, SaveActionEnum saveAction)
        {
            using (new QueryContextAdditionalInfoScope(InfoScope, "SaveDocument"))
            {
                var shortName = DocumentRepositoryHelper.TrimDocumentNameToRemoveLeadingFilepath(filename);

                return SaveToDocumentImageTable(data, shortName, null, saveAction, DocumentStoreType.Default);
            }
        }

        [IgnoreNumberOfOverloads]
        public Document SaveDocument(Stream data, string filename, SaveActionEnum saveAction)
        {
            using (new QueryContextAdditionalInfoScope(InfoScope, "SaveDocument"))
            {
                var shortName = DocumentRepositoryHelper.TrimDocumentNameToRemoveLeadingFilepath(filename);

                return SaveToDocumentImageTable(data, shortName, null, saveAction, DocumentStoreType.Default);
            }
        }

        [IgnoreNumberOfOverloads]
        public Document SaveDocument(long filestoreId, string filename, SaveActionEnum saveAction)
        {
           using (new QueryContextAdditionalInfoScope(InfoScope, "SaveDocument"))
           {
                var shortName = DocumentRepositoryHelper.TrimDocumentNameToRemoveLeadingFilepath(filename);

                var document = CreateDocument(shortName, saveAction);
                _documentImagesWriter.SaveDocumentImage(document);
                return MapRecordsetToContract(document);
           }
        }

        [IgnoreNumberOfOverloads]
        public Document SaveDocument(string dataFilePath, string filename, SaveActionEnum saveAction)
        {
            return SaveDocument(dataFilePath, filename, saveAction, DocumentStoreType.Default);
        }

        [IgnoreNumberOfOverloads]
        public Document SaveDocument(string dataFilePath, string filename, SaveActionEnum saveAction, DocumentStoreType saveDestination)
        {
            using (new QueryContextAdditionalInfoScope(InfoScope, "SaveDocument"))
            {
                var shortName = DocumentRepositoryHelper.TrimDocumentNameToRemoveLeadingFilepath(filename);

                using (var dataStream = new FileStream(dataFilePath, FileMode.Open))
                {
                    return SaveToDocumentImageTable(dataStream, shortName, null, saveAction, saveDestination);
                }
            }
        }

        public bool DocumentExists(string documentName)
        {
            using (new QueryContextAdditionalInfoScope(InfoScope, "DocumentExists"))
            {
                return _documentImagesReader.DoesDocumentExist(documentName);
            }
        }

        public byte[] GetDocumentData(string documentName)
        {
            using (new QueryContextAdditionalInfoScope(InfoScope, "GetDocumentData"))
            {
                return _documentImagesReader.GetDocumentImageData(documentName);
            }
        }
        
        public byte[] GetDocumentData(long documentId)
        {
            using (new QueryContextAdditionalInfoScope(InfoScope, "GetDocumentData"))
            {
                return _documentImagesReader.GetDocumentImageData(documentId);
            }
        }       

        public void DeleteDocument(string fileName)
        {
            using (new QueryContextAdditionalInfoScope(InfoScope, "DeleteDocumentImage"))
            {
                _documentImagesWriter.DeleteDocumentImage(fileName);
            }
        }

        public void DeleteDocument(long documentId)
        {
            using (new QueryContextAdditionalInfoScope(InfoScope, "DeleteDocumentImage"))
            {
                _documentImagesWriter.DeleteDocumentImage(documentId);
            }
        }

        public void SetDocumentRetentionPeriod(string fileName, int numberOfDaysTillDeletion)
        {
            throw new System.NotImplementedException();
        }

        public void SetDocumentRetentionPeriod(int documentId, int numberOfDaysTillDeletion)
        {
            throw new System.NotImplementedException();
        }

        public void SetDocumentRetentionClass(string filename, string retentionClass)
        {
            throw new System.NotImplementedException();
        }

        public void SetDocumentRetentionClass(int documentId, string retentionClass)
        {
            throw new System.NotImplementedException();
        }

        public string GetDocumentRetentionClass(string fileName)
        {
            throw new System.NotImplementedException();
        }

        public string GetDocumentRetentionClass(int documentId)
        {
            throw new System.NotImplementedException();
        }

        public Document GetDocumentInfo(int documentId)
        {
            using (new QueryContextAdditionalInfoScope(InfoScope, "GetDocument"))
            {
                return _documentImagesReader.GetDocument(documentId);
            }
        }

        public Document GetDocumentInfo(string fileName)
        {
            using (new QueryContextAdditionalInfoScope(InfoScope, "GetDocument"))
            {
                return _documentImagesReader.GetDocument(fileName);
            }
        }

        public bool DocumentExists(int documentId)
        {
            var filename = _documentImagesReader.GetFileName(documentId);
            return DocumentExists(filename);
        }

        private Document SaveToDocumentImageTable(byte[] data, string documentName, long? filestoreId, SaveActionEnum saveAction, DocumentStoreType saveDestination)
        {
            using (new QueryContextAdditionalInfoScope(InfoScope, "SaveToDocumentImageTable"))
            {
                var document = CreateDocument(documentName, saveAction);

                // update the database to contain the data
                document[DocumentImagesTable.Columns.DocImage] = data;
                
                _documentImagesWriter.SaveDocumentImage(document);

                return MapRecordsetToContract(document);
            }            
        }

        private Document MapRecordsetToContract(Recordset document)
        {
            return _recordsetMapper.Create(document);
        }

        private Document SaveToDocumentImageTable(Stream data, string documentName, long? filestoreId, SaveActionEnum saveAction, DocumentStoreType saveDestination)
        {
            using (new QueryContextAdditionalInfoScope(InfoScope, "SaveToDocumentImageTable"))
            {
                var document = CreateDocument(documentName, saveAction);

                // update the database to contain the data
                byte[] bytesRead = ReadStreamContent(data);
                document[DocumentImagesTable.Columns.DocImage] = bytesRead;

                _documentImagesWriter.SaveDocumentImage(document);

                return MapRecordsetToContract(document);
            }
        }

        private byte[] ReadStreamContent(Stream data)
        {
            data.Position = 0;

            var buffer = new byte[16 * 1024];
            using (var ms = new MemoryStream())
            {
                int read;
                while ((read = data.Read(buffer, 0, buffer.Length)) > 0)
                {
                    ms.Write(buffer, 0, read);
                }

                return ms.ToArray();
            }
        }

        private Recordset CreateDocument(string fileName, SaveActionEnum saveAction)
        {
            var document = new Recordset();
            document.AddNew();
            document[DocumentImagesTable.Columns.FileName] = fileName;

            document[DocumentImagesTable.Columns.DateTimeAdded] = Clock.Now();

            if (saveAction == SaveActionEnum.Create)
            {
                document.RowStatus = Recordset.RecordStatus.Added;    
            }
            else if (saveAction == SaveActionEnum.Update)
            {
                document.RowStatus = Recordset.RecordStatus.Modified;
            }
            
            return document;
        }

        public void Dispose()
        {            
        }
    }
}
