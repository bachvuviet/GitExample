﻿using System;
using System.Linq;
using Fnz.Framework.Components.Config;
using Fnz.Framework.DocumentRepository.Api;
using Fnz.Framework.DocumentRepository.DocumentMigration.DataAccess.Readers;

namespace Fnz.Framework.DocumentRepository.DocumentMigration
{
    public class DocumentMigrationCommandHandler : IDocumentMigrationCommandHandler
    {
        private readonly IDocumentMigrationReader _documentMigrationReader;
        private readonly ISystemVariablesReader _systemVariablesReader;
        private readonly IDocumentRepository _documentRepository;

        public DocumentMigrationCommandHandler(IDocumentMigrationReader documentMigrationReader, ISystemVariablesReader systemVariablesReader, IDocumentRepository documentRepository)
        {
            _documentMigrationReader = documentMigrationReader;
            _systemVariablesReader = systemVariablesReader;
            _documentRepository = documentRepository;
        }

        public void Execute(DocumentMigrationCommand command)
        {
            var startingId = _documentMigrationReader.GetLowestDocId();
            var lastStartingId = startingId;
            var toMigrate = _documentMigrationReader.GetDocumentsToMigrate(startingId, command.BatchSize);
            var migrationEnabled = _systemVariablesReader.GetValue<bool>(DocumentSystemVariables.MigrationEnabled.Application, DocumentSystemVariables.MigrationEnabled.Value);

            while (startingId > 0 && migrationEnabled)
            {
                var i = 0;

                foreach (var doc in toMigrate)
                {
                    if (i % 100 == 0)
                    {
                        // Check the system variable every 100 documents
                        migrationEnabled = _systemVariablesReader.GetValue<bool>(DocumentSystemVariables.MigrationEnabled.Application, DocumentSystemVariables.MigrationEnabled.Value);
                        if (!migrationEnabled)
                        {
                            break;
                        }
                    }

                    // Read the document from the latest version of the repository
                    // This should trigger a migration from DocumentImages to the latest version of the filestore
                    _documentRepository.GetDocumentData(doc.Filename);
                    i++;
                }

                // re-read the lowest doc Id 
                startingId = _documentMigrationReader.GetLowestDocId();

                if (lastStartingId == startingId)
                {
                    throw new Exception("Migration of {0} documents starting from DocId {1} failed. DocId {1} has not been removed from DocumentImages. Please investigate.".FormatWith(toMigrate.Count(), startingId));
                }
                
                lastStartingId = startingId;
                toMigrate = _documentMigrationReader.GetDocumentsToMigrate(startingId, command.BatchSize);
            }
        }
    }
}
