using System;
using System.Collections.Generic;
using System.Linq;
using Fnz.Framework.DataAccess;
using Fnz.Framework.DocumentRepository.DocumentMigration.DataAccess.Mappers;
using Fnz.Framework.MetaData.Documents.Documents;
using Fnz.Framework.ReadersWriters;

namespace Fnz.Framework.DocumentRepository.DocumentMigration.DataAccess.Readers
{
    public class DocumentMigrationReader : DataAccessBase, IDocumentMigrationReader
    {
        public DocumentMigrationReader()
            : this(new Dal())
        {           
        }

        public DocumentMigrationReader(IDataAccess dal)
            : base(dal)
        {
        }

        public int GetLowestDocId()
        {
            var result = QueryFactory
                               .Procedure<GetLowestDocumentImageDocIdProcedure>()
                               .WithParameters()
                               .Execute();

            return result.GetAsInteger(GetLowestDocumentImageDocIdProcedure.Columns.LowestDocId, -1);
        }

        public IEnumerable<DocumentToMigrate> GetDocumentsToMigrate(int startingDocumentId, int batchSize)
        {
            return QueryFactory
                   .Procedure<GetFilenamesToMigrateProcedure>()
                   .WithParameters(startingDocumentId, batchSize)
                   .Execute(new DocumentToMigrateMapperForGetFilenamesToMigrateProcedure());
        }
    }
}