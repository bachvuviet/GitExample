using System.Collections.Generic;

namespace Fnz.Framework.DocumentRepository.DocumentMigration.DataAccess.Readers
{
    public interface IDocumentMigrationReader
    {
        /// <summary>
        /// Gets the current lowest DocId in DocumentImages table
        /// </summary>
        /// <returns>-1 if no docId found. Otherwise the lowest DocId in the table.</returns>
        int GetLowestDocId();

        /// <summary>
        /// Gets a list of documents starting at docId <paramref name="startingDocumentId"/>
        /// </summary>
        /// <param name="startingDocumentId">The starting DocId to look for</param>
        /// <param name="batchSize">The maximum number of records to return</param>
        IEnumerable<DocumentToMigrate> GetDocumentsToMigrate(int startingDocumentId, int batchSize);
    }
}