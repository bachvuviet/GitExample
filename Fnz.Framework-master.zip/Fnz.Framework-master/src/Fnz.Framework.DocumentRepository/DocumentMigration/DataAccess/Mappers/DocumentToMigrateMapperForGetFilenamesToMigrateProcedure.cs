﻿using Fnz.Framework.DataAccess.RecordsetMapping;
using Fnz.Framework.DataAccess.RecordsetMapping.Data.ChangeTracking;
using Fnz.Framework.MetaData.Documents.Documents;

namespace Fnz.Framework.DocumentRepository.DocumentMigration.DataAccess.Mappers
{
    public class DocumentToMigrateMapperForGetFilenamesToMigrateProcedure : RecordsetMapper<DocumentToMigrate>
    {
        public DocumentToMigrateMapperForGetFilenamesToMigrateProcedure()
            : base(new ActivatorFactory())
        {
            this.Maps(x => x.DocId).To(GetFilenamesToMigrateProcedure.Columns.DocId);
            this.Maps(x => x.Filename).To(GetFilenamesToMigrateProcedure.Columns.FileName);
        }
    }
}