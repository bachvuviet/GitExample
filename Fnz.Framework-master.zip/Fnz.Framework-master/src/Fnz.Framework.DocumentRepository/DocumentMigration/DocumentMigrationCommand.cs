﻿namespace Fnz.Framework.DocumentRepository.DocumentMigration
{
    public class DocumentMigrationCommand
    {
        public int BatchSize { get; set; }
    }
}