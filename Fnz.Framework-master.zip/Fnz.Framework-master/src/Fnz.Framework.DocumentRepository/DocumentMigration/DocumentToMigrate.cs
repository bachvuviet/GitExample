﻿namespace Fnz.Framework.DocumentRepository.DocumentMigration
{
    public class DocumentToMigrate
    {
        public int DocId { get; set; }

        public string Filename { get; set; }
    }
}