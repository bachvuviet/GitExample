﻿using Fnz.Core.Platform.Framework.Commands;

namespace Fnz.Framework.DocumentRepository.DocumentMigration
{
    /// <summary>
    /// Migrates any document in DocumentImages into the bootstrapped document repository handler
    /// </summary>
    public interface IDocumentMigrationCommandHandler : ICommandHandler<DocumentMigrationCommand>
    {
    }
}
