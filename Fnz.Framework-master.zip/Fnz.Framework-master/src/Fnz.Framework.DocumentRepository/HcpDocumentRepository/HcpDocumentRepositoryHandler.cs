using System;
using System.IO;
using Fnz.Api.Errors;
using Fnz.Framework.Cca.ErrorHandling.Contracts;
using Fnz.Framework.Cca.ErrorHandling.Exceptions;
using Fnz.Framework.Components.Config;
using Fnz.Framework.Components.Environment;
using Fnz.Framework.Components.Tasks.DataAccess.Readers;
using Fnz.Framework.DataAccess;
using Fnz.Framework.DataAccess.Logging;
using Fnz.Framework.DocumentRepository.Api;
using Fnz.Framework.DocumentRepository.Database;
using Fnz.Framework.DocumentRepository.HcpDocumentRepository.DataAccess.Readers;
using Fnz.Framework.DocumentRepository.HcpDocumentRepository.DataAccess.Writers;
using Fnz.Framework.Integration.Hcp.Api;
using Fnz.Framework.Integration.Hcp.Api.Exceptions;
using Fnz.Framework.Util;
using Fnz.Framework.Util.CodeQuality;

namespace Fnz.Framework.DocumentRepository.HcpDocumentRepository
{
    /// <summary>
    /// IDocumentRepository implementation that stores (and loads) documents from the Hitachi Content Platform file store
    /// but can still read content from our legacy file repositories (the database and our internal file store)
    /// </summary>
    [IgnoreNumberOfMethods]
    public class HcpDocumentRepositoryHandler : IDocumentRepository, INextDocumentNameRepository, IDocumentFileNameRepository, IDocumentRepositoryPrivileged
    {
        private const string InfoScope = "DocumentRepositoryHandler";
        
        private readonly IHcpFilestore _hcpFilestore;
        private readonly IHcpFilestoreCollection _hcpFilestoreCollection;

        private readonly IDocumentImagesReader _legacyDocumentsReader;
        private readonly IDocumentImagesWriter _legacyDocumentsWriter;
        private readonly IDocumentsReader _documentsReader;
        private readonly IDocumentsWriter _documentsWriter;
        private readonly ISystemVariablesReader _systemVariablesReader;
        private readonly ITaskRequestReader _taskRequestReader;
        private readonly IDocumentImagesWriter _documentImagesWriter;

        private readonly IExceptionLogger _exceptionLogger;
        private readonly IEnvironmentInformationProvider _environmentInformationProvider;

        public HcpDocumentRepositoryHandler(IHcpFilestore hcpFilestore, IHcpFilestoreCollection hcpFilestoreCollection, IDocumentImagesWriter legacyDocumentsWriter, IDocumentImagesReader legacyDocumentsReader, IDocumentsReader documentsReader, IDocumentsWriter documentsWriter, ISystemVariablesReader systemVariablesReader, IEnvironmentInformationProvider environmentInformationProvider, ITaskRequestReader taskRequestReader, IDocumentImagesWriter documentImagesWriter)
        {
            _hcpFilestore = hcpFilestore;
            _hcpFilestoreCollection = hcpFilestoreCollection;

            _legacyDocumentsReader = legacyDocumentsReader;
            _legacyDocumentsWriter = legacyDocumentsWriter;
            _documentsReader = documentsReader;
            _documentsWriter = documentsWriter;

            _systemVariablesReader = systemVariablesReader;
            _environmentInformationProvider = environmentInformationProvider;
            _taskRequestReader = taskRequestReader;
            _documentImagesWriter = documentImagesWriter;

            _exceptionLogger = new ExceptionDatabaseLogger();
        }

        public Document SaveDocument(Stream data, string documentFileName, short documentTypeId)
        {
            return SaveDocumentPrivate(data, documentFileName, documentTypeId);
        }

        public Document SaveDocument(Stream data, string documentFileName, string retentionClass)
        {
            return SaveDocumentPrivate(data, documentFileName, retentionClass);
        }

        /// <summary>
        /// Save a document using the documentTypeId that might be identified by the filename of the task
        /// </summary>
        /// <param name="filePath">path to the document contents</param>
        /// <param name="filename">the name of the files to store</param>
        /// <param name="taskId">The Id of the task whose request file output we are saviong </param>
        /// <param name="saveDestination">A hint to the implementing class to decide where to store the data to - ignored because the save distination is always HCP)</param>
        public void SaveTaskDocument(string filePath, string filename, int taskId, DocumentStoreType saveDestination)
        {
            // If the task can map to a document category then use the document category when saving
            short? documentTypeId = null;

            if (taskId != 0)
            {
                documentTypeId = _documentsReader.GetTaskDocumentTypeId(taskId);
            }

            using (var dataStream = new FileStream(filePath, FileMode.Open))
            {
                SaveDocumentPrivate(dataStream, filename, documentTypeId);
            }
        }

        /// <summary>
        /// Create a document
        /// </summary>
        /// <param name="data">the file data</param>
        /// <param name="filename">the file name</param>
        /// <param name="saveAction">Ignored - all are treaded as a Create</param>
        /// <returns>details about the created document</returns>
        public Document SaveDocument(byte[] data, string filename, SaveActionEnum saveAction)
        {
            using (var dataStream = new MemoryStream(data))
            {
                return SaveDocumentPrivate(dataStream, filename, (string) null);
            }
        }

        /// <summary>
        /// Create a document
        /// </summary>
        /// <param name="data">the file data</param>
        /// <param name="filename">the file name</param>
        /// <param name="saveAction">Ignored - all are treaded as a Create</param>
        /// <returns>details about the created document</returns>
        public Document SaveDocument(Stream data, string filename, SaveActionEnum saveAction)
        {
            return SaveDocumentPrivate(data, filename, (string) null);
        }

        /// <summary>
        /// Create a document
        /// </summary>
        /// <param name="dataFilePath">the file data (including the filename)</param>
        /// <param name="filename">the file name</param>
        /// <param name="saveAction">Ignored - all are treaded as a Create</param>
        /// <returns>details about the created document</returns>
        public Document SaveDocument(string dataFilePath, string filename, SaveActionEnum saveAction)
        {
            return SaveDocument(dataFilePath, filename, saveAction, DocumentStoreType.Default);
        }

        /// <summary>
        /// Create a document
        /// </summary>
        /// <param name="dataFilePath">the file data (including the filename)</param>
        /// <param name="filename">the file name</param>
        /// <param name="saveAction">Ignored - all are treaded as a Create</param>
        /// <param name="saveDestination">Ignored - all are treates as saving to Hcp Filestore</param>
        /// <returns>details about the created document</returns>
        public Document SaveDocument(string dataFilePath, string filename, SaveActionEnum saveAction, DocumentStoreType saveDestination)
        {
            using (var dataStream = new FileStream(dataFilePath, FileMode.Open))
            {
                return SaveDocumentPrivate(dataStream, filename, (string) null);
            }
        }

        private Document SaveDocumentPrivate(Stream dataStream, string filename, short? documentTypeId)
        {
            string retentionClass = null;

            if (documentTypeId != null)
            {
                retentionClass = _documentsReader.GetDocumentTypeRetentionClass(documentTypeId.Value);
            }

            return SaveDocumentPrivate(dataStream, filename, retentionClass);
        }

        private Document SaveDocumentPrivate(Stream dataStream, string filename, string retentionClass)
        {
            var shortName = DocumentRepositoryHelper.TrimDocumentNameToRemoveLeadingFilepath(filename);

            var toRet = new Document()
                            {
                                DateTimeAdded = Clock.Now(),
                                Filename = filename
                            };
            var hcpPath = GetHcpPath(toRet);

            using (var ts = new TransactionAndConnectionScope())
            {
                using (new QueryContextAdditionalInfoScope(InfoScope, "DocumentExists-Hcp"))
                {
                    try
                    {
                        // Always do the save to HCP first because it is not part of the DB transaction, and we don't want the DB metadata
                        // left behind if the save to HCP fails
                        SaveToHcpFilestore(dataStream, hcpPath, retentionClass);

                        toRet = SaveMetaDataToDocumentsTable(shortName, toRet.DateTimeAdded, hcpPath);
                    }
                    catch (Exception e)
                    {
                        // If we can save to HCP then try to save to the document images table instead. It will be migrated to the 
                        // HCP server anyway when the document is next read (and HCP is available)
                        _exceptionLogger.LogException(e, string.Empty,
                                                      "Saving to HCP failed - falling back to saving to the DocumentImages table. Filename: " +
                                                      filename);
                        var documentRecordset = CreateDocument(shortName, dataStream);
                        _documentImagesWriter.SaveDocumentImage(documentRecordset);

                        toRet.Id = documentRecordset.GetInteger(DocumentImagesTable.Columns.DocId);
                    }
                }

                ts.Complete();
            }

            return toRet;
        }

        public bool DocumentExists(int documentId)
        {
            var document = _documentsReader.GetDocument(documentId);
            return DocumentExists(document.Filename);
        }

        public bool DocumentExists(string fileName)
        {
            using (new QueryContextAdditionalInfoScope(InfoScope, "DocumentExists-Hcp"))
            {
                if (_documentsReader.GetDocument(fileName) != null)
                {
                    return true;
                }

                return _legacyDocumentsReader.DoesDocumentExist(fileName);
            }
        }

        public byte[] GetDocumentData(string fileName)
        {
            using (new QueryContextAdditionalInfoScope(InfoScope, "GetDocumentData"))
            {
                Document legacyDocument;
                var document = _documentsReader.GetHcpDocument(fileName);

                try
                {
                    if (document != null)
                    {
                        return GetFileData(document);
                    }
                }
                catch (Exception)
                {
                    // Error occured when talking to HCP so try to get the data from the legacy repositories (filestore and DB)
                    legacyDocument = _legacyDocumentsReader.GetDocument(fileName);
                    return GetLegacyFileData(legacyDocument, false);
                }

                // Can't find the data in HCP so try to get the data from the legacy repositories (filestore and DB)
                legacyDocument = _legacyDocumentsReader.GetDocument(fileName);

                return GetLegacyFileData(legacyDocument, true);
            }            
        }

        public byte[] GetDocumentData(long documentId)
        {
            using (new QueryContextAdditionalInfoScope(InfoScope, "GetDocumentData"))
            {
                Document legacyDocument;
                var document = _documentsReader.GetHcpDocument((int) documentId);

                try
                {
                    if (document != null)
                    {
                        return GetFileData(document);
                    }
                }
                catch (Exception)
                {
                    // Error occured when talking to HCP so try to get the data from the legacy repositories (filestore and DB)
                    legacyDocument = _legacyDocumentsReader.GetDocument(documentId);
                    return GetLegacyFileData(legacyDocument, false);
                }

                // Can't find the data in HCP so try to get the data from the legacy repositories (filestore and DB)
                legacyDocument = _legacyDocumentsReader.GetDocument(documentId);
                return GetLegacyFileData(legacyDocument, true);
            }
        }

        private Stream GetDocumentDataStreamed(HcpDocument document)
        {
            try
            {
                return _hcpFilestore.Get(GetFullHcpPath(document.Path));
            }
            catch (ResourceNotFoundException)
            {
                throw new EntityNotFoundException(
                    new ErrorCode(100053, "Requested document was not found"), 
                    "Document not found",
                    new ErrorParameter { Name = " document.Path", Value = document.Path });
            }
        }

        private byte[] GetFileData(HcpDocument document)
        {
            var documentDataStream = GetDocumentDataStreamed(document);
            return StreamUtils.GetByteArrayFromStream(documentDataStream);
        }
        
        private byte[] GetLegacyFileData(Document legacyDocument, bool migrateToHcp)
        {            
            if (legacyDocument == null)
            {
                return null;
            }

            using (new QueryContextAdditionalInfoScope(InfoScope, "GetDocumentData-Hcp"))
            {                    
                var toRet = GetFileDataFromLegacySources(legacyDocument);

                if (migrateToHcp && toRet != null)
                {
                    try
                    {
                        MigrateTheFileDataToHcpFilestore(legacyDocument, toRet); 
                    }
                    catch (Exception e)
                    {
                        _exceptionLogger.LogException(e, string.Empty, "Migrating to HCP failed. Filename: " + legacyDocument.Filename);
                    }
                }                    

                return toRet;
            }
        }

        private string GetHcpPath(Document document)
        {
            // Should be in the folder "/environment/yyyy/mm/dd/hh/extension/"
            return
                   document.DateTimeAdded.Year + "/" + document.DateTimeAdded.Month + "/" +
                   document.DateTimeAdded.Day + "/" + document.DateTimeAdded.Hour +
                   GetFileExtension(document.Filename.ToLower()) + "/" +
                   UrlEncode(Escape(document.Filename));
        }

        private string Escape(string filename)
        {
            return filename.Replace('/', '-');
        }        

        private string UrlEncode(string filename)
        {
            // tried to use HttpUtility.UrlEncode(), but it would cause it to break for spaces for some reason.
            // So for now we just encode the special characters that we know are in filenames
            // return HttpUtility.UrlEncode(filename)
            return filename.Replace("+", "%2B");
        }

        private string GetFileExtension(string fileName)
        {
            string[] splitString = fileName.Split('.');
            if (splitString.Length > 1)
            {
                return "/" + splitString[splitString.Length - 1].ToLower();
            }

            return string.Empty;
        }

        private string GetEnvironmentName()
        {
            return _environmentInformationProvider.GetCurrentEnvironmentName(); 
        }

        private void MigrateTheFileDataToHcpFilestore(Document legacyDocument, byte[] data)
        {
            using (var ts = new TransactionAndConnectionScope())
            {                            
                var hcpPath = GetHcpPath(legacyDocument);

                // Save the document metadata in the DB
                _documentsWriter.AddMigratedDocument(legacyDocument.Filename, Clock.Now(), legacyDocument.DateTimeAdded, hcpPath, legacyDocument.Id, legacyDocument.LegacyFilestoreId);

                if (_systemVariablesReader.GetValue<bool>(DocumentSystemVariables.ShouldDeleteMigratedDocument.Application, DocumentSystemVariables.ShouldDeleteMigratedDocument.Value))
                {
                    _legacyDocumentsWriter.DeleteDocumentImage(legacyDocument.Filename);
                }

                // Save the document to the HCP repository
                using (Stream dataStream = new MemoryStream(data))
                {
                    string retentionClass = null;

                    // Look up the filename in the taskrequests table to see if it has a matching filename
                    // - if it does we can get the taskId and thus the documentTypeId
                    var taskId = _taskRequestReader.GetTaskIdForFileName(legacyDocument.Filename);
                    if (taskId != 0)
                    {
                        var documentTypeId = _documentsReader.GetTaskDocumentTypeId(taskId);

                        if (documentTypeId != null)
                        {
                            retentionClass = _documentsReader.GetDocumentTypeRetentionClass(documentTypeId.Value);
                        }
                    }

                    SaveToHcpFilestore(dataStream, hcpPath, retentionClass);   
                }

                // Commit the DB transaction if the HCP update was succesfull
                ts.Complete();
            }
        }

        private byte[] GetFileDataFromLegacySources(Document document)
        {
            byte[] toRet = null;

            // Get the data from the legacy filestore
            if (document.LegacyFilestoreId.HasValue && document.LegacyFilestoreId != 0)
            {
                DocumentRepositoryHelper.CreateAndReportError(document.Filename, "We would have attempted to load a document (with LegacyFilestoreId '{0}') from the legacy filestore (IFilestoreRepository), but we don't syupport that anymore".FormatWith(document.LegacyFilestoreId));
            }

            // If no data then fall back to attempting to get it from the database 
            if (toRet == null)
            {
                // Obtain the image column from the database (we did not select it in the earlier query to the documentimage table because we
                // thought we did not need it
                toRet = _legacyDocumentsReader.GetDocumentImageData(document.Filename);
            }

            return toRet;
        } 

        public void DeleteDocument(string fileName)
        {
            var retentionClass = GetDocumentRetentionClass(fileName);
 
            if (retentionClass == null)
            {
                SetDocumentRetentionPeriod(fileName, 1);
            }
            else
            {
                throw new Exception("You can't delete a document that has a retention class set on it");
            }
        }
 
        public void DeleteDocument(long documentId)
        {
            var retentionClass = GetDocumentRetentionClass((int)documentId);
 
            if (retentionClass == null)
            {
                SetDocumentRetentionPeriod((int)documentId, 1);
            }
            else
            {
                throw new Exception("You can't delete a document that has a retention class set on it");
            }
        }

        public void SetDocumentRetentionPeriod(string fileName, int numberOfDaysTillDeletion)
        {
            SetDocumentRetention(_documentsReader.GetHcpDocument(fileName), "N+" + numberOfDaysTillDeletion + "d");
        }

        public void SetDocumentRetentionPeriod(int documentId, int numberOfDaysTillDeletion)
        {
            SetDocumentRetention(_documentsReader.GetHcpDocument(documentId), "N+" + numberOfDaysTillDeletion + "d");
        }

        public void SetDocumentRetentionClass(string fileName, string retentionClass)
        {
            SetDocumentRetention(_documentsReader.GetHcpDocument(fileName), "C+" + retentionClass);
        }

        public void SetDocumentRetentionClass(int documentId, string retentionClass)
        {
            SetDocumentRetention(_documentsReader.GetHcpDocument(documentId), "C+" + retentionClass);
        }

        private void SetDocumentRetention(HcpDocument document, string retention)
        {
            try
            {
                var fullHcpPath = GetFullHcpPath(document.Path);
                _hcpFilestore.PostRetention(fullHcpPath, retention);
            }
            catch (ResourceNotFoundException)
            {
                throw new EntityNotFoundException(
                    new ErrorCode(100053, "Requested document was not found"),
                    "Document not found",
                    new ErrorParameter { Name = " document.Path", Value = document.Path });
            }
        }

        public string GetDocumentRetentionClass(string fileName)
        {
            var document = _documentsReader.GetHcpDocument(fileName);
            return GetDocumentRetentionClass(document);
        }

        public string GetDocumentRetentionClass(int documentId)
        {
            var document = _documentsReader.GetHcpDocument(documentId);
            return GetDocumentRetentionClass(document);
        }

        public Document GetDocumentInfo(int documentId)
        {
            using (new QueryContextAdditionalInfoScope(InfoScope, "GetDocument"))
            {
                // Fallback to Legacy Store when Getting Document - Same Logic as GetDocumentData
                return _documentsReader.GetDocument(documentId) ?? _legacyDocumentsReader.GetDocument(documentId);
            }
        }

        public Document GetDocumentInfo(string fileName)
        {
            using (new QueryContextAdditionalInfoScope(InfoScope, "GetDocument"))
            {
                // Fallback to Legacy Store when Getting Document - Same Logic as GetDocumentData
                return _documentsReader.GetDocument(fileName) ?? _legacyDocumentsReader.GetDocument(fileName);
            }
        }

        private string GetDocumentRetentionClass(HcpDocument document)
        {
            var headers = _hcpFilestore.Head(GetFullHcpPath(document.Path));
            return headers.RetentionClass;
        }

        private void SaveToHcpFilestore(Stream data, string hcpPath, string retentionClass) 
        {
            string retention = null;

            if (retentionClass != null)
            {
                retention = "C+" + retentionClass;
            }

            _hcpFilestoreCollection.Put(data, GetFullHcpPath(hcpPath), retention);
        }

        private string GetFullHcpPath(string hcpPath)
        {
            return GetEnvironmentName() + "/" + hcpPath;
        }

        private Document SaveMetaDataToDocumentsTable(string documentName, DateTime creationDate, string hcpPath)
        {
            using (new QueryContextAdditionalInfoScope(InfoScope, "SaveToDocumentsTable-Hcp"))
            {
                return _documentsWriter.AddDocument(documentName, creationDate, hcpPath);
            }
        }

        public void Dispose()
        {
        }

        private Recordset CreateDocument(string fileName, Stream dataStream)
        {
            byte[] fileData = ReadStreamContent(dataStream);

            var document = new Recordset();
            document.AddNew();
            document[DocumentImagesTable.Columns.FileName] = fileName;  
            document[DocumentImagesTable.Columns.DateTimeAdded] = Clock.Now();
            document[DocumentImagesTable.Columns.DocImage] = fileData;
            document.RowStatus = Recordset.RecordStatus.Added;

            return document;
        }

        private byte[] ReadStreamContent(Stream data)
        {
            data.Position = 0;

            var buffer = new byte[16 * 1024];
            using (var ms = new MemoryStream())
            {
                int read;
                while ((read = data.Read(buffer, 0, buffer.Length)) > 0)
                {
                    ms.Write(buffer, 0, read);
                }

                return ms.ToArray();
            }
        }

        /// <summary>
        /// Only used by FTP handling so not sure I really want this here long term; but need a means of transitioning.
        /// </summary>
        /// <param name="fileName">filename (everything up to the .)</param>
        /// <param name="extension">externsion portion of the filename (everything after the .)</param>
        /// <returns>Count of Documents with structural duplication</returns>
        public int GetNextDocumentNameSuffixForDuplicateDocument(string fileName, string extension)
        {
            return _documentsReader.GetDocumentSuffixForDuplicateFile(fileName, extension);
        }

        /// <summary>
        /// Used by a few methods; this may actually be useful on the FNZ.Framework interface (though returning the whole document object by DocID is probably useful ).
        /// </summary>
        /// <param name="docId">document id (document.documents.id)</param>
        /// <returns>filename of document with input id</returns>
        public string GetDocumentFilenameByDocId(int docId)
        {
            return _documentsReader.GetDocument(docId).Filename;
        }

        public void PrivilegedDelete(long documentId)
        {
            var documentAndInHcp = GetDocumentMetaDataFromHcpOrLegacy(documentId);
            PrivilegedDeletePrivate(documentAndInHcp.Item1, documentAndInHcp.Item2);
        }

        public void PrivilegedDelete(string fileName)
        {
            var documentAndInHcp = GetDocumentMetaDataFromHcpOrLegacy(fileName);
            PrivilegedDeletePrivate(documentAndInHcp.Item1, documentAndInHcp.Item2);
        }

        public void PrivilegedDeletePrivate(Document document, bool isInHcp)
        {
            if (isInHcp)
            {
                SetDocumentRetentionPeriod((int) document.Id, 1);
                _documentsWriter.DeleteDocument(document.Id);
            }
            else
            {
                using (new QueryContextAdditionalInfoScope(InfoScope, "PrivilegedDeletePrivate"))
                {
                    _documentImagesWriter.DeleteDocumentImage(document.Filename);
                }
            }
        }

        private Tuple<Document, bool> GetDocumentMetaDataFromHcpOrLegacy(long documentId)
        {
            bool isInHcp = true;
            var document = _documentsReader.GetDocument((int)documentId);
            if (document == null)
            {
                isInHcp = false;
                document = _legacyDocumentsReader.GetDocument(documentId);
            }

            return new Tuple<Document, bool>(document, isInHcp);
        }

        private Tuple<Document, bool> GetDocumentMetaDataFromHcpOrLegacy(string fileName)
        {
            bool isInHcp = true;
            var document = _documentsReader.GetDocument(fileName);
            if (document == null)
            {
                isInHcp = false;
                document = _legacyDocumentsReader.GetDocument(fileName);
            }

            return new Tuple<Document, bool>(document, isInHcp);
        }
    }
}
