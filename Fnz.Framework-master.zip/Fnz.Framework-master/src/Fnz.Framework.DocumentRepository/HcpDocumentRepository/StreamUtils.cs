﻿using System.IO;

namespace Fnz.Framework.DocumentRepository.HcpDocumentRepository
{
    public static class StreamUtils
    {
        public static byte[] GetByteArrayFromStream(Stream stream)
        {
            byte[] toRet;

            using (var memoryStream = new MemoryStream())
            {
                try
                {
                    var buffer = new byte[8192];

                    //not very efficent, however the length of the stream is unknown, so using a buffer for now
                    var bytesRead = stream.Read(buffer, 0, buffer.Length);
                    while (bytesRead > 0)
                    {
                        memoryStream.Write(buffer, 0, bytesRead);
                        bytesRead = stream.Read(buffer, 0, buffer.Length);
                    }

                    toRet = memoryStream.ToArray();
                }
                finally
                {
                    stream.Dispose();
                }
            }

            return toRet;
        }
    }
}
