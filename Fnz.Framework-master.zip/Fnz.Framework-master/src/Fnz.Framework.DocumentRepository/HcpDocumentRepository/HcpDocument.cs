namespace Fnz.Framework.DocumentRepository.HcpDocumentRepository
{
    public class HcpDocument
    {
        public int Id { get; set; }

        public string Path { get; set; }
    }
}