using Fnz.Framework.DataAccess;
using Fnz.Framework.DocumentRepository.Api;
using Fnz.Framework.DocumentRepository.HcpDocumentRepository.DataAccess.Mappers;
using Fnz.Framework.MetaData.Documents.Documents;
using Fnz.Framework.ReadersWriters;

namespace Fnz.Framework.DocumentRepository.HcpDocumentRepository.DataAccess.Readers
{
    public class DocumentsReader : DataAccessBase, IDocumentsReader
    {
        public DocumentsReader()
            : this(new Dal())
        {           
        }

        public DocumentsReader(IDataAccess dal)
            : base(dal)
        {
        }

        public Document GetDocument(int documentId)
        {
            return QueryFactory
               .Procedure<GetDocumentByDocumentIdProcedure>()
               .WithParameters(documentId)
               .ExecuteAndReturnFirst(new DocumentMapperForGetDocumentByDocumentIdProcedure());
        }  
        
        public Document GetDocument(string filename)
        {
            var toRet = QueryFactory
               .Procedure<GetDocumentByFilenameProcedure>()
               .WithParameters(filename)
               .ExecuteAndReturnFirst(new DocumentMapperForGetDocumentByFilenameProcedure());

            if (toRet != null)
            {
                toRet.Filename = filename;   
            }            

            return toRet;
        }

        public HcpDocument GetHcpDocument(int documentId)
        {
            return QueryFactory
               .Procedure<GetHcpDocumentByDocumentIdProcedure>()
               .WithParameters(documentId)
               .ExecuteAndReturnFirst(new DocumentMapperForGetHcpDocumentByDocumentIdProcedure());
        }

        public HcpDocument GetHcpDocument(string filename)
        {
            var toRet = QueryFactory
               .Procedure<GetHcpDocumentByFilenameProcedure>()
               .WithParameters(filename)
               .ExecuteAndReturnFirst(new DocumentMapperForGetHcpDocumentByFilenameProcedure());   

            return toRet;
        }

        public int GetDocumentSuffixForDuplicateFile(string fileName, string extension)
        {
            return QueryFactory
                .Procedure<GetDocumentCountForSuffixCreationProcedure>()
                .WithParameters(fileName, extension)
                .Execute()
                .GetInteger(GetDocumentCountForSuffixCreationProcedure.Columns.Count);
        }  
        
        public string GetDocumentTypeRetentionClass(short documentTypeId)
        {
            return QueryFactory
                .Procedure<GetDocumentTypeRetentionClassProcedure>()
                .WithParameters(documentTypeId)
                .Execute()
                .GetString(GetDocumentTypeRetentionClassProcedure.Columns.RetentionClassName, null);            
        }

        public short? GetTaskDocumentTypeId(int taskId)
        {
            var toRet = QueryFactory
                .Procedure<GetTaskDocumentTypeIdProcedure>()
                .WithParameters(taskId)
                .Execute()
                .GetInteger(GetTaskDocumentTypeIdProcedure.Columns.DocumentTypeId, 0);

            if (toRet == 0)
            {
                return null;
            } 
            else
            {
                return (short?) toRet;    
            }
        }
    }
}