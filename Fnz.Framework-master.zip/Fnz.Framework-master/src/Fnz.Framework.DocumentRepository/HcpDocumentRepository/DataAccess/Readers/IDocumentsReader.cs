using Fnz.Framework.DocumentRepository.Api;

namespace Fnz.Framework.DocumentRepository.HcpDocumentRepository.DataAccess.Readers
{
    public interface IDocumentsReader
    {
        /// <summary>
        /// Gets details of the document stored in Platform.Documents.Document based on the DocumentID
        /// </summary>
        /// <param name="documentId">Unique ID of document</param>
        /// <returns>document details</returns>
        Document GetDocument(int documentId);

        /// <summary>
        /// Gets details of the document stored in Platform.Documents.Document based on the Filename
        /// </summary>
        /// <param name="filename">Unique filename of the document</param>
        /// <returns>document details</returns>
        Document GetDocument(string filename); 
        
        /// <summary>
        /// Gets HCP details about a document (path stored)
        /// </summary>
        /// <param name="documentId">Unique Document ID</param>
        /// <returns>HCP specific document details</returns>
        HcpDocument GetHcpDocument(int documentId);

        /// <summary>
        /// Gets HCP details about a document (path stored)
        /// </summary>
        /// <param name="filename">unique filename of the document</param>
        /// <returns>HCP specific document details</returns>
        HcpDocument GetHcpDocument(string filename);

        /// <summary>
        /// Gets the retention class name based on a type id (Documents.DocumentTypes)
        /// </summary>
        /// <param name="documentTypeId">Document Type identifier</param>
        /// <returns>retention class</returns>
        string GetDocumentTypeRetentionClass(short documentTypeId);

        /// <summary>
        /// Gets the document type id based on a task number
        /// </summary>
        /// <param name="taskId">task id (tasksb..tasks2)</param>
        /// <returns>DocumentTYpeID</returns>
        short? GetTaskDocumentTypeId(int taskId);

        /// <summary>
        /// This call will check the Documents.Documents table for the next filename that can be used based on filename%.extension
        /// The call will return the count of files matching the current result; the assumption being that incrementating by 1 will be an unused name.
        /// There's probably better ways to do this; but this keeps the cost of execution a bit lower.
        /// </summary>
        /// <param name="fileName">filename without extension</param>
        /// <param name="extension">file extension</param>
        /// <returns>count of files in use so far</returns>
        int GetDocumentSuffixForDuplicateFile(string fileName, string extension);
    }
}