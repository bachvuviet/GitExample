using System;
using Fnz.Framework.DataAccess;
using Fnz.Framework.DocumentRepository.Api;
using Fnz.Framework.MetaData.Documents.Documents;
using Fnz.Framework.ReadersWriters;

namespace Fnz.Framework.DocumentRepository.HcpDocumentRepository.DataAccess.Writers
{
    public class DocumentsWriter : DataAccessBase, IDocumentsWriter
    {
        public DocumentsWriter()
            : this(new Dal())
        {           
        }

        public DocumentsWriter(IDataAccess dal)
            : base(dal)
        {
        }

        public Document AddDocument(string filename, DateTime dateTimeAdded, string hcpPath)
        { 
            var result = QueryFactory
               .Procedure<AddDocumentProcedure>()
               .WithParameters(filename, dateTimeAdded, 0)
               .AndOptionalParameter(x => x.HcpPath, hcpPath)
               .ExecuteWithOutputValues<AddDocumentProcedure.OutputValues>();

            if (result == null)
            {
                return null;
            }

            return new Document() { DateTimeAdded = dateTimeAdded, Filename = filename, Id = result.DocumentId };
        }

        public Document AddMigratedDocument(string filename, DateTime dateTimeAdded, DateTime dateTimeOriginallyAdded, string hcpPath, long documentImagesId, long? oldFilestoreId)
        { 
            var result = QueryFactory
               .Procedure<AddMigratedDocumentProcedure>()
               .WithParameters(filename, dateTimeAdded, dateTimeOriginallyAdded, hcpPath, (int)documentImagesId)
               .AndOptionalParameter(x => x.OldFilestoreId, (int?)oldFilestoreId)
               .ExecuteWithOutputValues<AddMigratedDocumentProcedure.OutputValues>();

            if (result == null)
            {
                return null;
            }

            return new Document() { DateTimeAdded = dateTimeAdded, Filename = filename, Id = documentImagesId };
        }

        public void DeleteDocument(long documentId)
        {
            QueryFactory
                .Procedure<DeleteDocumentProcedure>()
                .WithParameters((int)documentId)
                .Execute();
        }
    }
}