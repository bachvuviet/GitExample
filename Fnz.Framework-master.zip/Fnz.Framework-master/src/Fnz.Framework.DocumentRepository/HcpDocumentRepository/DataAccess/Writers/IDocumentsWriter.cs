using System;
using Fnz.Framework.DocumentRepository.Api;

namespace Fnz.Framework.DocumentRepository.HcpDocumentRepository.DataAccess.Writers
{
    public interface IDocumentsWriter
    {        
        Document AddDocument(string filename, DateTime dateTimeAdded, string hcpPath);

        Document AddMigratedDocument(string filename, DateTime dateTimeAdded, DateTime dateTimeOriginallyAdded, string hcpPath, long oldDocumentImagesId, long? oldFilestoreId);

        void DeleteDocument(long documentId);
    }
}