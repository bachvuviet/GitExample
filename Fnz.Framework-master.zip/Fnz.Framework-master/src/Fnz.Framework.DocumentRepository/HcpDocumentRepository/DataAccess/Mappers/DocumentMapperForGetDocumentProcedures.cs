using Fnz.Framework.DataAccess.RecordsetMapping;
using Fnz.Framework.DataAccess.RecordsetMapping.Data.ChangeTracking;
using Fnz.Framework.DocumentRepository.Api;
using Fnz.Framework.MetaData.Documents.Documents;

namespace Fnz.Framework.DocumentRepository.HcpDocumentRepository.DataAccess.Mappers
{
    public class DocumentMapperForGetDocumentByDocumentIdProcedure : RecordsetMapper<Document>
    {
        public DocumentMapperForGetDocumentByDocumentIdProcedure()
            : base(new ActivatorFactory())
        {
            this.Maps(x => x.DateTimeAdded).To(GetDocumentByDocumentIdProcedure.Columns.DateTimeAdded);
            this.Maps(x => x.Filename).To(GetDocumentByDocumentIdProcedure.Columns.Filename);
            this.Maps(x => x.Id).To(GetDocumentByDocumentIdProcedure.Columns.DocumentId);
        }
    }
}