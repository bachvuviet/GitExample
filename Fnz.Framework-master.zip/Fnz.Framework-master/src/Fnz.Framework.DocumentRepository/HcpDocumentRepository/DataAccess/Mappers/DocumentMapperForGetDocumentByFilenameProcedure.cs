using Fnz.Framework.DataAccess.RecordsetMapping;
using Fnz.Framework.DataAccess.RecordsetMapping.Data.ChangeTracking;
using Fnz.Framework.DocumentRepository.Api;
using Fnz.Framework.MetaData.Documents.Documents;

namespace Fnz.Framework.DocumentRepository.HcpDocumentRepository.DataAccess.Mappers
{
    public class DocumentMapperForGetDocumentByFilenameProcedure : RecordsetMapper<Document>
    {
        public DocumentMapperForGetDocumentByFilenameProcedure()
            : base(new ActivatorFactory())
        {
            this.Maps(x => x.DateTimeAdded).To(GetDocumentByFilenameProcedure.Columns.DateTimeAdded);
            this.Maps(x => x.Id).To(GetDocumentByFilenameProcedure.Columns.DocumentId);
        }
    }
}