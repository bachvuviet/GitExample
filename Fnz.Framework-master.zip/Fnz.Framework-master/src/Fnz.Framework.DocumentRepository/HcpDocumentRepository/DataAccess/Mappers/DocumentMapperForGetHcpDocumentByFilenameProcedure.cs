using Fnz.Framework.DataAccess.RecordsetMapping;
using Fnz.Framework.DataAccess.RecordsetMapping.Data.ChangeTracking;
using Fnz.Framework.DocumentRepository.Api;
using Fnz.Framework.MetaData.Documents.Documents;

namespace Fnz.Framework.DocumentRepository.HcpDocumentRepository.DataAccess.Mappers
{
    public class DocumentMapperForGetHcpDocumentByFilenameProcedure : RecordsetMapper<HcpDocument>
    {
        public DocumentMapperForGetHcpDocumentByFilenameProcedure()
            : base(new ActivatorFactory())
        {
            this.Maps(x => x.Path).To(GetHcpDocumentByFilenameProcedure.Columns.HcpPath);
            this.Maps(x => x.Id).To(GetHcpDocumentByFilenameProcedure.Columns.DocumentId);
        }
    }
}