﻿namespace Fnz.Framework.DocumentRepository
{
    public static class DocumentSystemVariables
    {
        public class MigrationEnabled
        {
            public const string Application = "HcpMigration";

            public const string Value = "Enabled";    
        }

        public class ShouldDeleteMigratedDocument
        {
            public const string Application = "HcpFilestore";

            public const string Value = "ShouldDeleteMigratedDocument";
        }
    }
}