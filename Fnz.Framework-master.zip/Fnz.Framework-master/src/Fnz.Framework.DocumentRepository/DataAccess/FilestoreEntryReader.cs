using Fnz.Framework.DataAccess;
using Fnz.Framework.DocumentRepository.Database;
using Fnz.Framework.ReadersWriters;

namespace Fnz.Framework.DocumentRepository
{
    public interface IFilestoreEntryReader
    {
        /// <summary>
        /// Get a FilestoreEntry from database.
        /// </summary>
        /// <param name="id">The Id of FilestoreEntry to get</param>
        /// <param name="fields">The fields to get</param>
        /// <returns>Record with FilestoreEntry</returns>
        IRecordset GetFilestoreEntry(long id, string[] fields);
    }

    public class FilestoreEntryReader : DataAccessBase, IFilestoreEntryReader
    {
        public FilestoreEntryReader(IDataAccessBaseParameter dataAccessBaseParameter)
            : base(dataAccessBaseParameter)
        {
        }        

        public IRecordset GetFilestoreEntry(long id, string[] fields)
        {
            var search = new Params { this.Column(FilestoreEntryTable.Columns.Id).IsEqualTo(id) };
            return QueryFactory.Select(fields).From<FilestoreEntryTable>().Where(search).Execute();
        }
    }
}
