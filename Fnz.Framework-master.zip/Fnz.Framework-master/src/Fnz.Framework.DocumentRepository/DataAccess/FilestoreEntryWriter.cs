﻿using Fnz.Framework.DataAccess;
using Fnz.Framework.DocumentRepository.Database;
using Fnz.Framework.ReadersWriters;

namespace Fnz.Framework.DocumentRepository
{
    public interface IFilestoreEntryWriter
    {
        /// <summary>
        /// Save a FilestoreEntry to the database
        /// </summary>
        /// <param name="data">FilestoreEntry information</param>
        void Save(Recordset data);
    }

    public class FilestoreEntryWriter : DataAccessBase, IFilestoreEntryWriter
    {
        public FilestoreEntryWriter(IDataAccessBaseParameter dataAccessBaseParameter)
            : base(dataAccessBaseParameter)
        {
        }

        public void Save(Recordset data)
        {
            DataAccess.SaveRecordset<FilestoreEntryTable>(data, true);
        }
    }
}
