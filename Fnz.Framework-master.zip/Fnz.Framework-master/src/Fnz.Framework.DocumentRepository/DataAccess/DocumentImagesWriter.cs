﻿using System;
using Fnz.Framework.DataAccess;
using Fnz.Framework.DocumentRepository.Database;
using Fnz.Framework.MetaData.Documents.Documents;
using Fnz.Framework.ReadersWriters;

namespace Fnz.Framework.DocumentRepository
{
    public interface IDocumentImagesWriter
    {
        /// <summary>
        /// Save a document image to the database
        /// </summary>
        /// <param name="data">document information</param>
        void SaveDocumentImage(Recordset data);
        
        void DeleteDocumentImage(string fileName);

        void DeleteDocumentImage(long documentId);
    }

    public class DocumentImagesWriter : DataAccessBase, IDocumentImagesWriter
    {
        public DocumentImagesWriter(IDataAccessBaseParameter dataAccessBaseParameter)
            : base(dataAccessBaseParameter)
        {
        }

        public void SaveDocumentImage(Recordset data)
        {
            // Instead of saving using 'DataAccess.SaveRecordset<DocumentImagesTable>(data, true)' we now have to save using an SP, because
            // the DocumentImages table is in another database, so can only be referenced via a DB synonym - which means we need to do this from an SP
            // and have to do it one row at a time - note we are assuming that all document saves are an Insert because we don't support updating of documents
            foreach (var document in data)
            {
                var filename = data.GetString(DocumentImagesTable.Columns.FileName);
                var dateTimeAdded = data.GetDateTime(DocumentImagesTable.Columns.DateTimeAdded);
                var documentImage = data.GetByteArray(DocumentImagesTable.Columns.DocImage);

                var ret = QueryFactory
                    .Procedure<AddLegacyDocumentImageProcedure>()
                    .WithParameters(filename, dateTimeAdded, documentImage, 0)
                    .ExecuteWithOutputValues<AddLegacyDocumentImageProcedure.OutputValues>();

                data[DocumentImagesTable.Columns.DocId] = ret.DocId;
            }            
        }

        public void DeleteDocumentImage(string fileName)
        {
            QueryFactory
                   .Procedure<DeleteLegacyDocumentImageProcedure>()
                   .WithParameters(fileName)
                   .Execute();
        }

        public void DeleteDocumentImage(long documentId)
        {
            var documents = QueryFactory
                    .Procedure<GetLegacyDocumentFilenameByDocIdProcedure>()
                    .WithParameters((int)documentId)
                    .Execute();

            if (documents.Count() == 0)
            {
                throw new Exception("The document does not exist");
            }

            var filename = documents.GetString(GetLegacyDocumentFilenameByDocIdProcedure.Columns.Filename);
            DeleteDocumentImage(filename);
        }
    }
}
