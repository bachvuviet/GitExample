using System.Linq;
using Fnz.Framework.DocumentRepository.Api;
using Fnz.Framework.MetaData.Documents.Documents;
using Fnz.Framework.ReadersWriters;

namespace Fnz.Framework.DocumentRepository
{
    public interface IDocumentImagesReader
    {
         /// <summary>
         /// Rretrieve the filename of a document given its document id
         /// </summary>
        /// <param name="documentId">document identifier</param>
         /// <returns>filename as string</returns>
        string GetFileName(long documentId);
        
        /// <summary>
        /// Get the data of a document.
        /// </summary>
        /// <param name="fileName">The name of document whose data we want to  get</param>
        /// <returns>the document data</returns>
        byte[] GetDocumentImageData(string fileName);

        /// <summary>
        /// Get the data of a document.
        /// </summary>
        /// <param name="docId">The docId of document whose data we want to  get</param>
        /// <returns>the document data</returns>
        byte[] GetDocumentImageData(long docId);
        
        /// <summary>
        /// Returns true if a document exists with the specified filename
        /// </summary>
        /// <param name="fileName">The name of document to get</param>
        /// <returns>Record with document</returns>
        bool DoesDocumentExist(string fileName);

        /// <summary>
        /// Get a document from database.
        /// </summary>
        /// <param name="documentId">The DocId of the document to get</param>
        /// <returns>Record with document</returns>
        Document GetDocument(long documentId);

        /// <summary>
        /// Get a document from database.
        /// </summary>
        /// <param name="fileName">The name of the document to get</param>
        /// <returns>Record with document</returns>
        Document GetDocument(string fileName);
    }

    public class DocumentImagesReader : DataAccessBase, IDocumentImagesReader
    {
        public DocumentImagesReader(IDataAccessBaseParameter dataAccessBaseParameter)
            : base(dataAccessBaseParameter)
        {
        }

        public string GetFileName(long documentId) // should really be a int because the column in the DB is an int
        {
            var toRet = QueryFactory
                    .Procedure<GetLegacyDocumentFilenameByDocIdProcedure>()
                    .WithParameters((int)documentId) 
                    .Execute();

            return toRet.GetString(GetLegacyDocumentFilenameByDocIdProcedure.Columns.Filename);
        }      
        
        public byte[] GetDocumentImageData(string fileName)
        {
            var toRet = QueryFactory
                    .Procedure<GetLegacyDocumentDataByFilenameProcedure>()
                    .WithParameters(fileName)
                    .Execute();

            if (!toRet.Any())
            {
                return null;
            }

            return toRet.GetByteArray(GetLegacyDocumentDataByFilenameProcedure.Columns.DocImage, null);
        }

        public byte[] GetDocumentImageData(long docId)
        {
            var toRet = QueryFactory
                .Procedure<GetLegacyDocumentDataByDocIdProcedure>()
                .WithParameters((int)docId)
                .Execute();

            if (!toRet.Any())
            {
                return null;
            }

            return toRet.GetByteArray(GetLegacyDocumentDataByFilenameProcedure.Columns.DocImage, null);
        }

        public bool DoesDocumentExist(string fileName) 
        {
            var toRet = QueryFactory
                    .Procedure<DoesLegacyDocumentExistProcedure>()
                    .WithParameters(fileName, false)
                    .ExecuteWithOutputValues<DoesLegacyDocumentExistProcedure.OutputValues>();

            return toRet.DoesExist;
        }

        public Document GetDocument(string fileName)
        {
            var mapper = new DocumentToRecordsetMapper();

            var toRet = QueryFactory
                    .Procedure<GetLegacyDocumentByFilenameProcedure>()
                    .WithParameters(fileName)
                    .ExecuteAndReturnFirst(mapper);
            return toRet;
        }

        public Document GetDocument(long documentId) // should really be a int because the column in the DB is an int
        {
            var mapper = new DocumentToRecordsetMapper();

            var toRet = QueryFactory
                    .Procedure<GetLegacyDocumentByDocIdProcedure>()
                    .WithParameters((int)documentId)
                    .ExecuteAndReturnFirst(mapper);

            return toRet;
        }        
    }
}
