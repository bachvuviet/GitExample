﻿using System.Reflection;
using System.Runtime.CompilerServices;
using Castle.MicroKernel.SubSystems.Configuration;
using Castle.Windsor;
using Fnz.Framework.Cca.Setup;
using Fnz.Framework.DocumentRepository.Api;
using Fnz.Framework.DocumentRepository.HcpDocumentRepository;
using Fnz.Framework.Integration.Hcp.Setup;
using Component = Castle.MicroKernel.Registration.Component;

namespace Fnz.Framework.DocumentRepository.Bootstrapping
{
    public class DocumentRepositoryInstaller : DefaultInstaller
    {
        private bool _registerHcp;

        public DocumentRepositoryInstaller()
            : base(Assembly.GetExecutingAssembly().FullName)
        {
        }

        public DocumentRepositoryInstaller WithHcp()
        {
            _registerHcp = true;
            return this;
        }

        public override void Install(IWindsorContainer container, IConfigurationStore store)
        {
            base.Install(container, store);

            if (_registerHcp)
            {
                InstallHcp(container, store);
            }
            else
            {
                container.Register(
                    Component.For<IDocumentRepository>().ImplementedBy<DocumentRepositoryHandler>().LifeStyle.Transient
                );
            }
        }

        // This method is split out purely so the DocumentRepositoryInstaller does not need a runtime dependency
        // on the Fnz.Framework.Integration.Hcp library for platforms that do not use HCP.
        [MethodImpl(MethodImplOptions.NoInlining)]
        internal static void InstallHcp(IWindsorContainer container, IConfigurationStore store)
        {
            container.Register(
                Component.For<IDocumentRepository>().ImplementedBy<HcpDocumentRepositoryHandler>().LifeStyle.Transient
            );

            container.Install(
                new HcpClientFrameworkInstaller()
            );
        }
    }
}