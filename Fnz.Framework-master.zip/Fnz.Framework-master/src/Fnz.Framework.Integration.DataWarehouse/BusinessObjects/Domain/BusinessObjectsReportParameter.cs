﻿namespace Fnz.Framework.Integration.DataWarehouse.BusinessObjects.Domain
{
    public struct BusinessObjectsReportParameter
    {
        public string ParameterName { get; set; }

        public string ParameterType { get; set; }

        public int ParameterId { get; set; }

        public string ParameterCode { get; set; }

        public string LastRunValue { get; set; }

        public bool Mandatory { get; set; }
    }
}
