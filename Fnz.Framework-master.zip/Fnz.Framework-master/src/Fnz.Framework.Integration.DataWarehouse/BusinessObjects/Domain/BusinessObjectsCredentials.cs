﻿namespace Fnz.Framework.Integration.DataWarehouse.BusinessObjects.Domain
{
    public class BusinessObjectsCredentials
    {
        public string UserName { get; set; }

        public string Password { get; set; }

        public string BaseURL { get; set; }

        public int TimeoutMS { get; set; }
    }
}