﻿using System;
using System.Collections.Generic;

namespace Fnz.Framework.Integration.DataWarehouse.BusinessObjects.Domain
{
    public class BusinessObjectsReportParameterInfo : List<BusinessObjectsReportParameter>
    {
        public DateTime ReportLastRun { get; set; }
    }
}