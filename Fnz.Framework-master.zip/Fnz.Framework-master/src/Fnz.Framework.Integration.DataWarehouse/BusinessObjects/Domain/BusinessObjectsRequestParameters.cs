﻿using System.Collections.Generic;

namespace Fnz.Framework.Integration.DataWarehouse.BusinessObjects.Domain
{
    public class BusinessObjectsRequestParameters : Dictionary<BusinessObjectsReportParameter, string>
    {
    }
}
