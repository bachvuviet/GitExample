﻿namespace Fnz.Framework.Integration.DataWarehouse.BusinessObjects.Domain
{
    public class BusinessObjectsToken
    {
        public string Token { get; set; }

        public string BaseURL { get; set; }

        public int TimeoutMS { get; set; }
    }
}