﻿using Fnz.Framework.Integration.DataWarehouse.BusinessObjects.Domain;

namespace Fnz.Framework.Integration.DataWarehouse.BusinessObjects.Commands
{
    public interface IBusinessObjectsCredentialsProvider
    {
        BusinessObjectsCredentials GetBusinessObjectsCredentials();
    }
}