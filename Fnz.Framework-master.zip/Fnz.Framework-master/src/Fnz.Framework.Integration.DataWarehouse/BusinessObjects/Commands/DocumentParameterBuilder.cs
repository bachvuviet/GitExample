﻿using System;
using System.Collections.Generic;
using Fnz.Framework.Integration.DataWarehouse.BusinessObjects.Domain;

namespace Fnz.Framework.Integration.DataWarehouse.BusinessObjects.Commands
{
    public static class DocumentParameterBuilder
    {
        public static BusinessObjectsRequestParameters GetParameters(BusinessObjectsReportParameterInfo availableParameterInfo, Dictionary<string, object> suppliedParameters)
        {
            var returnParameters = new BusinessObjectsRequestParameters();

            foreach (var ap in availableParameterInfo)
            {
                if (suppliedParameters.ContainsKey(ap.ParameterName))
                {
                    if (ap.ParameterType == "DateTime")
                    {
                        DateTime paramAsDate;

                        if (DateTime.TryParse(suppliedParameters[ap.ParameterName].ToString(), out paramAsDate))
                        {
                            returnParameters.Add(ap, paramAsDate.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss'.'fff'Z'"));
                        }
                        else
                        {
                            throw new ArgumentException("Parameter {0} contains value {1} which is not a recognised date".FormatWith(ap.ParameterName, suppliedParameters[ap.ParameterName].ToString()));
                        }
                    }
                    else
                    {
                        returnParameters.Add(ap, suppliedParameters[ap.ParameterName].ToString());
                    }
                }
                else if (ap.Mandatory)
                {
                    throw new ArgumentException("Parameter {0} is mandatory".FormatWith(ap.ParameterName));
                }
                else
                {
                    //It's optional and not supplied - need to overwrite existing value with nothing
                    returnParameters.Add(ap, string.Empty);
                }
            }

            return returnParameters;
        }
    }
}
