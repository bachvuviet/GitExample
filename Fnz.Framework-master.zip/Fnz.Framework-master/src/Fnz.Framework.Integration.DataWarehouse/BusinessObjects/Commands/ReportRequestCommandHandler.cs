﻿using System;
using Fnz.Framework.Integration.DataWarehouse.Api.BusinessObjects.Commands;
using Fnz.Framework.Integration.DataWarehouse.BusinessObjects.Domain;
using Fnz.Framework.Integration.DataWarehouse.BusinessObjects.Services;
using Fnz.Framework.Integration.DataWarehouse.BusinessObjects.Services.Contracts;

namespace Fnz.Framework.Integration.DataWarehouse.BusinessObjects.Commands
{
    public class ReportRequestCommandHandler : IReportRequestCommandHandler
    {
        private readonly IBusinessObjectsLoginService _loginService;
        private readonly IRefreshBusinessObjectsReportsService _refreshService;
        private readonly IGetBusinessObjectsDocumentService _getDocumentService;
        private readonly IGetDocumentParameterInfo _parameterInfoService;
        private readonly IBusinessObjectsCredentialsProvider _credentialsProvider;
        private readonly IBusinessObjectsReportInfoService _documentInfoService;

        public ReportRequestCommandHandler(IBusinessObjectsLoginService loginService, IRefreshBusinessObjectsReportsService refreshService, IGetBusinessObjectsDocumentService getDocumentService, IGetDocumentParameterInfo parameterInfoService, IBusinessObjectsCredentialsProvider credentialsProvider, IBusinessObjectsReportInfoService documentInfoService)
        {
            _loginService = loginService;
            _credentialsProvider = credentialsProvider;
            _documentInfoService = documentInfoService;
            _parameterInfoService = parameterInfoService;
            _getDocumentService = getDocumentService;
            _refreshService = refreshService;
        }

        public void Execute(ReportRequestCommand command)
        {
            var token = GetLoginToken(command);

            if (command.ReportId == 0)
            {
                command.ReportId = GetReportId(command, token);
            }

            var reportParameters = GetReportParameters(command, token);

            RefreshReport(command, token, reportParameters);

            SaveReport(command, token);
        }

        private int GetReportId(ReportRequestCommand command, BusinessObjectsToken token)
        {
            var reportId = _documentInfoService.GetReportId(new ReportInfoRequest
                                                        {
                                                            CUID = command.ReportCUID,
                                                            UserId = command.UserId,
                                                            TaskRequestId = command.TaskRequestId,
                                                            Token = token
                                                        });

            if (reportId == 0)
            {
                throw new Exception("Could not find report with CUID {0}".FormatWith(command.ReportCUID));
            }

            return reportId;
        }

        private void SaveReport(ReportRequestCommand command, BusinessObjectsToken token)
        {
            var request = new DocumentRequest
                              {
                                  UserId = command.UserId,
                                  ReportId = command.ReportId,
                                  ReportFormat = command.ReportFormat,
                                  TaskRequestId = command.TaskRequestId,
                                  Token = token,
                                  Filename = command.FileName
                              };

            _getDocumentService.SaveReport(request);
        }

        private void RefreshReport(ReportRequestCommand command, BusinessObjectsToken token, BusinessObjectsRequestParameters reportParameters)
        {
            var refreshRequest = new DocumentRefreshRequest(reportParameters)
                                     {
                                         UserId = command.UserId,
                                         ReportId = command.ReportId,
                                         TaskRequestId = command.TaskRequestId,
                                         Token = token
                                     };

            _refreshService.RefreshReport(refreshRequest);
        }

        private BusinessObjectsRequestParameters GetReportParameters(ReportRequestCommand command, BusinessObjectsToken token)
        {
            var parameterInfoRequest = new ParameterInfoRequest
                                           {
                                               UserId = command.UserId,
                                               ReportId = command.ReportId,
                                               TaskRequestId = command.TaskRequestId,
                                               Token = token
                                           };

            var availableParameters = _parameterInfoService.GetReportParameters(parameterInfoRequest);

            return DocumentParameterBuilder.GetParameters(availableParameters, command.Parameters);
        }

        private BusinessObjectsToken GetLoginToken(ReportRequestCommand command)
        {
            var loginCredentials = _credentialsProvider.GetBusinessObjectsCredentials();

            var loginRequest = new BusinessObjectsLoginRequest(loginCredentials.UserName, loginCredentials.Password)
                                   {
                                       UserId = command.UserId,
                                       ReportId = command.ReportId,
                                       TaskRequestId = command.TaskRequestId,
                                       Token = new BusinessObjectsToken
                                                   {
                                                       Token = string.Empty,
                                                       BaseURL = loginCredentials.BaseURL,
                                                       TimeoutMS = loginCredentials.TimeoutMS
                                                   }
                                   };

            return _loginService.GetLoginToken(loginRequest);
        }
    }
}
