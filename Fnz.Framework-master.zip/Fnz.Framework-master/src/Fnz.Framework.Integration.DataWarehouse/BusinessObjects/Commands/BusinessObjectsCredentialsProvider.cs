using System.Collections.Generic;
using Fnz.Framework.Components.Config;
using Fnz.Framework.DataAccess;
using Fnz.Framework.Integration.DataWarehouse.BusinessObjects.Domain;

namespace Fnz.Framework.Integration.DataWarehouse.BusinessObjects.Commands
{
    public class BusinessObjectsCredentialsProvider : IBusinessObjectsCredentialsProvider
    {
        private readonly ISystemVariablesReader _systemVariablesReader;

        public BusinessObjectsCredentialsProvider(ISystemVariablesReader systemVariablesReader)
        {
            _systemVariablesReader = systemVariablesReader;
        }

        public BusinessObjectsCredentials GetBusinessObjectsCredentials()
        {
            var sysVariables = _systemVariablesReader.GetValues("SAPIntegration", new List<string> { "UserName", "Password", "BaseURL", "TimeoutMS" });

            var credentials = new BusinessObjectsCredentials { TimeoutMS = 300000 };

            foreach (IRecordsetRow r in sysVariables)
            {
                if (r.GetAsString("Variable") == "UserName")
                {
                    credentials.UserName = r.GetAsString("Value");
                }

                if (r.GetAsString("Variable") == "Password")
                {
                    credentials.Password = r.GetAsString("Value");
                }

                if (r.GetAsString("Variable") == "BaseURL")
                {
                    credentials.BaseURL = r.GetAsString("Value");
                }

                if (r.GetAsString("Variable") == "TimeoutMS")
                {
                    credentials.TimeoutMS = r.GetAsInteger("Value");
                }
            }

            return credentials;
        }
    }
}
