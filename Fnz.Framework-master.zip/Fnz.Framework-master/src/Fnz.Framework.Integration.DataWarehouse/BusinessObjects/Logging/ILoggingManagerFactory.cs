using Fnz.Framework.Legacy.Logging;

namespace Fnz.Framework.Integration.DataWarehouse.BusinessObjects.Logging
{
    public interface ILoggingManagerFactory
    {
        ILog4NetExtension CreateRequestReplyLogger();
    }
}