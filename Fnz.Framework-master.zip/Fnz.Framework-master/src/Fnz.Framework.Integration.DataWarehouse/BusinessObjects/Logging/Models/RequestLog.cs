using System;
using System.Net;

namespace Fnz.Framework.Integration.DataWarehouse.BusinessObjects.Logging.Models
{
    public class RequestLog
    {
        public Guid Id { get; set; }

        public DateTime LogTime { get; set; }

        public HttpWebRequest Request { get; set; }

        public string RequestContent { get; set; }

        public string ServiceName { get; set; }
    }
}
