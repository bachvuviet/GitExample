using System;
using System.Net;

namespace Fnz.Framework.Integration.DataWarehouse.BusinessObjects.Logging.Models
{
    public class ResponseLog
    {
        public Guid Id { get; set; }

        public DateTime LogTime { get; set; }

        public HttpWebResponse Response { get; set; }

        public string ResponseContent { get; set; }

        public long ResponseTimeInMs { get; set; }
    }
}
