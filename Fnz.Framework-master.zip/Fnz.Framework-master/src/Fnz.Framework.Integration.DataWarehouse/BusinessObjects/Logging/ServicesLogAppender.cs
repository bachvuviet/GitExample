using Fnz.Framework.Cca.Services.Logging.DataAccess.Writers;
using Fnz.Framework.Integration.DataWarehouse.BusinessObjects.Logging.Mapper;
using Fnz.Framework.Integration.DataWarehouse.BusinessObjects.Logging.Models;
using log4net.Appender;
using log4net.Core;

namespace Fnz.Framework.Integration.DataWarehouse.BusinessObjects.Logging
{
    public class ServicesLogAppender : AppenderSkeleton
    {
        private readonly IServicesLogWriter _logWriter;
        private readonly IServiceLogEntryMapper _entryMapper;

        public ServicesLogAppender() : this(new ServicesLogWriter(), new ServiceLogEntryMapper())
        {
        }

        public ServicesLogAppender(IServicesLogWriter logWriter, IServiceLogEntryMapper entryMapper)
        {
            this._logWriter = logWriter;
            this._entryMapper = entryMapper;
        }

        protected override void Append(LoggingEvent loggingEvent)
        {
            if (loggingEvent.MessageObject is RequestLog)
            {
                var requestLog = (RequestLog) loggingEvent.MessageObject;

                _logWriter.LogRequestReply(_entryMapper.MapFromRequestLog(requestLog));
            }
            else if (loggingEvent.MessageObject is ResponseLog)
            {
                var responseLog = (ResponseLog) loggingEvent.MessageObject;

                _logWriter.LogRequestReply(_entryMapper.MapFromHttpResponse(responseLog));
            }
        }
    }
}
