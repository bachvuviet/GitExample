using System.Net;
using Fnz.Framework.Cca.Services.Logging.DataAccess.Writers;
using Fnz.Framework.Integration.DataWarehouse.BusinessObjects.Logging.Models;

namespace Fnz.Framework.Integration.DataWarehouse.BusinessObjects.Logging.Mapper
{
    public class ServiceLogEntryMapper : IServiceLogEntryMapper
    {
        public ServicesLogEntry MapFromRequestLog(RequestLog request)
        {
            return new ServicesLogEntry
                             {
                                 LogGuid = request.Id.ToString(),
                                 Host = request.Request.Headers["Host"],
                                 Method = request.Request.Method,
                                 Request = request.RequestContent,
                                 Url = request.Request.RequestUri.PathAndQuery,
                                 ServiceName = request.ServiceName,
                                 LogTime = request.LogTime,
                                 UserId = 8245,
                                 SessionId = string.Empty
                             };
        }

        public ServicesLogEntry MapFromHttpResponse(ResponseLog response)
        {
            var result = new ServicesLogEntry
                             {
                                 LogGuid = response.Id.ToString(),
                                 LogTime = response.LogTime,
                                 ResponseTimeInMs = response.ResponseTimeInMs,
                                 StatusCode = (int) response.Response.StatusCode
                             };

            if (response.Response.StatusCode != HttpStatusCode.OK)
            {
                result.Response = response.Response.StatusDescription;
                result.ErrorMessage = response.ResponseContent;
            }
            else
            {
                result.Response = response.ResponseContent;                
            }

            return result;
        }
    }
}
