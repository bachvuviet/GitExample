using Fnz.Framework.Cca.Services.Logging.DataAccess.Writers;
using Fnz.Framework.Integration.DataWarehouse.BusinessObjects.Logging.Models;

namespace Fnz.Framework.Integration.DataWarehouse.BusinessObjects.Logging.Mapper
{
    public interface IServiceLogEntryMapper
    {
        ServicesLogEntry MapFromRequestLog(RequestLog request);

        ServicesLogEntry MapFromHttpResponse(ResponseLog response);
    }
}