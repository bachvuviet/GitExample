using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using Fnz.Framework.Integration.DataWarehouse.BusinessObjects.Logging;
using Fnz.Framework.Integration.DataWarehouse.BusinessObjects.Logging.Models;
using Fnz.Framework.Util;

namespace Fnz.Framework.Integration.DataWarehouse.BusinessObjects.Services
{
    public abstract class BusinessObjectsActionService<T> where T : BusinessObjectsActionServiceRequest
    {
        private readonly ILoggingManagerFactory _loggingManagerFactory;

        protected BusinessObjectsActionService(ILoggingManagerFactory loggingManagerFactory)
        {
            _loggingManagerFactory = loggingManagerFactory;
        }

        protected string ResponseXml { get; set; }

        protected abstract string GetServiceUri(T request);

        protected abstract HttpMethod GetHttpMethod();

        protected void CallService(T request)
        {
            HttpWebRequest webRequest = PrepareWebRequest(request);

            var logger = _loggingManagerFactory.CreateRequestReplyLogger();

            var id = Guid.NewGuid();
            logger.DebugLow(new RequestLog { Id = id, LogTime = DateTime.Now, Request = webRequest, RequestContent = request.GetPayload(), ServiceName = this.GetType().Name });

            HttpWebResponse webResponse;
            
            var timer = new Stopwatch();
            timer.Start();

            try
            {
                webResponse = (HttpWebResponse)webRequest.GetResponse();

                using (var responseStream = webResponse.GetResponseStream())
                {
                    ProcessResponseStream(responseStream, request);
                }

                logger.DebugLow(
                   new ResponseLog
                   {
                       Id = id,
                       LogTime = DateTime.Now,
                       Response = webResponse,
                       ResponseContent = ResponseXml,
                       ResponseTimeInMs = timer.ElapsedMilliseconds
                   });

                //_loggingManagerFactory.LogResponse(requestId, this.GetType().Name, webResponse.StatusCode, ResponseXml, (int) timer.ElapsedMilliseconds);
            }
            catch (WebException e)
            {
                if (e.Response != null)
                {
                    using (var responseStream = e.Response.GetResponseStream())
                    using (var sr = new StreamReader(responseStream))
                    {
                        var errResponseXml = sr.ReadToEnd();
                        logger.DebugLow(
                            new ResponseLog
                                {
                                    Id = id,
                                    LogTime = DateTime.Now,
                                    Response = (HttpWebResponse) e.Response,
                                    ResponseContent = errResponseXml,
                                    ResponseTimeInMs = timer.ElapsedMilliseconds
                                });
                    }
                }

                throw;
            }
        }

        protected virtual void ProcessResponseStream(Stream responseStream, T request)
        {
            using (var sr = new StreamReader(responseStream))
            {
                ResponseXml = sr.ReadToEnd();
            }
        }

        private HttpWebRequest PrepareWebRequest(T request)
        {
            var webRequest = (HttpWebRequest)WebRequest.Create(string.Format("{0}{1}", request.Token.BaseURL, GetServiceUri(request)));

            webRequest.Method = GetHttpMethod().ToString();
            if (!request.Token.Token.IsNullOrEmpty())
            {
                webRequest.Headers.Add("X-SAP-LogonToken", "\"" + request.Token.Token + "\"");
            }

            webRequest.Accept = GetHttpAccept(request);
            webRequest.ContentType = GetHttpContentType(request);
            webRequest.Timeout = request.Token.TimeoutMS;

            var payload = request.GetPayload();

            if (!payload.IsNullOrEmpty())
            {
                using (var s = webRequest.GetRequestStream())
                using (var sw = new StreamWriter(s))
                {
                    sw.Write(payload);
                }
            }

            return webRequest;
        }

        protected virtual string GetHttpAccept(T request)
        {
            return string.Empty;
        }

        protected virtual string GetHttpContentType(T request)
        {
            return string.Empty;
        }
    }
}