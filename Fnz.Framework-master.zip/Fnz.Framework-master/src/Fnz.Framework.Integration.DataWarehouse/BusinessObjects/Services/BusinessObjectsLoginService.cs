using System.Linq;
using System.Web;
using System.Xml;
using Fnz.Framework.Integration.DataWarehouse.BusinessObjects.Domain;
using Fnz.Framework.Integration.DataWarehouse.BusinessObjects.Logging;
using Fnz.Framework.Util;
using Fnz.Framework.Util.Serialization;

namespace Fnz.Framework.Integration.DataWarehouse.BusinessObjects.Services
{
    public class BusinessObjectsLoginService : BusinessObjectsActionService<BusinessObjectsLoginRequest>, IBusinessObjectsLoginService
    {
        public BusinessObjectsLoginService(ILoggingManagerFactory logger)
            : base(logger)
        {
        }

        public BusinessObjectsToken GetLoginToken(BusinessObjectsLoginRequest request)
        {
            this.CallService(request);

            var responseXmlDoc = new XmlDocument();
            responseXmlDoc.LoadXml(ResponseXml);
            
            var loginResponse = XmlStringDeserializer.XmlDeserializeFromString<attrs>(responseXmlDoc.ChildNodes[0].ChildNodes[4].InnerXml);
            string token = loginResponse.attr.ToList().Where(x => x.name == "logonToken").First().Value;

            return new BusinessObjectsToken
                       {
                           Token = HttpUtility.HtmlDecode(token),
                           BaseURL = request.Token.BaseURL,
                           TimeoutMS = request.Token.TimeoutMS
                       };
        }

        protected override string GetServiceUri(BusinessObjectsLoginRequest request)
        {
            return "/biprws/logon/long";
        }

        protected override HttpMethod GetHttpMethod()
        {
            return HttpMethod.Post;
        }

        protected override string GetHttpContentType(BusinessObjectsLoginRequest request)
        {
            return "application/xml";
        }
    }
}