using System.Linq;
using System.Xml;
using Fnz.Framework.Integration.DataWarehouse.BusinessObjects.Logging;
using Fnz.Framework.Util;
using Fnz.Framework.Util.Serialization;

namespace Fnz.Framework.Integration.DataWarehouse.BusinessObjects.Services
{
    public class BusinessObjectsReportInfoService : BusinessObjectsActionService<ReportInfoRequest>, IBusinessObjectsReportInfoService
    {
        public BusinessObjectsReportInfoService(ILoggingManagerFactory loggingManagerFactory) : base(loggingManagerFactory)
        {
        }

        public int GetReportId(ReportInfoRequest request)
        {
            this.CallService(request);

            var responseXmlDoc = new XmlDocument();
            responseXmlDoc.LoadXml(ResponseXml);

            var response = XmlStringDeserializer.XmlDeserializeFromString<attrs>(responseXmlDoc.ChildNodes[0].ChildNodes[6].InnerXml);

            //var response = XMLStringDeserializer.XmlDeserializeFromString<entry>(ResponseXml);

            //return 0;
            return int.Parse(response.attr.Where(a => a.name == "id").First().Value);
        }

        protected override string GetServiceUri(ReportInfoRequest request)
        {
            return string.Format("/biprws/infostore/cuid_{0}", request.CUID);
        }

        protected override HttpMethod GetHttpMethod()
        {
            return HttpMethod.Get;
        }
    }
}