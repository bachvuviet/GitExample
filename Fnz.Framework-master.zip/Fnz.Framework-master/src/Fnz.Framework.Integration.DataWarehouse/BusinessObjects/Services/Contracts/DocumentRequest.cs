﻿using Fnz.Framework.Integration.DataWarehouse.Api.BusinessObjects.Commands;

namespace Fnz.Framework.Integration.DataWarehouse.BusinessObjects
{
    public class DocumentRequest : BusinessObjectsActionServiceRequest
    {
        public string Filename { get; set; }

        public ReportFormat ReportFormat { get; set; }

        public override string GetPayload()
        {
            return string.Empty;
        }
    }
}