﻿using System;
using System.Linq;
using Fnz.Framework.Integration.DataWarehouse.BusinessObjects.Domain;
using Fnz.Framework.Util.Serialization;

namespace Fnz.Framework.Integration.DataWarehouse.BusinessObjects.Services.Contracts
{
    public class DocumentRefreshRequest : BusinessObjectsActionServiceRequest
    {
        private readonly parameters _parameters;

        public DocumentRefreshRequest(BusinessObjectsRequestParameters requestParameters)
        {
            _parameters = new parameters
                              {
                                  parameter = new parametersParameter[requestParameters.Keys.Count]
                              };

            foreach (var p in requestParameters.Keys)
            {
                var index = requestParameters.Keys.ToList().IndexOf(p);
                _parameters.parameter[index] = new parametersParameter
                                                   {
                                                       id = (sbyte) p.ParameterId,
                                                       dpId = p.ParameterCode,
                                                       answer = new parametersParameterAnswer()
                                                   };
            
                if (!requestParameters[p].IsNullOrEmpty())
                {
                    _parameters.parameter[index].answer.values = new parametersParameterAnswerValues
                                                                     {
                                                                         value = requestParameters[p]
                                                                     };
                }
            }
        }

        public override string GetPayload()
        {
            return XmlObjectSerializer.Serialize(_parameters);
        }
    }
}
