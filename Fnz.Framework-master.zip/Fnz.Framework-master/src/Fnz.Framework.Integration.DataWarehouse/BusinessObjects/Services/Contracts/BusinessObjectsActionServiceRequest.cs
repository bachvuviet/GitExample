﻿using Fnz.Framework.Integration.DataWarehouse.BusinessObjects.Domain;

namespace Fnz.Framework.Integration.DataWarehouse.BusinessObjects
{
    public abstract class BusinessObjectsActionServiceRequest
    {
        public int UserId { get; set; }

        public int ReportId { get; set; }

        public int TaskRequestId { get; set; }

        public BusinessObjectsToken Token { get; set; }

        public abstract string GetPayload();
    }
}