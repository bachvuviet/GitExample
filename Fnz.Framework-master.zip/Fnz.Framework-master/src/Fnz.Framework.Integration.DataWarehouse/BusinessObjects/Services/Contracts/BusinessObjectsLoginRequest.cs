﻿using Fnz.Framework.Util.Serialization;

namespace Fnz.Framework.Integration.DataWarehouse.BusinessObjects
{
    public class BusinessObjectsLoginRequest : BusinessObjectsActionServiceRequest
    {
        private const string AuthType = "secEnterprise";

        private readonly attrs _sapAttrs;

        public BusinessObjectsLoginRequest(string username, string password)
        {
            _sapAttrs = new attrs()
                            {
                                attr = new[]
                                           {
                                               new attrsAttr
                                                   {
                                                       name = "userName",
                                                       type = "string",
                                                       Value = username
                                                   },
                                               new attrsAttr
                                                   {
                                                       name = "password",
                                                       type = "string",
                                                       Value = password
                                                   },
                                               new attrsAttr
                                                   {
                                                       name = "auth",
                                                       type = "string",
                                                       Value = AuthType
                                                   }
                                           }
                            };
        }

        public override string GetPayload()
        {
            return XmlObjectSerializer.Serialize(_sapAttrs);
        }
    }
}