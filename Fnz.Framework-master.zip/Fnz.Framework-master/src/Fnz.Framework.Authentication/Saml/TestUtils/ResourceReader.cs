﻿using System.IO;
using System.Reflection;
using System.Xml;

namespace Fnz.Framework.Authentication.Saml.TestUtils
{
    public static class ResourceReader
    {
        public static byte[] GetResourceBytes(Assembly assembly, string filename)
        {
            using (Stream resFilestream = assembly.GetManifestResourceStream(filename))
            {
                if (resFilestream == null)
                {
                    return null;
                }

                byte[] ba = new byte[resFilestream.Length];
                resFilestream.Read(ba, 0, ba.Length);
                return ba;
            }
        }

        public static XmlElement GetResourceXml(Assembly assembly, string filename)
        {
            using (Stream resFilestream = assembly.GetManifestResourceStream(filename))
            {
                if (resFilestream == null)
                {
                    return null;
                }

                var xmlDoc = new XmlDocument();
                xmlDoc.Load(resFilestream);
                return xmlDoc.DocumentElement;
            }
        }
    }
}