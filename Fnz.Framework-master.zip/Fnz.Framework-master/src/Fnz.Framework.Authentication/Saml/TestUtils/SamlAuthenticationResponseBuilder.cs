﻿using System;
using System.Security.Cryptography.X509Certificates;
using System.Xml;
using ComponentSpace.SAML2.Assertions;
using ComponentSpace.SAML2.Protocols;
using Fnz.Framework.Util;

namespace Fnz.Framework.Authentication.Saml.TestUtils
{
    //public class SamlAuthenticationResponseBuilder
    //{
    //    private readonly SAMLResponse _response;
    //    private SAMLAssertion _assertion;
    //    private EncryptedAssertion _encryptedAssertion;

    //    public SamlAuthenticationResponseBuilder()
    //    {
    //        _response = new SAMLResponse();
    //        _response.ID = Guid.NewGuid().ToString();
    //        _assertion = new SAMLAssertion();
    //        _assertion.ID = Guid.NewGuid().ToString();
    //        SetConditions();
    //        _assertion.Subject = new Subject();
    //    }

    //    private void SetConditions()
    //    {
    //        _assertion.Conditions = new Conditions(Clock.UtcNow.AddMinutes(-1), Clock.UtcNow.AddMinutes(5));
    //    }

    //    public SamlAuthenticationResponseBuilder WithUserId(string id)
    //    {
    //        _assertion.Subject.NameID = new NameID(id);
    //        return this;
    //    }

    //    public SamlAuthenticationResponseBuilder WithDestination(string assertionConsumerServiceUrl)
    //    {
    //        _response.Destination = assertionConsumerServiceUrl;
    //        return this;
    //    }

    //    public SamlAuthenticationResponseBuilder SignAssertion(byte[] certificate, string password)
    //    {
    //        if (_assertion.Issuer == null)
    //        {
    //            _assertion.Issuer = new Issuer("issuer-name");
    //        }

    //        var cert = new X509Certificate2(certificate);
    //        var xml = _assertion.ToXml();
    //        SAMLAssertionSignature.Generate(xml, cert.PrivateKey);
    //        _assertion = new SAMLAssertion(xml);
    //        return this;
    //    }

    //    public SamlAuthenticationResponseBuilder EncryptAssertion(byte[] certificate, string password)
    //    {
    //        var cert = new X509Certificate2(certificate, password);
    //        _encryptedAssertion = new EncryptedAssertion(_assertion.ToXml(), cert);
    //        _assertion = null;

    //        return this;
    //    }

    //    public XmlElement Build()
    //    {
    //        if (_assertion != null)
    //        {
    //            _response.Assertions.Add(_assertion);
    //        }
    //        else if (_encryptedAssertion != null)
    //        {
    //            _response.Assertions.Add(_encryptedAssertion);
    //        }

    //        return _response.ToXml();
    //    }
    //}
}