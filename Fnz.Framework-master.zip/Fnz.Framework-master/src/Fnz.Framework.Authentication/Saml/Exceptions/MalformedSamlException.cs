﻿using Fnz.Framework.Authentication.Api.Errors;
using Fnz.Framework.Cca.ErrorHandling.Exceptions;

namespace Fnz.Framework.Authentication.Saml.Exceptions
{
    public class MalformedSamlException : InvalidInputsException
    {
        public MalformedSamlException()
            : base(ErrorCodes.InvalidSamlMessage, ErrorCodes.InvalidSamlMessage.Description)
        {
        }
    }
}