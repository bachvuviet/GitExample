﻿using Fnz.Framework.Authentication.Api.Errors;
using Fnz.Framework.Cca.ErrorHandling.Exceptions;

namespace Fnz.Framework.Authentication.Saml.Exceptions
{
    public class SamlDestinationNotValidException : InvalidInputsException
    {
        public SamlDestinationNotValidException()
            : base(ErrorCodes.SamlDestinationNotValid, ErrorCodes.SamlDestinationNotValid.Description)
        {
        }
    }
}