﻿using System;

namespace Fnz.Framework.Authentication.Saml.Exceptions
{
    public class InvalidApplicationNameException : Exception
    {
        public InvalidApplicationNameException()
            : base("Only numeric ApplicationNames are supported for single log out")
        {
        }
    }
}