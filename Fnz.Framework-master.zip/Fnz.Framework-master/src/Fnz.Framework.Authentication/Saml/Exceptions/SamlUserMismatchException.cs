using System;

namespace Fnz.Framework.Authentication.Saml.Exceptions
{
    public class SamlUserMismatchException : Exception
    {
    }
}