﻿using System;

namespace Fnz.Framework.Authentication.Saml.Exceptions
{
    public class InvalidSamlConfigurationException : Exception
    {
        public InvalidSamlConfigurationException(string message)
            : base(message)
        {
        }
    }
}