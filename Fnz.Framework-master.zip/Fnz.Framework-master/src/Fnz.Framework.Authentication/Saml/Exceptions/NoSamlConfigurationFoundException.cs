﻿using Fnz.Framework.Authentication.Api.Errors;
using Fnz.Framework.Cca.ErrorHandling.Exceptions;

namespace Fnz.Framework.Authentication.Saml.Exceptions
{
    public class NoSamlConfigurationFoundException : EntityNotFoundException
    {
        public NoSamlConfigurationFoundException()
            : base(ErrorCodes.SamlConfigurationNotFound, "Saml configuration not found")
        {
        }
    }
}