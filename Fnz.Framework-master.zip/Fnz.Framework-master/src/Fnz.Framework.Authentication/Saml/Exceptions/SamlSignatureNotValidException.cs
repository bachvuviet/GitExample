using Fnz.Framework.Authentication.Api.Errors;
using Fnz.Framework.Cca.ErrorHandling.Exceptions;

namespace Fnz.Framework.Authentication.Saml.Exceptions
{
    public class SamlSignatureNotValidException : InvalidInputsException
    {
        public SamlSignatureNotValidException()
            : base(ErrorCodes.SamlSignatureNotVerified, ErrorCodes.SamlSignatureNotVerified.Description)
        {
        }

        public SamlSignatureNotValidException(string message)
            : base(ErrorCodes.SamlSignatureNotVerified, message)
        {
        }
    }
}