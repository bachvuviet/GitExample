﻿using Castle.Core.Internal;
using FluentValidation;
using Fnz.Framework.Authentication.Api.Saml.Commands;
using Fnz.Framework.Cca.Validation.Fluent;

namespace Fnz.Framework.Authentication.Saml.Validators
{
    public class SamlLogoutRequestCommandValidator : FluentValidator<ProcessSamlLogoutRequestCommand>
    {
        public SamlLogoutRequestCommandValidator()
        {
            this.RuleFor(x => x.SamlConfigurationKey).Must(x => x.IsNullOrEmpty() == false).WithMessage("SAML configuration must be specified");
            this.RuleFor(x => x.Request).Must(x => x.IsNullOrEmpty() == false).WithMessage("SAML request must be included");
        }
    }
}