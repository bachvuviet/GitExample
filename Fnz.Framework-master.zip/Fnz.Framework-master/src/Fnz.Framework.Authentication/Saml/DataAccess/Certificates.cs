using System.Security.Cryptography.X509Certificates;
using Castle.Core.Internal;

namespace Fnz.Framework.Authentication.Saml.DataAccess
{
    public class Certificates
    {
        public byte[] SigningCertificate { get; set; }

        public string SigningCertificatePassword { get; set; }

        public byte[] EncryptionCertificate { get; set; }

        public string EncryptionCertificatePassword { get; set; }

        public byte[] DecryptionCertificate { get; set; }

        public string DecryptionCertificatePassword { get; set; }

        public X509Certificate2 GetSigningCertificate()
        {
            if (this.SigningCertificate.IsNullOrEmpty())
            {
                return null;
            }

            return this.SigningCertificatePassword.IsNullOrEmpty()
                       ? new X509Certificate2(this.SigningCertificate)
                       : new X509Certificate2(this.SigningCertificate, this.SigningCertificatePassword);
        }

        public X509Certificate2 GetDecryptionCertificate()
        {
            if (this.DecryptionCertificate.IsNullOrEmpty())
            {
                return null;
            }

            return this.DecryptionCertificatePassword.IsNullOrEmpty()
                       ? new X509Certificate2(this.DecryptionCertificate)
                       : new X509Certificate2(this.DecryptionCertificate, this.DecryptionCertificatePassword);
        }
    }
}