﻿namespace Fnz.Framework.Authentication.Saml.DataAccess
{
    public enum SamlRoleType
    {
        ServiceProvider,
        IdentityProvider
    }
}