﻿using Fnz.Framework.Authentication.Api.Sessions;

namespace Fnz.Framework.Authentication.Saml.DataAccess
{
    public interface IWebFormsSessionWriter
    {
        SingleSignOnSession Login(int userId); 
    }
}