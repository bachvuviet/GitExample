﻿using Fnz.Framework.Authentication.Api.Sessions;

namespace Fnz.Framework.Authentication.Saml.DataAccess
{
    public interface ISamlUserIdentiferQueryHandler
    {
        string GetSharedIdentifier(UserIdentifierType userIdentifierType, int userId);

        int GetFnzUserId(string userIdentifier, UserIdentifierType userIdentifierType);
    }
}