﻿namespace Fnz.Framework.Authentication.Saml.DataAccess
{
    public enum SamlUserIdentifierType
    {
        FnzUserId,
        ExternalUserId,
        ExternalCustomerId
    }
}