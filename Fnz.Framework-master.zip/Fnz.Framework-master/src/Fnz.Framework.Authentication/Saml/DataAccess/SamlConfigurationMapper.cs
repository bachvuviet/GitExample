﻿using Fnz.Framework.Authentication.Api.Sessions;
using Fnz.Framework.DataAccess.RecordsetMapping;
using Fnz.Framework.DataAccess.RecordsetMapping.Data.ChangeTracking;
using Fnz.Framework.DataAccess.RecordsetMapping.Data.Mapping.Converters;
using Columns = Fnz.Framework.MetaData.Saml.Saml.SamlConfigurationsView.Columns;

namespace Fnz.Framework.Authentication.Saml.DataAccess
{
    public class SamlConfigurationMapper : RecordsetMapper<SamlConfiguration>
    {
        public SamlConfigurationMapper()
            : base(new ActivatorFactory())
        {
            this.Maps(x => x.Id).To(Columns.ConfigurationId);
            this.Maps(x => x.IdentityProvider.Logout.LogoutRequestUrl).To(Columns.IdPSingleLogoutServiceUrl);
            this.Maps(x => x.IdentityProvider.Logout.LogoutResponseUrl).To(Columns.IdPSingleLogoutServiceResponseUrl);
            this.Maps(x => x.ServiceProvider.Logout.LogoutRequestUrl).To(Columns.SPSingleLogoutServiceUrl);
            this.Maps(x => x.ServiceProvider.Logout.LogoutResponseUrl).To(Columns.SPSingleLogoutServiceResponseUrl);
            this.Maps(x => x.UserIdentifierType).To(Columns.UserIdentifierTypeId).WithConverter(new IntToEnumConverter<UserIdentifierType>());
            this.Maps(x => x.LocalPlatformRole).To(Columns.LocalRoleTypeId).WithConverter(new IntToEnumConverter<SamlRoleType>());
            this.Maps(x => x.ServiceProvider.Certificates.SigningCertificate).To(Columns.SPSigningCertificate);
            this.Maps(x => x.ServiceProvider.Certificates.SigningCertificatePassword).To(Columns.SPSigningCertificatePassword);
            this.Maps(x => x.ServiceProvider.Certificates.DecryptionCertificate).To(Columns.SPDecryptionCertificate);
            this.Maps(x => x.ServiceProvider.Certificates.DecryptionCertificatePassword).To(Columns.SPDecryptionCertificatePassword);
            this.Maps(x => x.ServiceProvider.Certificates.EncryptionCertificate).To(Columns.SPEncryptionCertificate);
            this.Maps(x => x.ServiceProvider.Certificates.EncryptionCertificatePassword).To(Columns.SPEncryptionCertificatePassword);
            this.Maps(x => x.IdentityProvider.Certificates.SigningCertificate).To(Columns.IdPSigningCertificate);
            this.Maps(x => x.IdentityProvider.Certificates.SigningCertificatePassword).To(Columns.IdPSigningCertificatePassword);
            this.Maps(x => x.IdentityProvider.MetadataUrl).To(Columns.IdPMetadataUrl);
            this.Maps(x => x.ServiceProvider.MetadataUrl).To(Columns.SPMetadataUrl);
            this.Maps(x => x.ServiceProvider.AssertionConsumerServiceUrl).To(Columns.SPAssertionConsumerServiceUrl);
        }
    }
}
