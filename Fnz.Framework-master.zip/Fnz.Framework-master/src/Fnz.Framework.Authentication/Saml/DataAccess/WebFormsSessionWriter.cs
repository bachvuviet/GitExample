﻿using System;
using Fnz.Framework.Authentication.Api.Sessions;
using Fnz.Framework.DataAccess;
using Fnz.Framework.MetaData.Saml.Saml;
using Fnz.Framework.ReadersWriters;

namespace Fnz.Framework.Authentication.Saml.DataAccess
{
    public class WebFormsSessionWriter : DataAccessBase, IWebFormsSessionWriter
    {
        public WebFormsSessionWriter(IDataAccess dal)
            : base(dal)
        {
        }

        public SingleSignOnSession Login(int userId)
        {
            var sessionToken = Guid.NewGuid();

            QueryFactory
                   .Procedure<LoginUserProcedure>()
                   .WithParameters(userId, sessionToken)
                   .Execute();

            return new SingleSignOnSession
                       {
                           DefaultTimeout = 0,
                           FirstTimeLogin = false,
                           Token = sessionToken,
                           UserId = userId
                       };
        }
    }
}