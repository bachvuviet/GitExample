using System.Xml;

namespace Fnz.Framework.Authentication.Saml.DataAccess
{
    public interface ISamlMessageLogWriter
    {
        void LogSuccess(SamlActionType action, string externalUserIdentifier, int fnzUserIdentifier, string messageId, XmlElement message);

        void LogFailure(SamlActionType action, string externalUserIdentifier, int? fnzUserIdentifier, string messageId, XmlElement message, string exception);
    }
}