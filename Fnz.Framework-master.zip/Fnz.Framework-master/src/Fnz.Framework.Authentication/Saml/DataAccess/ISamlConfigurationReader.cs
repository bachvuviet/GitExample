﻿namespace Fnz.Framework.Authentication.Saml.DataAccess
{
    public interface ISamlConfigurationReader
    {
        SamlConfiguration GetByKey(string samlConfigurationKey);
    }
}