﻿using Fnz.Framework.Authentication.Saml.Exceptions;
using Fnz.Framework.DataAccess;
using Fnz.Framework.MetaData.Saml.Saml;
using Fnz.Framework.ReadersWriters;

namespace Fnz.Framework.Authentication.Saml.DataAccess
{
    public class SamlConfigurationReader : DataAccessBase, ISamlConfigurationReader
    {
        public SamlConfigurationReader(IDataAccess dal)
            : base(dal)
        {
        }

        public SamlConfiguration GetByKey(string samlConfigurationKey)
        {
            var samlConfig = this.QueryFactory.Select()
                            .From<SamlConfigurationsView>()
                            .Where(SamlConfigurationsView.Columns.ConfigurationKey, "=", samlConfigurationKey)
                            .ExecuteAndReturnFirst(new SamlConfigurationMapper());

            if (samlConfig == null)
            {
                throw new NoSamlConfigurationFoundException();
            }

            return samlConfig;
        }
    }
}