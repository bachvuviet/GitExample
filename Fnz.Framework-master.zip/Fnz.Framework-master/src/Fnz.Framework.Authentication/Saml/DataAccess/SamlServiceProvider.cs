﻿namespace Fnz.Framework.Authentication.Saml.DataAccess
{
    public class SamlServiceProvider
    {
        public SamlServiceProvider()
        {
            this.Logout = new SamlLogoutConfiguration();
            this.Certificates = new Certificates();
        }

        public SamlLogoutConfiguration Logout { get; set; }

        public Certificates Certificates { get; set; }

        public string MetadataUrl { get; set; }

        public string AssertionConsumerServiceUrl { get; set; }
    }
}