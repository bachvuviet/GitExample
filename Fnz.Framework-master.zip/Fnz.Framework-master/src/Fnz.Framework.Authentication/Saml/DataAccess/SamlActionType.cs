﻿namespace Fnz.Framework.Authentication.Saml.DataAccess
{
    public enum SamlActionType
    {
        AuthnResponseReceived,
        LogoutRequestSent,
        LogoutRequestReceived,
        LogoutResponseSent
    }
}