﻿namespace Fnz.Framework.Authentication.Saml.DataAccess
{
    public class SamlIdentityProvider
    {
        public SamlIdentityProvider()
        {
            this.Logout = new SamlLogoutConfiguration();
            this.Certificates = new Certificates();
        }

        public SamlLogoutConfiguration Logout { get; set; }

        public Certificates Certificates { get; set; }

        public string MetadataUrl { get; set; }
    }
}