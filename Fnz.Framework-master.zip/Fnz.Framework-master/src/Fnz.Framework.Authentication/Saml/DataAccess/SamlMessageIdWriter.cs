﻿using System;

using Fnz.Framework.DataAccess;
using Fnz.Framework.MetaData.Saml.Saml;
using Fnz.Framework.ReadersWriters;

namespace Fnz.Framework.Authentication.Saml.DataAccess
{
    public class SamlMessageIdWriter : DataAccessBase, ISamlMessageIdWriter
    {
        public SamlMessageIdWriter(IDataAccess dal)
            : base(dal)
        {
        }

        public bool SaveMessageId(int configurationId, string messageId, DateTime expiresAt)
        {
            var successRs =
                QueryFactory.Procedure<VerifySamlMessageIdProcedure>()
                    .WithParameters(configurationId, messageId, expiresAt.ToLocalTime())
                    .Execute();

            return successRs.GetAsString("Success") == "1";
        }
    }
}