﻿using System.Xml;
using Fnz.Framework.DataAccess;
using Fnz.Framework.MetaData.Saml.Saml;
using Fnz.Framework.ReadersWriters;
using Fnz.Framework.Util;
using Fnz.Framework.Util.CodeQuality;

namespace Fnz.Framework.Authentication.Saml.DataAccess
{
    public class SamlMessageLogWriter : DataAccessBase, ISamlMessageLogWriter
    {
        public SamlMessageLogWriter(IDataAccess dal)
            : base(dal)
        {
        }

        [IgnoreNumberOfParameters]
        private void Log(SamlActionType action, string externalUserIdentifier, int? fnzUserId, string messageId, XmlElement message, bool success, string exception)
        {
            var stringMessage = message.OuterXml;

            var logRs = new Recordset();
            logRs.AddNew();
            logRs.RowStatus = Recordset.RecordStatus.Added;
            logRs[MessageLogTable.Columns.LogDateTime] = Clock.Now();
            logRs[MessageLogTable.Columns.ExternalUserId] = externalUserIdentifier;
            logRs[MessageLogTable.Columns.UserId] = fnzUserId;
            logRs[MessageLogTable.Columns.SamlMessageId] = messageId;
            logRs[MessageLogTable.Columns.ActionType] = (int)action;
            logRs[MessageLogTable.Columns.Message] = stringMessage;
            logRs[MessageLogTable.Columns.Success] = success;
            logRs[MessageLogTable.Columns.Exception] = exception;

            this.DataAccess.SaveRecordset<MessageLogTable>(logRs, false);
        }

        public void LogSuccess(SamlActionType action, string externalUserIdentifier, int fnzUserIdentifier, string messageId, XmlElement message)
        {
            this.Log(action, externalUserIdentifier, fnzUserIdentifier, messageId, message, true, null);
        }

        public void LogFailure(SamlActionType action, string externalUserIdentifier, int? fnzUserIdentifier, string messageId, XmlElement message, string exception)
        {
            this.Log(action, externalUserIdentifier, fnzUserIdentifier, messageId, message, false, exception);
        }
    }
}