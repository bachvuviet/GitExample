﻿using System;

namespace Fnz.Framework.Authentication.Saml.DataAccess
{
    public interface ISamlMessageIdWriter
    {
        bool SaveMessageId(int configurationId, string messageId, DateTime expiresAt);
    }
}