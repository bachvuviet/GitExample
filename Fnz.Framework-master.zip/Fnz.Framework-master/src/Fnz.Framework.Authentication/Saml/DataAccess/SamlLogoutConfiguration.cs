﻿namespace Fnz.Framework.Authentication.Saml.DataAccess
{
    public class SamlLogoutConfiguration
    {
        private string _logoutResponseUrl;

        public string LogoutRequestUrl { get; set; }

        public string LogoutResponseUrl
        {
            get
            {
                return this._logoutResponseUrl ?? this.LogoutRequestUrl;
            }

            set
            {
                this._logoutResponseUrl = value;
            }
        }
    }
}