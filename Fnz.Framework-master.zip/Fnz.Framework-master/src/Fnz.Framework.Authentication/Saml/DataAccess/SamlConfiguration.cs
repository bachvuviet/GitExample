﻿using Fnz.Framework.Authentication.Api.Sessions;

namespace Fnz.Framework.Authentication.Saml.DataAccess
{
    public class SamlConfiguration
    {
        public SamlConfiguration()
        {
            this.ServiceProvider = new SamlServiceProvider();
            this.IdentityProvider = new SamlIdentityProvider();
        }

        public int Id { get; set; }

        public SamlServiceProvider ServiceProvider { get; set; }

        public SamlIdentityProvider IdentityProvider { get; set; }

        public UserIdentifierType UserIdentifierType { get; set; }

        public SamlRoleType LocalPlatformRole { get; set; }
    }
}