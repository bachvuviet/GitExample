﻿using System.Reflection;
using Castle.MicroKernel.Registration;
using Castle.MicroKernel.SubSystems.Configuration;
using Castle.Windsor;
using Fnz.Framework.Authentication.Saml.Commands;
using Fnz.Framework.Authentication.Saml.Queries;
using Fnz.Framework.Cca.Setup;

namespace Fnz.Framework.Authentication.Saml
{
    public class SamlInstaller : DefaultInstaller
    {
        public SamlInstaller()
            : base(Assembly.GetExecutingAssembly().FullName)
        {
        }

        public override void Install(IWindsorContainer container, IConfigurationStore store)
        {
            base.Install(container, store);

            container.Register(Component
                        .For(typeof(ISamlUserFactory))
                        .ImplementedBy(typeof(SamlUserFactory))
                        .LifestyleTransient());
        }
    }
}