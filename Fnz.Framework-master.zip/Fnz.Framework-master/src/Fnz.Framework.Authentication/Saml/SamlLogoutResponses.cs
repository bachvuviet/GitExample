﻿using ComponentSpace.SAML2;
using ComponentSpace.SAML2.Assertions;
using ComponentSpace.SAML2.Protocols;
using Fnz.Framework.Authentication.Api.Saml.Commands;
using Fnz.Framework.Authentication.Saml.DataAccess;
using Fnz.Framework.Util;

namespace Fnz.Framework.Authentication.Saml
{
    public static class SamlLogoutResponses
    {
        public static SamlLogoutResponse IdentityProviderInitiatedSuccess(SamlConfiguration samlConfig, LogoutRequest logoutRequest)
        {
            var logoutResponse = GetBasicResponse(samlConfig, logoutRequest);
            logoutResponse.Status = new Status(SAMLIdentifiers.PrimaryStatusCodes.Success, null);
            return new SamlLogoutResponse(logoutResponse.ToXml());
        }

        public static SamlLogoutResponse IdentityProviderInitiatedInvalidSaml(SamlConfiguration samlConfig)
        {
            var logoutResponse = new LogoutResponse();
            logoutResponse.Status = new Status(SAMLIdentifiers.PrimaryStatusCodes.Requester, "The request message could not be read");
            logoutResponse.Destination = samlConfig.IdentityProvider.Logout.LogoutResponseUrl;
            logoutResponse.IssueInstant = Clock.Now();

            return new SamlLogoutResponse(logoutResponse.ToXml());
        }

        public static SamlLogoutResponse UserNotFound(SamlConfiguration samlConfig, LogoutRequest logoutRequest)
        {
            var logoutResponse = GetBasicResponse(samlConfig, logoutRequest);
            logoutResponse.Status = new Status(SAMLIdentifiers.PrimaryStatusCodes.Responder, SAMLIdentifiers.SecondaryStatusCodes.AuthnFailed, "User not found");
            return new SamlLogoutResponse(logoutResponse.ToXml());
        }

        private static LogoutResponse GetBasicResponse(SamlConfiguration samlConfig, LogoutRequest logoutRequest)
        {
            var logoutResponse = new LogoutResponse();
            logoutResponse.Issuer = new Issuer(samlConfig.ServiceProvider.Logout.LogoutRequestUrl);
            logoutResponse.InResponseTo = logoutRequest.ID;
            logoutResponse.Destination = samlConfig.IdentityProvider.Logout.LogoutResponseUrl;
            logoutResponse.IssueInstant = Clock.Now();
            return logoutResponse;
        }
    }
}