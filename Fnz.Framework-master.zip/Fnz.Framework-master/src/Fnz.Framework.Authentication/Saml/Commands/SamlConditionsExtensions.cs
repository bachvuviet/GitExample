﻿using System;

using ComponentSpace.SAML2.Assertions;

using Fnz.Framework.Util;

namespace Fnz.Framework.Authentication.Saml.Commands
{
    public static class SamlConditionsExtensions
    {
        public static bool CheckTimePeriod(this Conditions conditions)
        {
            var utcNow = Clock.UtcNow;
            if (utcNow < conditions.NotBefore)
            {
                return false;
            }

            if (utcNow >= conditions.NotOnOrAfter)
            {
                return false;
            }

            return true;
        }        
    }
}