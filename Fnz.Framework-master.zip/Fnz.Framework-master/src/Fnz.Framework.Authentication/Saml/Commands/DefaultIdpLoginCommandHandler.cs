﻿using Fnz.Framework.Authentication.Api.Saml.Commands;
using Fnz.Framework.Authentication.Api.Saml.Queries;
using Fnz.Framework.Authentication.Api.Sessions;
using Fnz.Framework.Authentication.Saml.DataAccess;

namespace Fnz.Framework.Authentication.Saml.Commands
{
    public class DefaultIdpLoginCommandHandler : IIdpLoginCommandHandler
    {
        private readonly IWebFormsSessionWriter _webFormsSessionWriter;

        private readonly ISamlFnzUserIdQueryHandler _getFnzUserId;

        public DefaultIdpLoginCommandHandler(IWebFormsSessionWriter webFormsSessionWriter, ISamlFnzUserIdQueryHandler getFnzUserId)
        {
            _webFormsSessionWriter = webFormsSessionWriter;
            _getFnzUserId = getFnzUserId;
        }

        public SamlAuthenticationResponse Execute(IdpLoginCommand command)
        {
            return AdminSiteLogin(command);
        }

        private SamlAuthenticationResponse AdminSiteLogin(IdpLoginCommand command)
        {
            int userId = _getFnzUserId.Execute(new SamlFnzUserIdQuery { ExternalIdentifier = command.NameId, UserIdentifierType = command.UserIdentifierType });
            var session = _webFormsSessionWriter.Login(userId);

            return new SamlAuthenticationResponse
                       {
                           CustomAttributes = command.Attributes,
                           Token =
                               new AuthenticationToken
                                   {
                                       DefaultTimeout =
                                           session.DefaultTimeout,
                                       FirstTimeLogin = false,
                                       FullAuthenticationRequired = false,
                                       MemorableWordUpdateRequired = false,
                                       PasswordUpdateRequired = false,
                                       Token = session.Token,
                                       UserId = session.UserId
                                   }
                       };
        }
    }
}