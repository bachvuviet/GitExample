﻿using System;
using System.Security.Cryptography.X509Certificates;
using Castle.Core.Internal;
using ComponentSpace.SAML2.Protocols;
using Fnz.Framework.Authentication.Api.Saml.Commands;
using Fnz.Framework.Authentication.Api.Saml.Queries;
using Fnz.Framework.Authentication.Saml.DataAccess;

namespace Fnz.Framework.Authentication.Saml.Commands
{
    public class GenerateSamlLogoutRequestCommandHandler : IGenerateSamlLogoutRequestCommandHandler
    {
        private readonly ISamlConfigurationReader _configurationReader;

        private readonly ISamlSharedIdentifierQueryHandler _getSharedIdentifier;

        public GenerateSamlLogoutRequestCommandHandler(
            ISamlConfigurationReader configurationReader,
            ISamlSharedIdentifierQueryHandler getSharedIdentifier)
        {
            this._configurationReader = configurationReader;
            _getSharedIdentifier = getSharedIdentifier;
        }

        public SamlLogoutRequest Execute(SamlGenerateLogoutRequestCommand command)
        {
            var samlConfig = this._configurationReader.GetByKey(command.SamlConfigurationKey);

            if (samlConfig.LocalPlatformRole == SamlRoleType.ServiceProvider)
            {
                return this.GenerateLogoutRequestForServiceProvider(command, samlConfig);
            }

            throw new NotImplementedException("Logout requests are not supported where the local platform is the Identity Provider. Check the SAML configuration if the platform is a Service Provider");
        }

        private SamlLogoutRequest GenerateLogoutRequestForServiceProvider(SamlGenerateLogoutRequestCommand command, SamlConfiguration samlConfig)
        {
            var userIdentifier = _getSharedIdentifier.Execute(new SamlSharedIdentifierQuery { UserId = command.UserId, UserIdentifierType = samlConfig.UserIdentifierType });
            var request = SamlLogoutMessages.ServiceProviderInitiatedRequest(samlConfig, userIdentifier);

            if (samlConfig.ServiceProvider.Certificates.SigningCertificate.IsNullOrEmpty() == false)
            {
                var certificate = new X509Certificate2(samlConfig.ServiceProvider.Certificates.SigningCertificate,
                                                        samlConfig.ServiceProvider.Certificates.SigningCertificatePassword);
                SAMLMessageSignature.Generate(request.Xml, certificate.PrivateKey, certificate);
            }

            return request;
        }
    }
}
