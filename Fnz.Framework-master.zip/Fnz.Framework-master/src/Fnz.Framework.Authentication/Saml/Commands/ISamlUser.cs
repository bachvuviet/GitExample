using Fnz.Framework.Authentication.Saml.DataAccess;

namespace Fnz.Framework.Authentication.Saml.Commands
{
    public interface ISamlUser
    {
        void Logout(string userIdentifier, SamlUserIdentifierType userIdentifierType, string applicationName);
    }
}