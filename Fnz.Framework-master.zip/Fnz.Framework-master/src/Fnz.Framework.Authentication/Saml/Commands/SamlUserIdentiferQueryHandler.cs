﻿using System;
using Fnz.Framework.Authentication.Api.Customers;
using Fnz.Framework.Authentication.Api.Sessions;
using Fnz.Framework.Authentication.Api.Users;
using Fnz.Framework.Authentication.Saml.DataAccess;
using Fnz.Framework.Authentication.Saml.Exceptions;
using Fnz.Framework.Authentication.Users;
using Fnz.Framework.Cca.ErrorHandling.Contracts;

namespace Fnz.Framework.Authentication.Saml.Commands
{
    public class SamlUserIdentiferQueryHandler : ISamlUserIdentiferQueryHandler
    {
        private readonly IUserQueryHandler _getUsers;

        private readonly ICustomerIdentifierByUserIdQueryHandler _getUserCustomerIdentifier;

        private readonly IGetCustomerUserIdQueryHandler _getCustomerUser;

        public SamlUserIdentiferQueryHandler(IUserQueryHandler getUsers, ICustomerIdentifierByUserIdQueryHandler getUserCustomerIdentifier, IGetCustomerUserIdQueryHandler getCustomerUser)
        {
            _getUsers = getUsers;
            _getUserCustomerIdentifier = getUserCustomerIdentifier;
            _getCustomerUser = getCustomerUser;
        }

        public string GetSharedIdentifier(UserIdentifierType userIdentifierType, int userId)
        {
            var identifier = this.GetIdentifier(userIdentifierType, userId);

            if (identifier.IsNullOrEmpty())
            {
                throw new NoSamlIdentifierException();
            }

            return identifier;
        }

        private string GetIdentifier(UserIdentifierType userIdentifierType, int userId)
        {
            switch (userIdentifierType)
            {
                case UserIdentifierType.UserId:
                    return userId.ToString();

                case UserIdentifierType.ExternalUserId:
                    var user = _getUsers.Execute(new UserQuery { RequestedUserId = userId });
                    return user.ExternalUserId;

                case UserIdentifierType.ExternalCustomerId:
                    var customer = _getUserCustomerIdentifier.Execute(new CustomerIdentifierByUserQuery { UserId = userId });
                    return customer.ExternalCustomerId;

                default:
                    throw new NotImplementedException();
            }
        }

        public int GetFnzUserId(string userIdentifier, UserIdentifierType userIdentifierType)
        {
            switch (userIdentifierType)
            {
                case UserIdentifierType.ExternalUserId:
                    var user = _getUsers.Execute(new UserQuery { ExternalUserId = userIdentifier });
                    return user.Id;

                case UserIdentifierType.UserId:
                    return int.Parse(userIdentifier);

                case UserIdentifierType.ExternalCustomerId:
                    var userId = 
                        _getCustomerUser.Execute(new GetCustomerUserIdQuery { ExternalIdentifier = userIdentifier });
                    ThrowIfUserNotFound(userId);
                    return userId.Value;

                default:
                    throw new NotImplementedException();
            }
        }

        private static void ThrowIfUserNotFound(int? userId)
        {
            if (userId == null || userId.Value == 0)
            {
                throw new UserNotFoundException(new ErrorParameter());
            }
        }
    }
}