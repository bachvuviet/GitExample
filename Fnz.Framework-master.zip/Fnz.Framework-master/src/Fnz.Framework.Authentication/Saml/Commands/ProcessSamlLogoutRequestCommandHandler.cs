﻿using System;
using ComponentSpace.SAML2.Exceptions;
using ComponentSpace.SAML2.Protocols;
using Fnz.Framework.Authentication.Api.Saml.Commands;
using Fnz.Framework.Authentication.Saml.DataAccess;
using Fnz.Framework.Authentication.Saml.Exceptions;
using Fnz.Framework.Authentication.Users;
using Fnz.Framework.DataAccess.Logging;

namespace Fnz.Framework.Authentication.Saml.Commands
{
    public class ProcessSamlLogoutRequestCommandHandler : IProcessSamlLogoutRequestCommandHandler
    {
        private readonly ISamlConfigurationReader _configurationReader;

        private readonly IExceptionLogger _exceptionLogger;

        private readonly ISamlUserFactory _samlUserFactory;

        public ProcessSamlLogoutRequestCommandHandler(ISamlConfigurationReader configurationReader,
                                                        IExceptionLogger exceptionLogger,
                                                        ISamlUserFactory samlUserFactory)
        {
            this._configurationReader = configurationReader;
            this._exceptionLogger = exceptionLogger;
            this._samlUserFactory = samlUserFactory;
        }

        public SamlLogoutResponse Execute(ProcessSamlLogoutRequestCommand command)
        {
            var samlConfig = this._configurationReader.GetByKey(command.SamlConfigurationKey);

            if (samlConfig.LocalPlatformRole == SamlRoleType.ServiceProvider)
            {
                return this.ProcessLogoutForServiceProvider(command, samlConfig);
            }

            throw new NotImplementedException("Logout requests are not supported where the local platform is the Identity Provider. Check the SAML configuration if the platform is a Service Provider");
        }

        private SamlLogoutResponse ProcessLogoutForServiceProvider(ProcessSamlLogoutRequestCommand command, SamlConfiguration samlConfig)
        {
            LogoutRequest logoutRequest = null;
            try
            {
                logoutRequest = new LogoutRequest(command.Request);

                // TODO: add logging

                if (SamlSignature.Verify(logoutRequest.ToXml(), samlConfig.IdentityProvider.Certificates.SigningCertificate) == false)
                {
                    throw new SamlSignatureNotValidException();
                }

                var samlUser = this._samlUserFactory.Get(command.SessionToken, logoutRequest.NameID.NameIdentifier, samlConfig.UserIdentifierType, command.ApplicationName);
                samlUser.Logout();

                // TODO: sign the responses
                return SamlLogoutMessages.IdentityProviderInitiatedSuccessResponse(samlConfig, logoutRequest);
            }
            catch (SAMLSerializationException)
            {
                return SamlLogoutMessages.IdentityProviderInitiatedInvalidSamlResponse(samlConfig);
            }
            catch (UserNotFoundException)
            {
                return SamlLogoutMessages.UserNotFoundResponse(samlConfig, logoutRequest);
            }
            catch (Exception e)
            {
                this._exceptionLogger.LogException(e, GetRequestMessage(logoutRequest));
                return SamlLogoutMessages.GeneralFailureResponse(samlConfig, logoutRequest);
            }
        }

        // this should never fail
        private static string GetRequestMessage(LogoutRequest logoutRequest)
        {
            try
            {
                return logoutRequest.ToXml().OuterXml;
            }
            catch (Exception)
            {
                return null;
            }
        }
    }
}