﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Xml;
using ComponentSpace.SAML2.Assertions;
using ComponentSpace.SAML2.Protocols;
using Fnz.Framework.Authentication.Api.Saml.Commands;
using Fnz.Framework.Authentication.Saml.DataAccess;
using Fnz.Framework.Authentication.Saml.Exceptions;

namespace Fnz.Framework.Authentication.Saml.Commands
{
    public class ProcessSamlAuthenticationResponseCommandHandler : IProcessSamlAuthenticationResponseCommandHandler
    {
        private readonly ISamlConfigurationReader _configurationReader;

        private readonly ISamlMessageLogWriter _samlLogWriter;

        private readonly IIdpLoginCommandHandler _loginHandler;

        private readonly ISamlMessageIdWriter _messageIdStore;

        public ProcessSamlAuthenticationResponseCommandHandler(ISamlConfigurationReader configurationReader,
                                                                        ISamlMessageLogWriter samlLogWriter,
                                                                        IIdpLoginCommandHandler loginHandler,
                                                                        ISamlMessageIdWriter messageIdStore)
        {
            _configurationReader = configurationReader;
            _samlLogWriter = samlLogWriter;
            _loginHandler = loginHandler;
            _messageIdStore = messageIdStore;
        }

        public SamlAuthenticationResponse Execute(ProcessSamlAuthenticationResponseCommand command)
        {
            var samlConfig = _configurationReader.GetByKey(command.SamlConfigurationKey);

            var identityProviderSigningKey = samlConfig.IdentityProvider.Certificates.GetSigningCertificate();
            var decryptionKey = samlConfig.ServiceProvider.Certificates.GetDecryptionCertificate();

            var message = new SAMLResponse(command.Assertion);

            XmlElement rawXmlForVerification;
            var assertion = this.GetSingleAssertionOrFail(message, decryptionKey, out rawXmlForVerification);

            // catch exceptions here so we can always log the assertion if anything goes wrong
            try
            {
                VerifySignatureOrFail(command.Assertion, rawXmlForVerification, identityProviderSigningKey);
                VerifyTimeConditionsOrFail(assertion.Conditions);
                VerifyReplayAttackOrFail(samlConfig.Id, assertion.ID, assertion.Conditions.NotOnOrAfter);
                VerifyDestination(samlConfig.ServiceProvider.AssertionConsumerServiceUrl, message.Destination);

                // get all attributes - assume that attributes aren't encrypted, and they only have one value
                var attributes =
                    assertion.GetAttributeStatements()
                        .SelectMany(x => x.GetUnencryptedAttributes())
                        .Select(x => new SamlCustomAttribute { Name = x.Name, Value = x.Values.First().ToString() })
                        .ToList();

                var loginCommand = new IdpLoginCommand
                                       {
                                           ApplicationName = command.ApplicationName,
                                           NameId = assertion.GetNameID(),
                                           Attributes = attributes,
                                           UserIdentifierType = samlConfig.UserIdentifierType
                                       };

                var session = this._loginHandler.Execute(loginCommand);

                _samlLogWriter.LogSuccess(SamlActionType.AuthnResponseReceived, GetExternalUserIdentifier(assertion), session.Token.UserId, message.ID, assertion.ToXml());

                return session;
            }
            catch (Exception e)
            {
                _samlLogWriter.LogFailure(SamlActionType.AuthnResponseReceived, GetExternalUserIdentifier(assertion), null, message.ID, assertion.ToXml(), e.Message);
                throw;
            }
        }

        private void VerifyDestination(string expectedDestinationUrl, string actualDestinationUrl)
        {
            if (expectedDestinationUrl.IsNullOrEmpty())
            {
                return;
            }

            if (expectedDestinationUrl != actualDestinationUrl)
            {
                throw new SamlDestinationNotValidException();
            }
        }

        private static string GetExternalUserIdentifier(SAMLAssertion assertion)
        {
            try
            {
                return assertion.GetNameID();
            }
            catch
            {
                return null;
            }
        }

        private void VerifyReplayAttackOrFail(int configurationId, string messageId, DateTime notOnOrAfter)
        {
            var success = _messageIdStore.SaveMessageId(configurationId, messageId, notOnOrAfter);

            if (!success)
            {
                throw new SamlReplayAttackException();
            }
        }

        private void VerifyTimeConditionsOrFail(Conditions conditions)
        {
            if (conditions == null)
            {
                return;
            }

            if (!conditions.CheckTimePeriod())
            {
                throw new SamlTimeConditionsException();
            }
        }

        private SAMLAssertion GetSingleAssertionOrFail(SAMLResponse message, X509Certificate2 decryptionKey, out XmlElement rawXmlForVerification)
        {
            // assume there is exactly one assertion for now
            List<SAMLAssertion> assertions = new List<SAMLAssertion>();

            if (decryptionKey == null)
            {
                assertions.AddRange(message.GetAssertions());
                assertions.AddRange(message.GetSignedAssertions().Select(x => new SAMLAssertion(x)));

                VerifyAssertionCount(assertions, false);

                rawXmlForVerification = assertions[0].ToXml();
            }
            else
            {
                assertions.AddRange(message.GetEncryptedAssertions().Select(x => x.Decrypt(decryptionKey.PrivateKey)).ToList());

                VerifyAssertionCount(assertions, true);

                rawXmlForVerification = message.GetEncryptedAssertion().DecryptToXml(decryptionKey);
            }

            return assertions[0];
        }

        private static void VerifyAssertionCount(IEnumerable<SAMLAssertion> assertions, bool shouldBeEncrypted)
        {
            if (assertions.Any() == false)
            {
                throw new SamlException(
                    "No valid {0} assertions found".FormatWith(shouldBeEncrypted ? "encrypted" : "unencrypted"));
            }

            if (assertions.Count() > 1)
            {
                throw new SamlException("SAML message has more than one assertion. This is not supported");
            }
        }

        private void VerifySignatureOrFail(XmlElement token, XmlElement assertion, X509Certificate2 identityProviderSigningKey)
        {
            if (identityProviderSigningKey == null)
            {
                // not expecting a signature, wave it through
                return;
            }

            var tokenSigned = SAMLMessageSignature.IsSigned(token);
            var assertionSigned = assertion != null && SAMLAssertionSignature.IsSigned(assertion);

            if (tokenSigned == false && assertionSigned == false)
            {
                // we are expecting a signature, problem
                throw new SamlSignatureNotValidException("SAML message has not been signed when a signature was expected");
            }

            if (tokenSigned && !SAMLMessageSignature.Verify(token, identityProviderSigningKey.PublicKey.Key))
            {
                // signature failed
                throw new SamlSignatureNotValidException();
            }

            if (assertionSigned && !SAMLAssertionSignature.Verify(assertion, identityProviderSigningKey.PublicKey.Key))
            {
                // signature failed
                throw new SamlSignatureNotValidException();
            }
        }
    }
}