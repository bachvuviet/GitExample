﻿using System;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Xml;
using Castle.Core.Internal;
using ComponentSpace.SAML2.Bindings;
using ComponentSpace.SAML2.Exceptions;
using ComponentSpace.SAML2.Protocols;
using Fnz.Framework.Authentication.Api.Saml.Commands;
using Fnz.Framework.Authentication.Saml.DataAccess;
using Fnz.Framework.Authentication.Saml.Exceptions;
using Fnz.Framework.Authentication.Users;
using Fnz.Framework.DataAccess.Logging;

namespace Fnz.Framework.Authentication.Saml.Commands
{
    public class ProcessSamlRedirectBindingLogoutRequestCommandHandler : IProcessSamlRedirectBindingLogoutRequestCommandHandler
    {
        private readonly ISamlConfigurationReader _configurationReader;

        private readonly IExceptionLogger _exceptionLogger;

        private readonly ISamlUserFactory _samlUserFactory;

        private readonly ISamlMessageLogWriter _samlLogWriter;

        public ProcessSamlRedirectBindingLogoutRequestCommandHandler(ISamlConfigurationReader configurationReader,
                                                                        IExceptionLogger exceptionLogger,
                                                                        ISamlUserFactory samlUserFactory,
                                                                        ISamlMessageLogWriter samlLogWriter)        
        {
            this._configurationReader = configurationReader;
            this._exceptionLogger = exceptionLogger;
            this._samlUserFactory = samlUserFactory;
            this._samlLogWriter = samlLogWriter;
        }

        public SamlRedirectBindingMessage Execute(ProcessSamlRedirectBindingLogoutRequestCommand command)
        {
            var samlConfig = this._configurationReader.GetByKey(command.SamlConfigurationKey);

            if (samlConfig.LocalPlatformRole == SamlRoleType.ServiceProvider)
            {
                return this.ProcessLogoutForServiceProvider(command, samlConfig);
            }

            throw new NotImplementedException("Logout requests are not supported where the local platform is the Identity Provider. Check the SAML configuration if the platform is a Service Provider");
        }

        private SamlRedirectBindingMessage ProcessLogoutForServiceProvider(ProcessSamlRedirectBindingLogoutRequestCommand command, SamlConfiguration samlConfig)
        {
            LogoutRequest logoutRequest = null;
            var serviceProviderSigningKey = samlConfig.ServiceProvider.Certificates.SigningCertificate.IsNullOrEmpty()
                          ? null
                          : new X509Certificate2(
                                samlConfig.ServiceProvider.Certificates.SigningCertificate,
                                samlConfig.ServiceProvider.Certificates.SigningCertificatePassword).PrivateKey;

            try
            {
                var identityProviderSigningKey =
                    samlConfig.IdentityProvider.Certificates.SigningCertificate.IsNullOrEmpty()
                        ? null
                        : new X509Certificate2(samlConfig.IdentityProvider.Certificates.SigningCertificate,
                                                samlConfig.IdentityProvider.Certificates.SigningCertificatePassword).PublicKey.Key;

                var message = GetMessage(command, identityProviderSigningKey);

                logoutRequest = new LogoutRequest(message);

                var samlUser = this._samlUserFactory.Get(
                    command.SessionToken,
                    logoutRequest.NameID.NameIdentifier,
                    samlConfig.UserIdentifierType,
                    command.ApplicationName);

                _samlLogWriter.LogSuccess(SamlActionType.LogoutRequestReceived, logoutRequest.NameID.NameIdentifier, samlUser.FnzUserId, null, message);

                samlUser.Logout();

                var response = SamlLogoutMessages.IdentityProviderInitiatedSuccessResponse(samlConfig, logoutRequest);

                _samlLogWriter.LogSuccess(SamlActionType.LogoutResponseSent, logoutRequest.NameID.NameIdentifier, samlUser.FnzUserId, null, response.Xml);

                return response.ToRedirectUrl(samlConfig.IdentityProvider.Logout.LogoutResponseUrl, serviceProviderSigningKey);
            }
            catch (SAMLSerializationException e)
            {
                this._exceptionLogger.LogException(e, command.Url);
                return
                    SamlLogoutMessages.IdentityProviderInitiatedInvalidSamlResponse(samlConfig)
                        .ToRedirectUrl(samlConfig.IdentityProvider.Logout.LogoutResponseUrl, serviceProviderSigningKey);
            }
            catch (UserNotFoundException e)
            {
                this._exceptionLogger.LogException(e, GetRequestMessage(logoutRequest));
                return
                    SamlLogoutMessages.UserNotFoundResponse(samlConfig, logoutRequest)
                        .ToRedirectUrl(samlConfig.IdentityProvider.Logout.LogoutResponseUrl, serviceProviderSigningKey);
            }
            catch (Exception e)
            {
                this._exceptionLogger.LogException(e, GetRequestMessage(logoutRequest));
                return
                    SamlLogoutMessages.GeneralFailureResponse(samlConfig, logoutRequest)
                        .ToRedirectUrl(samlConfig.IdentityProvider.Logout.LogoutResponseUrl, serviceProviderSigningKey);                
            }
        }

        // this should never fail
        private static string GetRequestMessage(LogoutRequest logoutRequest)
        {
            try
            {
                return logoutRequest.ToXml().OuterXml;
            }
            catch (Exception)
            {
                return null;
            }
        }

        private static XmlElement GetMessage(
            ProcessSamlRedirectBindingLogoutRequestCommand command,
            AsymmetricAlgorithm publicKey)
        {
            XmlElement message;
            string relayState;
            bool isSigned;
            HTTPRedirectBinding.GetRequestFromRedirectURL(
                command.Url,
                out message,
                out relayState,
                out isSigned,
                publicKey);

            if (isSigned == false && publicKey != null)
            {
                throw new SamlMessageNotSignedException();
            }

            return message;
        }
    }
}