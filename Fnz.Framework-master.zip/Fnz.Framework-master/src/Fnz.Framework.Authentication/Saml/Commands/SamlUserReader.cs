using System;
using Fnz.Framework.Authentication.Api.Sessions;
using Fnz.Framework.Authentication.Saml.DataAccess;
using Fnz.Framework.Authentication.Saml.Exceptions;

namespace Fnz.Framework.Authentication.Saml.Commands
{
    public class SamlUserReader : ISamlUserReader
    {
        private readonly ILogoutCommandHandler _logout;

        private readonly IUserTokenReader _userTokenReader;

        private readonly ISamlUserIdentiferQueryHandler _userIdentiferQueryHandler;

        public SamlUserReader(ILogoutCommandHandler logout, IUserTokenReader userTokenReader, ISamlUserIdentiferQueryHandler userIdentiferQueryHandler)
        {
            this._logout = logout;
            this._userTokenReader = userTokenReader;
            this._userIdentiferQueryHandler = userIdentiferQueryHandler;
        }

        public SamlUser Get(Guid? sessionToken, string userIdentifier, UserIdentifierType userIdentifierType, string applicationName)
        {
            var userId = this._userIdentiferQueryHandler.GetFnzUserId(userIdentifier, userIdentifierType);
            var propositionId = this.GetPropositionId(applicationName);
            var token = this._userTokenReader.Get(userId, propositionId);

            ThrowIfServiceUserDifferentToSamlRequest(sessionToken, token);

            return new SamlUser(this._logout, token.Token, userId);
        }

        private static void ThrowIfServiceUserDifferentToSamlRequest(Guid? sessionToken, UserToken token)
        {
            if (sessionToken != null)
            {
                if (token == null || sessionToken.Value != token.Token)
                {
                    throw new SamlUserMismatchException();
                }
            }
        }

        private int GetPropositionId(string applicationName)
        {
            int propositionId;
            if (int.TryParse(applicationName, out propositionId))
            {
                return propositionId;
            }

            throw new InvalidApplicationNameException();
        }
    }
}