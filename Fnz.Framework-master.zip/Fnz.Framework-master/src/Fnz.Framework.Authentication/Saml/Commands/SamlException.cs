﻿using System;

namespace Fnz.Framework.Authentication.Saml.Commands
{
    public class SamlException : Exception
    {
        public SamlException(string message) : base(message)
        {
        }
    }
}