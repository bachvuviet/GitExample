﻿using Fnz.Framework.Authentication.Saml.DataAccess;

namespace Fnz.Framework.Authentication.Saml.Commands
{
    public interface ISamlUserIdentifiers
    {
        string GetSharedIdentifier(SamlUserIdentifierType userIdentifierType, int userId);

        int GetFnzUserId(string userIdentifier, SamlUserIdentifierType userIdentifierType);
    }
}