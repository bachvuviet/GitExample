using System;
using Fnz.Framework.Authentication.Api.Sessions;

namespace Fnz.Framework.Authentication.Saml.Commands
{
    public interface ISamlUserFactory
    {
        SamlUser Get(Guid? sessionToken, string userIdentifier, UserIdentifierType userIdentifierType, string applicationName);
    }
}