﻿using System.Xml;
using Fnz.Core.Platform.Framework.Commands;
using Fnz.Framework.Authentication.Api.Saml.Commands;

namespace Fnz.Framework.Authentication.Saml.Commands
{
    public interface ILogSamlMessageCommandHandler : ICommandHandler<SamlLogMessage>
    {
    }

    public class SamlLogMessage
    {
        // public SamlMessageType Type { get; set; }

        public XmlElement Message { get; set; }

        public SamlCustomAttribute Attributes { get; set; }
    }
}