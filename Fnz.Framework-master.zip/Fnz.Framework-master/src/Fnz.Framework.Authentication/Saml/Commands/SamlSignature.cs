﻿using System.Security.Cryptography.X509Certificates;
using System.Xml;

using Castle.Core.Internal;

using ComponentSpace.SAML2.Protocols;

using Fnz.Framework.Authentication.Saml.Exceptions;

namespace Fnz.Framework.Authentication.Saml.Commands
{
    public static class SamlSignature
    {
        public static bool Verify(XmlElement message, byte[] certificateBytes)
        {
            if (SAMLMessageSignature.IsSigned(message) == false)
            {
                return true;
            }

            if (certificateBytes.IsNullOrEmpty())
            {
                throw new InvalidSamlConfigurationException("No signing certificate found");
            }

            var certificate = new X509Certificate2(certificateBytes);
            return SAMLMessageSignature.Verify(message, certificate);
        }
    }
}