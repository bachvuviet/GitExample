using System.Security.Cryptography;

using ComponentSpace.SAML2.Bindings;
using Fnz.Framework.Authentication.Api.Saml.Commands;

namespace Fnz.Framework.Authentication.Saml.Commands
{
    internal static class SamlLogoutResponseExtensions
    {
        public static SamlRedirectBindingMessage ToRedirectUrl(this SamlLogoutResponse message, string responseUrl, AsymmetricAlgorithm key)
        {
            var url = HTTPRedirectBinding.CreateResponseRedirectURL(responseUrl, message.Xml, null, key);
            return new SamlRedirectBindingMessage { Url = url };
        }
    }
}