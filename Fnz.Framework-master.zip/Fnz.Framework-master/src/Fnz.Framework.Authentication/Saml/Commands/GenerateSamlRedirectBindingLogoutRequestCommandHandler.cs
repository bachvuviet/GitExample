﻿using System;
using System.Security.Cryptography.X509Certificates;
using Castle.Core.Internal;
using ComponentSpace.SAML2.Bindings;
using Fnz.Framework.Authentication.Api.Saml.Commands;
using Fnz.Framework.Authentication.Api.Saml.Queries;
using Fnz.Framework.Authentication.Saml.DataAccess;

namespace Fnz.Framework.Authentication.Saml.Commands
{
    public class GenerateSamlRedirectBindingLogoutRequestCommandHandler : IGenerateSamlRedirectBindingLogoutRequestCommandHandler
    {
        private readonly ISamlConfigurationReader _configurationReader;

        private readonly ISamlSharedIdentifierQueryHandler _getSharedIdentifier;

        private readonly ISamlMessageLogWriter _samllogWriter;

        public GenerateSamlRedirectBindingLogoutRequestCommandHandler(
            ISamlConfigurationReader configurationReader,
            ISamlSharedIdentifierQueryHandler getSharedIdentifier,
            ISamlMessageLogWriter samllogWriter)
        {
            this._configurationReader = configurationReader;
            _getSharedIdentifier = getSharedIdentifier;
            this._samllogWriter = samllogWriter;
        }

        public SamlRedirectBindingMessage Execute(SamlGenerateLogoutRequestCommand command)
        {
            var samlConfig = this._configurationReader.GetByKey(command.SamlConfigurationKey);

            if (samlConfig.LocalPlatformRole == SamlRoleType.ServiceProvider)
            {
                return this.GenerateLogoutRequestForServiceProvider(command, samlConfig);
            }

            throw new NotImplementedException("Logout requests are not supported where the local platform is the Identity Provider. Check the SAML configuration if the platform is a Service Provider");
        }

        private SamlRedirectBindingMessage GenerateLogoutRequestForServiceProvider(SamlGenerateLogoutRequestCommand command, SamlConfiguration samlConfig)
        {
            var userIdentifier = _getSharedIdentifier.Execute(new SamlSharedIdentifierQuery { UserId = command.UserId, UserIdentifierType = samlConfig.UserIdentifierType });
            var request = SamlLogoutMessages.ServiceProviderInitiatedRequest(samlConfig, userIdentifier);

            this._samllogWriter.LogSuccess(SamlActionType.LogoutRequestSent, userIdentifier, command.UserId, null, request.Xml);

            string url;
            if (samlConfig.ServiceProvider.Certificates.SigningCertificate.IsNullOrEmpty() == false)
            {
                var certificate = new X509Certificate2(samlConfig.ServiceProvider.Certificates.SigningCertificate,
                                                        samlConfig.ServiceProvider.Certificates.SigningCertificatePassword);
                url = HTTPRedirectBinding.CreateRequestRedirectURL(samlConfig.IdentityProvider.Logout.LogoutRequestUrl, request.Xml, null, certificate.PrivateKey);
            }
            else
            {
                url = HTTPRedirectBinding.CreateRequestRedirectURL(samlConfig.IdentityProvider.Logout.LogoutRequestUrl, request.Xml, null, null);
            }

            return new SamlRedirectBindingMessage { Url = url };
        }
    }
}
