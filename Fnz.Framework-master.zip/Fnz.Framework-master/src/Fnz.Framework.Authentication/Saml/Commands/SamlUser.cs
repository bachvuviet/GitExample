using System;
using Fnz.Framework.Authentication.Api.Sessions;

namespace Fnz.Framework.Authentication.Saml.Commands
{
    public class SamlUser
    {
        private readonly ILogoutCommandHandler _logout;

        private readonly Guid? _token;

        public SamlUser(ILogoutCommandHandler logout, Guid? token, int fnzUserId)
        {
            this.FnzUserId = fnzUserId;
            this._logout = logout;
            this._token = token;
        }

        public int FnzUserId { get; private set; }

        public void Logout()
        {
            if (this._token.HasValue)
            {
                this._logout.Execute(this._token);
            }
        }
    }
}