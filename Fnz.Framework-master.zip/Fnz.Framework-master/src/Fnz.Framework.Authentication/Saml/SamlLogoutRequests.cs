﻿using ComponentSpace.SAML2.Assertions;
using ComponentSpace.SAML2.Protocols;
using Fnz.Framework.Authentication.Api.Saml.Commands;
using Fnz.Framework.Authentication.Saml.DataAccess;
using Fnz.Framework.Util;

namespace Fnz.Framework.Authentication.Saml
{
    public static class SamlLogoutRequests
    {
        public static SamlLogoutRequest ServiceProviderInitiated(SamlConfiguration samlConfig, string userIdentifier)
        {
            var logoutRequest = new LogoutRequest();
            logoutRequest.NameID = new NameID(userIdentifier);
            logoutRequest.Issuer = new Issuer(samlConfig.ServiceProvider.Logout.LogoutRequestUrl);
            logoutRequest.IssueInstant = Clock.Now();

            return new SamlLogoutRequest(logoutRequest.ToXml());            
        }
    }
}