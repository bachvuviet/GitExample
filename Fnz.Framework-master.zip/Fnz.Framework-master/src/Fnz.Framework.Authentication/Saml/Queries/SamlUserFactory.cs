using System;
using Fnz.Framework.Authentication.Api.Saml.Queries;
using Fnz.Framework.Authentication.Api.Sessions;
using Fnz.Framework.Authentication.Saml.Commands;
using Fnz.Framework.Authentication.Saml.Exceptions;

namespace Fnz.Framework.Authentication.Saml.Queries
{
    public class SamlUserFactory : ISamlUserFactory
    {
        private readonly ILogoutCommandHandler _logout;

        private readonly IUserTokenReader _userTokenReader;

        private readonly ISamlFnzUserIdQueryHandler _getFnzUserId;

        public SamlUserFactory(ILogoutCommandHandler logout, IUserTokenReader userTokenReader, ISamlFnzUserIdQueryHandler getFnzUserId)
        {
            this._logout = logout;
            this._userTokenReader = userTokenReader;
            _getFnzUserId = getFnzUserId;
        }

        public SamlUser Get(Guid? sessionToken, string userIdentifier, UserIdentifierType userIdentifierType, string applicationName)
        {
            var userId = _getFnzUserId.Execute(new SamlFnzUserIdQuery { ExternalIdentifier = userIdentifier, UserIdentifierType = userIdentifierType });
            var propositionId = this.GetPropositionId(applicationName);
            var token = this._userTokenReader.Get(userId, propositionId);

            ThrowIfServiceUserDifferentToSamlRequest(sessionToken, token);

            return new SamlUser(this._logout, token.Token, userId);
        }

        private static void ThrowIfServiceUserDifferentToSamlRequest(Guid? sessionToken, UserToken token)
        {
            if (sessionToken != null)
            {
                if (token == null || sessionToken.Value != token.Token)
                {
                    throw new SamlUserMismatchException();
                }
            }
        }

        private int GetPropositionId(string applicationName)
        {
            int propositionId;
            if (int.TryParse(applicationName, out propositionId))
            {
                return propositionId;
            }

            throw new InvalidApplicationNameException();
        }
    }
}