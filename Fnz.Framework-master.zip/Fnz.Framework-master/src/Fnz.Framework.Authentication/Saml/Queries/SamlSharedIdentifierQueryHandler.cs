﻿using System;
using Fnz.Framework.Authentication.Api.Customers;
using Fnz.Framework.Authentication.Api.Saml.Queries;
using Fnz.Framework.Authentication.Api.Sessions;
using Fnz.Framework.Authentication.Api.Users;
using Fnz.Framework.Authentication.Saml.Exceptions;

namespace Fnz.Framework.Authentication.Saml.Queries
{
    public class SamlSharedIdentifierQueryHandler : ISamlSharedIdentifierQueryHandler
    {
        private readonly IUserQueryHandler _getUsers;

        private readonly ICustomerIdentifierByUserIdQueryHandler _getUserCustomerIdentifier;

        public SamlSharedIdentifierQueryHandler(IUserQueryHandler getUsers, ICustomerIdentifierByUserIdQueryHandler getUserCustomerIdentifier)
        {
            _getUsers = getUsers;
            _getUserCustomerIdentifier = getUserCustomerIdentifier;
        }

        public string Execute(SamlSharedIdentifierQuery query)
        {
            var identifier = this.GetIdentifier(query.UserIdentifierType, query.UserId);

            if (identifier.IsNullOrEmpty())
            {
                throw new NoSamlIdentifierException();
            }

            return identifier;            
        }

        private string GetIdentifier(UserIdentifierType userIdentifierType, int userId)
        {
            switch (userIdentifierType)
            {
                case UserIdentifierType.UserId:
                    return userId.ToString();

                case UserIdentifierType.ExternalUserId:
                    var user = _getUsers.Execute(new UserQuery { RequestedUserId = userId });
                    return user.ExternalUserId;

                case UserIdentifierType.ExternalCustomerId:
                    var customer = _getUserCustomerIdentifier.Execute(new CustomerIdentifierByUserQuery { UserId = userId });
                    return customer.ExternalCustomerId;

                default:
                    throw new NotImplementedException();
            }
        }
    }
}