﻿using System;
using Fnz.Framework.Authentication.Api.Saml.Api.Queries;
using Fnz.Framework.Authentication.Api.Saml.Queries;
using Fnz.Framework.Authentication.Saml.DataAccess;

namespace Fnz.Framework.Authentication.Saml.Queries
{
    public class SamlLogoutDestinationsQueryHandler : ISamlLogoutDestinationsQueryHandler
    {
        private readonly ISamlConfigurationReader _configurationReader;

        public SamlLogoutDestinationsQueryHandler(ISamlConfigurationReader configurationReader)
        {
            this._configurationReader = configurationReader;
        }

        public SamlLogoutDestinations Execute(SamlLogoutDestinationsQuery query)
        {
            var config = this._configurationReader.GetByKey(query.SamlConfigurationKey);

            if (config.LocalPlatformRole == SamlRoleType.ServiceProvider)
            {
                return GetIdentityProviderDestinations(config);
            }

            throw new NotImplementedException("Identity provider capability is not implemented. Check the SAML configuration");
        }

        private static SamlLogoutDestinations GetIdentityProviderDestinations(SamlConfiguration config)
        {
            return new SamlLogoutDestinations
                       {
                           LogoutRequestDestination =
                               config.IdentityProvider.Logout.LogoutRequestUrl,
                           LogoutResponseDestination =
                               config.IdentityProvider.Logout.LogoutResponseUrl
                       };
        }
    }
}