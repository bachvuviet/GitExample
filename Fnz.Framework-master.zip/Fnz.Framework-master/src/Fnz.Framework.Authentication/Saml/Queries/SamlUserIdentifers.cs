﻿using System;
using Fnz.Framework.Authentication.Api.Customers;
using Fnz.Framework.Authentication.Api.Users;
using Fnz.Framework.Authentication.Saml.Commands;
using Fnz.Framework.Authentication.Saml.DataAccess;
using Fnz.Framework.Authentication.Saml.Exceptions;
using Fnz.Framework.Authentication.Users;
using Fnz.Framework.Cca.ErrorHandling.Contracts;

namespace Fnz.Framework.Authentication.Saml.Queries
{
    public class SamlUserIdentifers : ISamlUserIdentifiers
    {
        private readonly IUserQueryHandler _getUsers;

        private readonly ICustomerIdentifierByUserIdQueryHandler _getUserCustomerIdentifier;

        private readonly IGetCustomerUserIdQueryHandler _getCustomerUser;

        public SamlUserIdentifers(IUserQueryHandler getUsers, ICustomerIdentifierByUserIdQueryHandler getUserCustomerIdentifier, IGetCustomerUserIdQueryHandler getCustomerUser)
        {
            _getUsers = getUsers;
            _getUserCustomerIdentifier = getUserCustomerIdentifier;
            _getCustomerUser = getCustomerUser;
        }

        public string GetSharedIdentifier(SamlUserIdentifierType userIdentifierType, int userId)
        {
            var identifier = this.GetIdentifier(userIdentifierType, userId);

            if (identifier.IsNullOrEmpty())
            {
                throw new NoSamlIdentifierException();
            }

            return identifier;
        }

        private string GetIdentifier(SamlUserIdentifierType userIdentifierType, int userId)
        {
            switch (userIdentifierType)
            {
                case SamlUserIdentifierType.FnzUserId:
                    return userId.ToString();

                case SamlUserIdentifierType.ExternalUserId:
                    var user = _getUsers.Execute(new UserQuery { RequestedUserId = userId });
                    return user.ExternalUserId;

                case SamlUserIdentifierType.ExternalCustomerId:
                    var customer = _getUserCustomerIdentifier.Execute(new CustomerIdentifierByUserQuery { UserId = userId });
                    return customer.ExternalCustomerId;

                default:
                    throw new NotImplementedException();
            }
        }

        public int GetFnzUserId(string userIdentifier, SamlUserIdentifierType userIdentifierType)
        {
            switch (userIdentifierType)
            {
                case SamlUserIdentifierType.ExternalUserId:
                    var user = _getUsers.Execute(new UserQuery { ExternalUserId = userIdentifier });
                    return user.Id;

                case SamlUserIdentifierType.FnzUserId:
                    return int.Parse(userIdentifier);

                case SamlUserIdentifierType.ExternalCustomerId:
                    var userId = 
                        _getCustomerUser.Execute(new GetCustomerUserIdQuery { ExternalIdentifier = userIdentifier });
                    ThrowIfUserNotFound(userId);
                    return userId.Value;

                default:
                    throw new NotImplementedException();
            }
        }

        private static void ThrowIfUserNotFound(int? userId)
        {
            if (userId == null || userId.Value == 0)
            {
                throw new UserNotFoundException(new ErrorParameter());
            }
        }
    }
}