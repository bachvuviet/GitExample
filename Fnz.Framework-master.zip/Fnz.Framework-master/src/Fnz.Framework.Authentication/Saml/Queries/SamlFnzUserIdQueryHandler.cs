﻿using System;
using Fnz.Framework.Authentication.Api.Customers;
using Fnz.Framework.Authentication.Api.Saml.Queries;
using Fnz.Framework.Authentication.Api.Sessions;
using Fnz.Framework.Authentication.Api.Users;
using Fnz.Framework.Authentication.Users;
using Fnz.Framework.Cca.ErrorHandling.Contracts;

namespace Fnz.Framework.Authentication.Saml.Queries
{
    public class SamlFnzUserIdQueryHandler : ISamlFnzUserIdQueryHandler
    {
        private readonly IUserQueryHandler _getUsers;

        private readonly IGetCustomerUserIdQueryHandler _getCustomerUser;

        public SamlFnzUserIdQueryHandler(IUserQueryHandler getUsers, IGetCustomerUserIdQueryHandler getCustomerUser)
        {
            _getUsers = getUsers;
            _getCustomerUser = getCustomerUser;
        }

        public int Execute(SamlFnzUserIdQuery query)
        {
            switch (query.UserIdentifierType)
            {
                case UserIdentifierType.ExternalUserId:
                    var user = _getUsers.Execute(new UserQuery { ExternalUserId = query.ExternalIdentifier });
                    return user.Id;

                case UserIdentifierType.UserId:
                    return int.Parse(query.ExternalIdentifier);

                case UserIdentifierType.ExternalCustomerId:
                    var userId =
                        _getCustomerUser.Execute(new GetCustomerUserIdQuery { ExternalIdentifier = query.ExternalIdentifier });
                    ThrowIfUserNotFound(userId);
                    return userId.Value;

                default:
                    throw new NotImplementedException();
            }            
        }

        private static void ThrowIfUserNotFound(int? userId)
        {
            if (userId == null || userId.Value == 0)
            {
                throw new UserNotFoundException(new ErrorParameter());
            }
        }
    }
}