﻿using System;
using ComponentSpace.SAML2;
using ComponentSpace.SAML2.Assertions;
using ComponentSpace.SAML2.Protocols;
using Fnz.Framework.Authentication.Api.Saml.Commands;
using Fnz.Framework.Authentication.Saml.DataAccess;
using Fnz.Framework.Util;

namespace Fnz.Framework.Authentication.Saml
{
    public static class SamlLogoutMessages
    {
        public static SamlLogoutRequest ServiceProviderInitiatedRequest(SamlConfiguration samlConfig, string userIdentifier)
        {
            var logoutRequest = new LogoutRequest();
            logoutRequest.NameID = new NameID(userIdentifier);
            logoutRequest.Issuer = new Issuer(GetIssuer(samlConfig));
            logoutRequest.IssueInstant = Clock.Now();
            logoutRequest.Destination = samlConfig.IdentityProvider.Logout.LogoutRequestUrl;

            return new SamlLogoutRequest(logoutRequest.ToXml());
        }

        public static SamlLogoutResponse IdentityProviderInitiatedSuccessResponse(SamlConfiguration samlConfig, LogoutRequest logoutRequest)
        {
            var logoutResponse = GetBasicResponse(samlConfig, logoutRequest);
            logoutResponse.Status = new Status(SAMLIdentifiers.PrimaryStatusCodes.Success, null);
            return new SamlLogoutResponse(logoutResponse.ToXml());
        }

        public static SamlLogoutResponse IdentityProviderInitiatedInvalidSamlResponse(SamlConfiguration samlConfig)
        {
            var logoutResponse = new LogoutResponse();
            logoutResponse.Status = new Status(SAMLIdentifiers.PrimaryStatusCodes.Requester, "The request message could not be read");
            logoutResponse.Destination = samlConfig.IdentityProvider.Logout.LogoutResponseUrl;
            logoutResponse.IssueInstant = Clock.Now();

            return new SamlLogoutResponse(logoutResponse.ToXml());
        }

        public static SamlLogoutResponse UserNotFoundResponse(SamlConfiguration samlConfig, LogoutRequest logoutRequest)
        {
            var logoutResponse = GetBasicResponse(samlConfig, logoutRequest);
            logoutResponse.Status = new Status(SAMLIdentifiers.PrimaryStatusCodes.Responder, SAMLIdentifiers.SecondaryStatusCodes.AuthnFailed, "User not found");
            return new SamlLogoutResponse(logoutResponse.ToXml());
        }

        public static SamlLogoutResponse GeneralFailureResponse(SamlConfiguration samlConfig, LogoutRequest logoutRequest)
        {
            var logoutResponse = GetBasicResponse(samlConfig, logoutRequest);
            logoutResponse.Status = new Status(SAMLIdentifiers.PrimaryStatusCodes.Responder, "There was an error responding to the logout request");
            return new SamlLogoutResponse(logoutResponse.ToXml());
        }

        private static LogoutResponse GetBasicResponse(SamlConfiguration samlConfig, LogoutRequest logoutRequest)
        {
            var logoutResponse = new LogoutResponse();
            logoutResponse.Issuer = new Issuer(GetIssuer(samlConfig));
            logoutResponse.InResponseTo = logoutRequest != null ? logoutRequest.ID : null;
            logoutResponse.Destination = samlConfig.IdentityProvider.Logout.LogoutResponseUrl;
            logoutResponse.IssueInstant = Clock.Now();
            return logoutResponse;
        }

        private static string GetIssuer(SamlConfiguration samlConfig)
        {
            return samlConfig.ServiceProvider.MetadataUrl.IsNotNullOrEmpty()
                       ? samlConfig.ServiceProvider.MetadataUrl
                       : samlConfig.ServiceProvider.Logout.LogoutRequestUrl;
        }
    }
}