﻿using Fnz.Framework.Authentication.Api.Errors;
using Fnz.Framework.Cca.ErrorHandling.Contracts;
using Fnz.Framework.Cca.ErrorHandling.Exceptions;

namespace Fnz.Framework.Authentication.Users
{
    public class UserNotFoundException : EntityNotFoundException
    {
        private const string Format = "User with id {0} not found.";

        public UserNotFoundException(ErrorParameter parameter)
            : base(ErrorCodes.UserNotFound, string.Format(Format, parameter.Value), parameter)
        {
        }
    }
}