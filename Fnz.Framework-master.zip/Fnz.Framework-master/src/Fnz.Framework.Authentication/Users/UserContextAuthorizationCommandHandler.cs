﻿using Fnz.Framework.Authentication.Api.Customers;
using Fnz.Framework.Authentication.Api.Errors;
using Fnz.Framework.Authentication.Api.Users;
using Fnz.Framework.Cca.ErrorHandling.Contracts;
using Fnz.Framework.Cca.ErrorHandling.Exceptions;

namespace Fnz.Framework.Authentication.Users
{
    public class UserContextAuthorizationCommandHandler : IUserContextAuthorizationCommandHandler
    {
        private readonly IUserQueryHandler _getUser;

        private readonly IGetCustomerUserIdQueryHandler _getCustomerUser;

        public UserContextAuthorizationCommandHandler(IUserQueryHandler getUser, IGetCustomerUserIdQueryHandler getCustomerUser)
        {
            _getUser = getUser;
            _getCustomerUser = getCustomerUser;
        }

        public int Execute(UserContextAuthorizationCommand command)
        {
            if (command.HasExactlyOneIdentifier() == false)
            {
                throw UnauthorizedException();
            }

            try
            {
                if (command.HasExternalCustomerId)
                {
                    return GetUserFromCustomerId(command.ExternalCustomerId);
                }

                return this.GetUserFromUserId(command);
            }
            catch (UserNotFoundException)
            {
                throw UnauthorizedException();
            }
        }

        private int GetUserFromUserId(UserContextAuthorizationCommand command)
        {
            var user =
                _getUser.Execute(
                    new UserQuery
                    {
                        ApplicationName = command.ApplicationName,
                        RequestedUserId = command.UserId,
                        UserName = command.UserName,
                        ExternalUserId = command.ExternalUserId,
                        Email = command.EmailAddress
                    });
            return user.Id;
        }

        private int GetUserFromCustomerId(string externalCustomerId)
        {
            var userId =
                _getCustomerUser.Execute(new GetCustomerUserIdQuery { ExternalIdentifier = externalCustomerId });

            if (userId.HasValue == false)
            {
                throw new UserNotFoundException(new ErrorParameter());
            }

            return userId.Value;
        }

        private static UnauthorizedException UnauthorizedException()
        {
            return new UnauthorizedException(ErrorCodes.UnauthorizedAccess);
        }
    }
}