using System;
using Fnz.Framework.DataAccess;

namespace Fnz.Framework.DocumentRepository.Api
{
    public static class RecordsetUtils
    {
        public static long GetFileStoreId(IRecordset document)
        {
            long fileStoreId = 0;

            var id = document["FileStoreID"];
            if (id != null)
            {
                Int64.TryParse(id.ToString(), out fileStoreId);
            }

            return fileStoreId;
        }
    }
}
