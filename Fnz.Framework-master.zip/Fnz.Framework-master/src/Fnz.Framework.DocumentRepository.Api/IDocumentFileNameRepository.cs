﻿namespace Fnz.Framework.DocumentRepository.Api
{
    /// <summary>
    /// Get document name from Documents.Documents
    /// [Obsolete("ID is specific to the technology being used and calls by ID should be avoided where possible.  Do not use for new usage; was put in place as transition away from this behaviour.")
    /// </summary>
    //// [Obsolete("ID is specific to the technology being used and calls by ID should be avoided where possible.  Do not use for new usage; was put in place as transition away from this behaviour.")] 
    public interface IDocumentFileNameRepository
    {
        string GetDocumentFilenameByDocId(int docId);
    }
}
