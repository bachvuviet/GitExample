﻿using System;

namespace Fnz.Framework.DocumentRepository.Api
{
    public class Document
    {
        public long Id { get; set; }

        public string Filename { get; set; }

        public DateTime DateTimeAdded { get; set; }

        /// <summary>
        /// The filestoreID of the document if it resides in the legacy Fnz filestore
        /// </summary>
        public long? LegacyFilestoreId { get; set; }

        /// <summary>
        /// The filename that the user sees (may be null)
        /// </summary>
        public string DisplayFilename { get; set; }
    }
}