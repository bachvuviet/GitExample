﻿namespace Fnz.Framework.DocumentRepository.Api
{
    public enum SaveActionEnum
    {
        Create,
        Update,
        Unknown
    }
}