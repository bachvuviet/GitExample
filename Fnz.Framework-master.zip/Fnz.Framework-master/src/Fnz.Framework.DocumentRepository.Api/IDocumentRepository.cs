using System;
using System.IO;

namespace Fnz.Framework.DocumentRepository.Api
{
    /// <summary>
    /// The Api for storing and loading document data. Implementations of this can be storing to different repositories.
    /// All storing and loading of blob data should be done via this interface.
    /// </summary>
    public interface IDocumentRepository : IDisposable
    {
        /// <summary>
        /// Save a document 
        /// </summary>
        /// <param name="data">document contents</param>
        /// <param name="filename">the name of the files to store</param>
        /// <param name="documentTypeId">the id of the DocumentType which indicates what type of document it is and what retention period it will have</param>
        /// <returns>Information about submitted document</returns>
        Document SaveDocument(Stream data, string filename, short documentTypeId);

        /// <summary>
        /// Save a document 
        /// </summary>
        /// <param name="data">document contents</param>
        /// <param name="filename">the name of the files to store</param>
        /// <param name="retentionClass">the retention class of the document e.g. 'FNZ Regulatory' - this is used when deciding when the document should be deleted </param>
        /// <returns>Information about submitted document</returns>
        Document SaveDocument(Stream data, string filename, string retentionClass);

        /// <summary>
        /// Save a document using the documentTypeId that might be identified by the filename of the task
        /// </summary>
        /// <param name="filePath">path to the document contents</param>
        /// <param name="filename">the name of the files to store</param>
        /// <param name="taskId">The Id of the task whose request file output we are saviong </param>
        /// <param name="saveDestination">A hint to the implementing class to decide where to store the data to (though depending on the implementation it may ignore this)</param>
        void SaveTaskDocument(string filePath, string filename, int taskId, DocumentStoreType saveDestination);

        /// <summary>
        /// Save a document - its binary data will be saved to the filestore if we are configured to do so
        /// </summary>
        /// <param name="data">document contents</param>
        /// <param name="filename">the name to give the document</param>
        /// <param name="saveAction">whether to create a new document or update an existing document</param>
        /// <returns>Information about submitted document</returns>
        Document SaveDocument(byte[] data, string filename, SaveActionEnum saveAction);        
        
        /// <summary>
        /// Save a document - its binary data will be saved to the filestore if we are configured to do so
        /// </summary>
        /// <param name="data">document contents</param>
        /// <param name="filename">the name to give the document</param>
        /// <param name="saveAction">whether to create a new document or update an existing document</param>
        /// <returns>Information about submitted document</returns>
        Document SaveDocument(Stream data, string filename, SaveActionEnum saveAction);

        /// <summary>
        /// Save a document - its binary data is referenced by the 'dataFilePath'
        /// </summary>
        /// <param name="dataFilePath">location of the file that contains the document contents</param>
        /// <param name="filename">the name to give the document</param>
        /// <param name="saveAction">whether to create a new document or update an existing document</param>
        /// <returns>Information about submitted document</returns>
        Document SaveDocument(string dataFilePath, string filename, SaveActionEnum saveAction);       
        
        /// <summary>
        /// Save a document - its binary data is referenced by the 'dataFilePath'
        /// </summary>
        /// <param name="dataFilePath">location of the file that contains the document contents</param>
        /// <param name="filename">the name to give the document</param>
        /// <param name="saveAction">whether to create a new document or update an existing document</param>
        /// <param name="saveDestination">A hint to the implementing class to decide where to store the data to (though depending on the implementation it may ignore this)</param>
        Document SaveDocument(string dataFilePath, string filename, SaveActionEnum saveAction, DocumentStoreType saveDestination);

        /// <summary>
        /// To find if a document with the name specified exists.
        /// </summary>
        bool DocumentExists(string fileName);

        /// <summary>
        /// Return the data for the document with the specified name
        /// </summary>
        byte[] GetDocumentData(string fileName);

        /// <summary>
        /// Return the data for the document with the specified Id
        /// </summary>
        byte[] GetDocumentData(long documentId);

        //TODO: [CG]
        //Stream GetDocumentData(string fileName);

        /// <summary>
        /// Delete the document with the specified filename
        /// </summary>
        void DeleteDocument(string fileName);

        /// <summary>
        /// Delete the document with the specified Id
        /// </summary>
        void DeleteDocument(long documentId);        
        
        /// <summary>
        /// Set the retention period of the document
        /// </summary>
        void SetDocumentRetentionPeriod(string fileName, int numberOfDaysTillDeletion);
        
        /// <summary>
        /// Set the retention period of the document
        /// </summary>
        void SetDocumentRetentionPeriod(int documentId, int numberOfDaysTillDeletion);
        
        /// <summary>
        /// Set the retention class of the document
        /// </summary>
        void SetDocumentRetentionClass(string filename, string retentionClass);
        
        /// <summary>
        /// Set the retention class of the document
        /// </summary>
        void SetDocumentRetentionClass(int documentId, string retentionClass);

        string GetDocumentRetentionClass(string fileName);

        string GetDocumentRetentionClass(int documentId);

        Document GetDocumentInfo(int documentId);

        Document GetDocumentInfo(string fileName);

        bool DocumentExists(int documentId);
    }
}