namespace Fnz.Framework.DocumentRepository.Api
{
    /// <summary>
    /// Indicates where a document's data can be stored: the filestore, the database, or to leave the decision to the
    /// document repository
    /// </summary>
    public enum DocumentStoreType
    {
        Filestore,
        Database,
        Default
    }
}