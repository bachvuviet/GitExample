﻿using System;

namespace Fnz.Framework.DocumentRepository.Api
{
    /// <summary>
    /// For getting the next document name available when saving potentially duplicate documents
    /// Is currently used by the FTP classes when accepting files; if duplicate file comes in the new one is given a new name.
    /// If this is going to be the case we should look at using the displayName for the input and usage; but create unique names on input that aren't based on what's passed through.
    /// [Obsolete("Used to temporiraly work around FTP implementation - avoid usage; displayFileName fills this gap.")]
    /// </summary>
    //// [Obsolete("Used to temporiraly work around FTP implementation - avoid usage; displayFileName fills this gap.")] 
    public interface INextDocumentNameRepository
    {
        int GetNextDocumentNameSuffixForDuplicateDocument(String fileName, String extension);
    }
}
