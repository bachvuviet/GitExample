﻿namespace Fnz.Framework.DocumentRepository.Api
{
    /// <summary>
    /// API for performing privileged operations on documents (it has  a seperate interface from IDocumentRepository so that we can reduce the chance that devs call this when they shouldn't)
    /// </summary>
    public interface IDocumentRepositoryPrivileged
    {
        /// <summary>
        /// Delete the document and its metadata
        /// </summary>
        void PrivilegedDelete(long documentId);        
        
        /// <summary>
        /// Delete the document and its metadata
        /// </summary>
        void PrivilegedDelete(string fileName);
    }
}