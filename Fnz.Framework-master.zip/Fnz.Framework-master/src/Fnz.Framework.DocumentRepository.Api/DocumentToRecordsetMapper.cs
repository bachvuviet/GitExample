using Fnz.Framework.DataAccess.RecordsetMapping;
using Fnz.Framework.DataAccess.RecordsetMapping.Data.ChangeTracking;

namespace Fnz.Framework.DocumentRepository.Api
{
    public class DocumentToRecordsetMapper : RecordsetMapper<Document>
    {
        public DocumentToRecordsetMapper()
            : base(new ActivatorFactory())
        {
            Maps(t => t.Id).To("DocId");
            Maps(t => t.Filename).To("FileName");
            Maps(t => t.DateTimeAdded).To("DateTimeAdded");
            Maps(t => t.LegacyFilestoreId).To("FileStoreID");
        }   
    }
}