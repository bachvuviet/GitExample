﻿using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Dispatcher;
using Fnz.Framework.Filestore.Util;

// The same LocalDataStoreSlot object can be used across all threads.

namespace Fnz.Framework.Filestore.Contract
{
    public class WriteDocumentHeader : IClientMessageInspector
    {
        public object BeforeSendRequest(ref Message request, IClientChannel channel)
        {
            string documentUrl = DocumentContext.GetDocumentUrl();
            MessageHeader myHeader = MessageHeader.CreateHeader("DocumentUrl", "FilestoreService", documentUrl);
            request.Headers.Add(myHeader);

            return null;
        }

        public void AfterReceiveReply(ref Message reply, object correlationState)
        {
        }
    }
}
