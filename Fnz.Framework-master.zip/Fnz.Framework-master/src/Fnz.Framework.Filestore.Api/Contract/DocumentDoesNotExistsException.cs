﻿namespace Fnz.Framework.Filestore.Contract
{
    public class DocumentDoesNotExistsException : FilestoreException
    {
        public DocumentDoesNotExistsException(string message) : base(message)
        {
        }
    }
}
