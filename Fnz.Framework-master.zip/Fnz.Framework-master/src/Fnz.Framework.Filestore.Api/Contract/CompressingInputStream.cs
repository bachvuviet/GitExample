﻿using System;
using System.IO;
using ICSharpCode.SharpZipLib.Zip;

namespace Fnz.Framework.Filestore.Contract
{
    public class CompressingInputStream : Stream
    {
        private readonly Stream _in;
        private readonly byte[] _tempBuffer = new byte[8192];
        private readonly MemoryStream _bufferStream;
        private readonly ZipOutputStream _zipOutputStream;

        private bool _endOfStream;
        private int _bufferSize;
        private long _bufferPosition;
        private int _totalBytesUncompressed;
        private int _totalBytesCompressed;

        public CompressingInputStream(Stream inputStream)
        {
            if (!inputStream.CanRead)
            {
                throw new IOException("Can only compress input streams");
            }

            _in = inputStream;
            _bufferStream = new NonSeekableStream(16384);
            _zipOutputStream = new ZipOutputStream(_bufferStream);

            var entry = new ZipEntry("content") { DateTime = DateTime.Now };

            _zipOutputStream.PutNextEntry(entry);
        }

        public override bool CanRead
        {
            get { return true; }
        }

        public override bool CanSeek
        {
            get { return false; }
        }

        public override bool CanWrite
        {
            get { return false; }
        }

        public override long Length
        {
            get { throw new NotSupportedException(); }
        }

        //public long CompressedPosition
        //{
        //    get { return _totalBytesCompressed; }
        //}

        public override long Position
        {
            get { return _totalBytesUncompressed; }
            set { throw new NotSupportedException(); }
        }

        public override void Flush()
        {
            throw new NotSupportedException();
        }

        public override long Seek(long offset, SeekOrigin origin)
        {
            throw new NotSupportedException();
        }

        public override void SetLength(long value)
        {
            throw new NotSupportedException();
        }

        public override int Read(byte[] buffer, int offset, int count)
        {
            if (count == 0)
            {
                throw new IOException("invalid count 0");
            }

            var bytesCopied = CopyBytesFromBuffer(buffer, offset, count);

            while (bytesCopied < count && !_endOfStream)
            {
                while (_bufferStream.Position == 0)
                {
                    var bytesRead = _in.Read(_tempBuffer, 0, _tempBuffer.Length);

                    if (bytesRead > 0)
                    {
                        _zipOutputStream.Write(_tempBuffer, 0, bytesRead);
                        _totalBytesUncompressed += bytesRead;
                    }
                    else
                    {
                        _zipOutputStream.Finish();
                        _endOfStream = true;
                    }
                }

                _bufferPosition = 0;
                _bufferSize = (int)_bufferStream.Position;

                bytesCopied += CopyBytesFromBuffer(buffer, offset + bytesCopied, count - bytesCopied);
            }

            if (_endOfStream)
            {
            }

            _totalBytesCompressed += bytesCopied;
            return bytesCopied;
        }

        private int CopyBytesFromBuffer(byte[] buffer, int offset, int count)
        {
            if (_bufferSize == 0)
            {
                return 0;
            }

            int bytesCopied;
            var compressedBuffer = _bufferStream.GetBuffer();

            if (_bufferSize >= count)
            {
                Array.Copy(compressedBuffer, _bufferPosition, buffer, offset, count);
                _bufferPosition += count;
                _bufferSize -= count;
                bytesCopied = count;
            }
            else
            {
                Array.Copy(compressedBuffer, _bufferPosition, buffer, offset, _bufferSize);
                bytesCopied = _bufferSize;
                _bufferPosition = 0;
                _bufferSize = 0;
                _bufferStream.Position = 0;
            }

            return bytesCopied;
        }

        public override void Write(byte[] buffer, int offset, int count)
        {
            throw new NotSupportedException();
        }

        public override void Close()
        {
            base.Close();
            _in.Close();
            _zipOutputStream.Close();
        }
    }
}
