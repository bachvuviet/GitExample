﻿namespace Fnz.Framework.Filestore.Contract
{
    public class FilestoreLocationNotFoundException : FilestoreException
    {
        public FilestoreLocationNotFoundException(string message) : base(message)
        {
        }
    }
}
