﻿namespace Fnz.Framework.Filestore.Contract
{
    public class DocumentAlreadyExistsException : FilestoreException
    {
        public DocumentAlreadyExistsException(string message) : base(message)
        {
        }
    }
}
