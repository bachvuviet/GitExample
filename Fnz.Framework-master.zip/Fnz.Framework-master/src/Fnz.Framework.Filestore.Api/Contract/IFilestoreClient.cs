using System.IO;

namespace Fnz.Framework.Filestore.Contract
{
    public interface IFilestoreClient
    {
        /// <summary>
        /// Saves content to the filestore using the provide document url - uncompressed
        /// </summary>
        /// <param name="documentUrl">identity of the document</param>
        /// <param name="contentStream">The content to save</param>
        /// <returns>The number of bytes saved</returns>
        long SaveContent(string documentUrl, Stream contentStream);

        /// <summary>
        /// Saves content to the filestore using the provide document url - uncompressed
        /// </summary>
        /// <param name="documentUrl">identity of the document</param>
        /// <param name="contentStream">The content to save</param>
        /// <param name="compress">True if content is to be compressed</param>
        /// <returns>The number of bytes saved</returns>
        long SaveContent(string documentUrl, Stream contentStream, bool compress);

        /// <summary>
        /// Gets the content for the provide document url from the filestore - uncompressed only
        /// </summary>
        /// <param name="documentUrl">identity of document</param>
        /// <returns>Content as stream</returns>
        Stream GetContent(string documentUrl);

        /// <summary>
        /// Gets the content for the provide document url from the filestore
        /// </summary>
        /// <param name="documentUrl">identity of document</param>
        /// <param name="isCompressed">True if document is compressed</param>
        /// <returns>Content as stream</returns>
        Stream GetContent(string documentUrl, bool isCompressed);

        /// <summary>
        /// Requests the status of the filestore
        /// </summary>
        /// <returns>The state of the filestore </returns>
        string Ping();

        /// <summary>
        /// Closes connection to filestore service
        /// </summary>
        void Close();
    }
}