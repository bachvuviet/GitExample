﻿using System;

namespace Fnz.Framework.Filestore.Contract
{
    public class FilestoreException : Exception
    {
        public FilestoreException(string message)
            : base(message)
        {
        }
    }
}
