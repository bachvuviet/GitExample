﻿namespace Fnz.Framework.Filestore.Contract
{
    public class InvalidDocumentIdException : FilestoreException
    {
        public InvalidDocumentIdException(string message) : base(message)
        {
        }
    }
}
