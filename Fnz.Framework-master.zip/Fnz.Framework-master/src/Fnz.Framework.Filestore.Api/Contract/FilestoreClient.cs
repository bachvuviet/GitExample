﻿using System;
using System.IO;
using System.ServiceModel;
using Fnz.Framework.Components.Config;
using Fnz.Framework.Filestore.Util;

namespace Fnz.Framework.Filestore.Contract
{
    public class FilestoreClient : IFilestoreClient
    {
        private readonly ISystemVariablesReader _systemVariablesReader;
        private FilestoreServiceProxy _filestoreService;

        public FilestoreClient(ISystemVariablesReader systemVariablesReader)
        {
            _systemVariablesReader = systemVariablesReader;

            // TODO: [CG] - remove the need to call InitialiseFilestoreServiceProxy here because we do not want to
            // read data from the database (vai SystemVariablesReader) during the construction because it 
            // means when we use the Castle Container (as we do in some tests) we need to wrap it in a 'new DalScope()'
            InitialiseFilestoreServiceProxy();
        }

        public FilestoreClient(ISystemVariablesReader systemVariablesReader, string endpointAddressUri)
        {
            _systemVariablesReader = systemVariablesReader;

            var b = new BasicHttpBinding { TransferMode = TransferMode.Streamed, MaxReceivedMessageSize = 1000000000 };

            if (endpointAddressUri.StartsWith("https", true, null))
            {
                b.Security.Mode = BasicHttpSecurityMode.Transport;
            }

            var endpointAddress = new EndpointAddress(endpointAddressUri);
            _filestoreService = new FilestoreServiceProxy(b, endpointAddress);
        }

        public bool IsFilestoreServiceProxyInitialised()
        {
            return _filestoreService != null;
        }

        private void InitialiseFilestoreServiceProxy()
        {
            if (IsFilestoreEnabled() && _filestoreService == null)
            {
                _filestoreService = new FilestoreServiceProxy("BasicHttpBinding_IFilestoreService");
            }            
        }

        private FilestoreServiceProxy GetFilestoreServiceProxy()
        {
            InitialiseFilestoreServiceProxy();

            if (_filestoreService == null)
            {
                throw new Exception("Failed to initialise the filestore service proxy - the SystemVariable setting '" +
                      SystemVariables.Filestore.Name + ":" + SystemVariables.Filestore.Name + "' must have the value 'true'");    
            }

            return _filestoreService;
        }

        public long SaveContent(string documentUrl, Stream contentStream)
        {
            return SaveContent(documentUrl, contentStream, false);
        }

        public long SaveContent(string documentUrl, Stream contentStream, bool compress)
        {
            try
            {
                var filestoreService = GetFilestoreServiceProxy();

                DocumentContext.SetDocumentUrl(documentUrl);
                var stream = compress ? new CompressingInputStream(contentStream) : contentStream;
                filestoreService.SaveContent(stream);

                return stream.Position;
            }
            catch (FaultException fe)
            {
                ThrowAsFilestoreException(fe);
                throw;
            }
        }

        public Stream GetContent(string documentUrl)
        {
            return GetContent(documentUrl, false);
        }

        public Stream GetContent(string documentUrl, bool isCompressed)
        {
            try
            {
                var filestoreService = GetFilestoreServiceProxy();

                DocumentContext.SetDocumentUrl(documentUrl);
                var contentStream = filestoreService.GetContent();
                var returnStream = isCompressed ? new UncompressingInputStream(contentStream) : contentStream;
                return returnStream;
            }
            catch (FaultException fe)
            {
                ThrowAsFilestoreException(fe);
                throw;
            }
        }

        public string Ping()
        {
            var filestoreService = GetFilestoreServiceProxy();
            return filestoreService.Ping();
        }

        public void Close()
        {
            if (_filestoreService != null)
            {
                _filestoreService.Close();
                _filestoreService = null;
            }            
        }

        /// <summary>
        /// Throws as Filestore exception if know fault
        /// </summary>
        private void ThrowAsFilestoreException(FaultException e)
        {
            string faultExceptionCode = e.Code.Name;

            if (faultExceptionCode.Equals("DocumentDoesNotExistsException"))
            {
                throw new DocumentDoesNotExistsException(e.Message);
            }
            else if (faultExceptionCode.Equals("DocumentAlreadyExistsException"))
            {
                throw new DocumentAlreadyExistsException(e.Message);
            }
            else if (faultExceptionCode.Equals("InvalidDocumentIdException"))
            {
                throw new InvalidDocumentIdException(e.Message);
            }
            else if (faultExceptionCode.Equals("FilestoreLocationNotFoundException"))
            {
                throw new FilestoreLocationNotFoundException(e.Message);
            }
        }

        private bool IsFilestoreEnabled()
        {
            return GetSystemVariableFlag(SystemVariables.Filestore.Switch);
        }

        private bool GetSystemVariableFlag(string flagName)
        {
            return _systemVariablesReader.GetValue<bool>(SystemVariables.Filestore.Name, flagName);
        }
    }
}
