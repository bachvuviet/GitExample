﻿using System.IO;

namespace Fnz.Framework.Filestore.Contract
{
    public class NonSeekableStream : MemoryStream
    {
        public NonSeekableStream(int capacity)
                : base(capacity)
        {
        }

        public override bool CanSeek
        {
            get { return false; }
        }
    }
}