﻿namespace Fnz.Framework.Archiving.Api.Entities
{
    public class ArchiveProcess
    {
        public string ProcessName { get; set; }

        public int DaysOfDataToKeep { get; set; }

        public int RowsPerFile { get; set; }

        public int ArchivingOrder { get; set; }

        public int Enabled { get; set; }
    }
}
