﻿using System;

namespace Fnz.Framework.Archiving.Api.Entities
{
    public class MigrationProcess
    {
        public string ProcessName { get; set; }

        public int RowsPerFile { get; set; }

        public int ArchivingOrder { get; set; }

        public int Enabled { get; set; }

        public DateTime NextArchiveDate { get; set; }

        public DateTime FinalArchiveDate { get; set; }
    }
}
