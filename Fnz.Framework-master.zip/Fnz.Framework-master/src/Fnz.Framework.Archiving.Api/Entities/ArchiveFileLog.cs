﻿using System;

namespace Fnz.Framework.Archiving.Api.Entities
{
    public class ArchiveFileLog
    {
        public int AuditLogId { get; set; }

        public string FileName { get; set; }

        public int MinId { get; set; }

        public int MaxId { get; set; }

        public int RowsArchived { get; set; }

        public DateTime DateTimeArchived { get; set; }
    }
}
