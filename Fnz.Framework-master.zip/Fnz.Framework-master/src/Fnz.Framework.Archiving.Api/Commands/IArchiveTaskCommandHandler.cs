﻿using Fnz.Core.Platform.Framework.Commands;

namespace Fnz.Framework.Archiving.Api.Commands
{
    public interface IArchiveTaskCommandHandler : ICommandHandler<ArchiveTaskCommand>
    {
    }
}
