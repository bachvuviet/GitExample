﻿using System;

namespace Fnz.Framework.Archiving.Api.Commands
{
    public class ArchiveProcessCommand
    {
        public string ProcessName { get; set; }

        public int RowsPerFile { get; set; }

        public DateTime FromDate { get; set; }

        public DateTime ToDate { get; set; }
    }
}
