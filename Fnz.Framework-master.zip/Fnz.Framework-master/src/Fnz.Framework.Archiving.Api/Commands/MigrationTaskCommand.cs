﻿namespace Fnz.Framework.Archiving.Api.Commands
{
    public class MigrationTaskCommand
    {
    }
}
