﻿using System;

namespace Fnz.Framework.Archiving.Api.Commands
{
    public class ArchiveTaskCommand
    {
        public DateTime? AsAt { get; set; }
    }
}
