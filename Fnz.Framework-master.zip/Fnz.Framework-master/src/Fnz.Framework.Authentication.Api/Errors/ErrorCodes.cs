﻿using Fnz.Api.Errors;

namespace Fnz.Framework.Authentication.Api.Errors
{
    public static class ErrorCodes
    {
        // General
        public static readonly ErrorCode UnauthorizedAccess = new ErrorCode(1, "Unauthorized Access");

        // Users
        public static readonly ErrorCode UserNotFound = new ErrorCode(50, "User not found");

        // SAML
        public static readonly ErrorCode InvalidSamlMessage = new ErrorCode(100, "The SAML message could be not interpreted");

        public static readonly ErrorCode SamlSignatureNotVerified = new ErrorCode(101, "The SAML message signature could not be verified");

        public static readonly ErrorCode SamlConfigurationNotFound = new ErrorCode(102, "The SAML message signature could not be verified");

        public static readonly ErrorCode SamlDestinationNotValid = new ErrorCode(103, "The Destination specified in the SAML token is not valid");

        public static readonly ErrorCode SamlReplayAttack = new ErrorCode(104, "This SAML message ID has already been used, possible replay attack detected");

        public static readonly ErrorCode SamlTimeConditionsNotSatisfied = new ErrorCode(105, "The SAML assertion is outside the valid time period.");
    }
}