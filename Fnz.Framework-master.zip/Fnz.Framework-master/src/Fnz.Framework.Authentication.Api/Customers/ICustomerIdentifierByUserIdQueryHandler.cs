﻿using Fnz.Core.Platform.Framework;

namespace Fnz.Framework.Authentication.Api.Customers
{
    public interface ICustomerIdentifierByUserIdQueryHandler : IQueryHandler<CustomerIdentifierByUserQuery, CustomerIdentifier>
    {
    }
}