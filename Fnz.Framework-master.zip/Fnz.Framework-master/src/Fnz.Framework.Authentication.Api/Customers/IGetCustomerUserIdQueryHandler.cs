﻿using Fnz.Core.Platform.Framework;

namespace Fnz.Framework.Authentication.Api.Customers
{
    public interface IGetCustomerUserIdQueryHandler : IQueryHandler<GetCustomerUserIdQuery, int?>
    {
    }
}