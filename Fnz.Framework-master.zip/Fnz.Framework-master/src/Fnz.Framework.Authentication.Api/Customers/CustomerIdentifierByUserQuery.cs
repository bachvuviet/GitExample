﻿namespace Fnz.Framework.Authentication.Api.Customers
{
    public class CustomerIdentifierByUserQuery
    {
        public int UserId { get; set; }
    }
}