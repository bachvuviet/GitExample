﻿namespace Fnz.Framework.Authentication.Api.Customers
{
    public class CustomerIdentifier
    {
        public int Id { get; set; }

        public string ExternalCustomerId { get; set; } 
    }
}