﻿namespace Fnz.Framework.Authentication.Api.Customers
{
    public class GetCustomerUserIdQuery
    {
        public string ExternalIdentifier { get; set; }
    }
}