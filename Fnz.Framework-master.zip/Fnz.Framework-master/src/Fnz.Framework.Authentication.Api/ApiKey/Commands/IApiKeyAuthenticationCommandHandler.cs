﻿using Fnz.Core.Platform.Framework.Commands;

namespace Fnz.Framework.Authentication.Api.ApiKey.Commands
{
    public interface IApiKeyAuthenticationCommandHandler : ICommandHandler<ApiKeyAuthenticationCommand>
    {
    }
}
