﻿namespace Fnz.Framework.Authentication.Api.ApiKey.Commands
{
    public class ApiKeyAuthenticationCommand
    {
        public string ApiKey { get; set; }
    }
}
