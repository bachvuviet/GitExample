﻿namespace Fnz.Framework.Authentication.Api.Saml.Commands
{
    public sealed class SamlCustomAttribute
    {
        public string Name { get; set; }

        public string Value { get; set; }
    }
}