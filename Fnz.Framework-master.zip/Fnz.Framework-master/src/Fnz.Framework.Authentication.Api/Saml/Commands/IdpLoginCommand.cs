﻿using System.Collections.Generic;
using Fnz.Framework.Authentication.Api.Sessions;

namespace Fnz.Framework.Authentication.Api.Saml.Commands
{
    public class IdpLoginCommand
    {
        public string ApplicationName { get; set; }

        public string NameId { get; set; }

        public UserIdentifierType UserIdentifierType { get; set; }

        public List<SamlCustomAttribute> Attributes { get; set; }
    }
}