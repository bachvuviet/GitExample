﻿using System;
using System.Xml;

namespace Fnz.Framework.Authentication.Api.Saml.Commands
{
    public class ProcessSamlLogoutRequestCommand
    {
        public string SamlConfigurationKey { get; set; }

        public XmlElement Request { get; set; }

        public Guid? SessionToken { get; set; }

        public string ApplicationName { get; set; }
    }
}