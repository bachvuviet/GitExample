﻿using System.Xml;

namespace Fnz.Framework.Authentication.Api.Saml.Commands
{
    public class SamlLogoutResponse
    {
        public SamlLogoutResponse()
        {
        }

        public SamlLogoutResponse(XmlElement request)
        {
            this.Xml = request;
        }

        public XmlElement Xml { get; set; }
    }
}