using Fnz.Core.Platform.Framework.Commands;

namespace Fnz.Framework.Authentication.Api.Saml.Commands
{
    public interface IGenerateSamlLogoutRequestCommandHandler : ICommandHandler<SamlGenerateLogoutRequestCommand, SamlLogoutRequest>
    {
    }
}