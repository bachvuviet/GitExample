﻿using System;

namespace Fnz.Framework.Authentication.Api.Saml.Commands
{
    public class ProcessSamlRedirectBindingLogoutRequestCommand
    {
        public string SamlConfigurationKey { get; set; }

        public string Url { get; set; }

        public Guid? SessionToken { get; set; }

        public string ApplicationName { get; set; }
    }
}