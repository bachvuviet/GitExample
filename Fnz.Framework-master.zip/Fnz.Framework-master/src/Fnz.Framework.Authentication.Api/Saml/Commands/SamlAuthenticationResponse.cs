﻿using System.Collections.Generic;
using Fnz.Framework.Authentication.Api.Sessions;

namespace Fnz.Framework.Authentication.Api.Saml.Commands
{
    public class SamlAuthenticationResponse
    {
        public AuthenticationToken Token { get; set; }

        public List<SamlCustomAttribute> CustomAttributes { get; set; }
    }
}