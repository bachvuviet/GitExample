using Fnz.Core.Platform.Framework.Commands;

namespace Fnz.Framework.Authentication.Api.Saml.Commands
{
    public interface IGenerateSamlRedirectBindingLogoutRequestCommandHandler : ICommandHandler<SamlGenerateLogoutRequestCommand, SamlRedirectBindingMessage>
    {
    }
}