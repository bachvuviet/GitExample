using System.Xml;

namespace Fnz.Framework.Authentication.Api.Saml.Commands
{
    public class ProcessSamlAuthenticationResponseCommand
    {
        public string SamlConfigurationKey { get; set; }

        public XmlElement Assertion { get; set; }

        public string ApplicationName { get; set; }
    }
}