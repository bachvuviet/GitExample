﻿using Fnz.Core.Platform.Framework.Commands;

namespace Fnz.Framework.Authentication.Api.Saml.Commands
{
    public interface IProcessSamlLogoutRequestCommandHandler : ICommandHandler<ProcessSamlLogoutRequestCommand, SamlLogoutResponse>
    {
    }
}