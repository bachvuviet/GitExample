using System.Xml;

namespace Fnz.Framework.Authentication.Api.Saml.Commands
{
    public class SamlLogoutRequest
    {
        public SamlLogoutRequest()
        {
        }

        public SamlLogoutRequest(XmlElement request)
        {
            this.Xml = request;
        }

        public XmlElement Xml { get; set; }        
    }
}