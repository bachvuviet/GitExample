namespace Fnz.Framework.Authentication.Api.Saml.Commands
{
    public class SamlGenerateLogoutRequestCommand
    {
        public SamlGenerateLogoutRequestCommand()
        {
        }

        public SamlGenerateLogoutRequestCommand(string samlConfigurationKey, int userId)
        {
            this.SamlConfigurationKey = samlConfigurationKey;
            this.UserId = userId;
        }

        public string SamlConfigurationKey { get; set; }

        public int UserId { get; set; }
    }
}