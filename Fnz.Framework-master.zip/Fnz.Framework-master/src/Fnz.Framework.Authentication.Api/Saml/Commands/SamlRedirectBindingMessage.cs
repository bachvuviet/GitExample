namespace Fnz.Framework.Authentication.Api.Saml.Commands
{
    public class SamlRedirectBindingMessage
    {
        public string Url { get; set; }
    }
}