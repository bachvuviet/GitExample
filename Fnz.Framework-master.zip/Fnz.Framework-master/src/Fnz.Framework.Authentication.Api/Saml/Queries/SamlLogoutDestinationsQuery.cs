﻿namespace Fnz.Framework.Authentication.Api.Saml.Api.Queries
{
    public class SamlLogoutDestinationsQuery
    {
        public SamlLogoutDestinationsQuery()
        {
        }

        public SamlLogoutDestinationsQuery(string samlConfigurationKey)
        {
            this.SamlConfigurationKey = samlConfigurationKey;
        }

        public string SamlConfigurationKey { get; set; }
    }
}