﻿using Fnz.Core.Platform.Framework;
using Fnz.Framework.Authentication.Api.Saml.Api.Queries;

namespace Fnz.Framework.Authentication.Api.Saml.Queries
{
    public interface ISamlLogoutDestinationsQueryHandler : IQueryHandler<SamlLogoutDestinationsQuery, SamlLogoutDestinations>
    {
    }
}