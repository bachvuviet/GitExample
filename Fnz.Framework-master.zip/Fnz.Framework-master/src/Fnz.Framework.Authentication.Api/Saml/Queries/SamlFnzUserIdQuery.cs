using Fnz.Framework.Authentication.Api.Sessions;

namespace Fnz.Framework.Authentication.Api.Saml.Queries
{
    public class SamlFnzUserIdQuery
    {
        public string ExternalIdentifier { get; set; }

        public UserIdentifierType UserIdentifierType { get; set; }
    }
}