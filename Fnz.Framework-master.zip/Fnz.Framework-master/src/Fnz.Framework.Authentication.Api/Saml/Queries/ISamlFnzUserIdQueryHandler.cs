﻿using Fnz.Core.Platform.Framework;

namespace Fnz.Framework.Authentication.Api.Saml.Queries
{
    public interface ISamlFnzUserIdQueryHandler : IQueryHandler<SamlFnzUserIdQuery, int>
    {
    }
}