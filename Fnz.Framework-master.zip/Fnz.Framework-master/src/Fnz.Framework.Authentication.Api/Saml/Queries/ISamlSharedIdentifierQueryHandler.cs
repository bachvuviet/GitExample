﻿using Fnz.Core.Platform.Framework;

namespace Fnz.Framework.Authentication.Api.Saml.Queries
{
    public interface ISamlSharedIdentifierQueryHandler : IQueryHandler<SamlSharedIdentifierQuery, string>
    {         
    }
}