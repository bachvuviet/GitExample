﻿using Fnz.Framework.Authentication.Api.Sessions;

namespace Fnz.Framework.Authentication.Api.Saml.Queries
{
    public class SamlSharedIdentifierQuery
    {
        public UserIdentifierType UserIdentifierType { get; set; }

        /// <summary>
        /// This is the FNZ user ID
        /// </summary>
        public int UserId { get; set; }
    }
}