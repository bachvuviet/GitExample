﻿namespace Fnz.Framework.Authentication.Api.Saml.Api.Queries
{
    public class SamlLogoutDestinations
    {
        /// <summary>
        /// The endpoint to send logout requests to
        /// </summary>
        public string LogoutRequestDestination { get; set; }

        /// <summary>
        /// The endpoint to send logout responses to
        /// </summary>
        public string LogoutResponseDestination { get; set; }         
    }
}