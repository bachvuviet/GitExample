﻿namespace Fnz.Framework.Authentication.Api.Users
{
    public class UserIdentifier
    {
        public int Id { get; set; }

        public string ExternalUserId { get; set; }
    }
}