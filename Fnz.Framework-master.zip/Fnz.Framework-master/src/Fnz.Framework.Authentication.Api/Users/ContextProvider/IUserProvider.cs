﻿namespace Fnz.Framework.Authentication.Api.Users.ContextProvider
{
    public interface IUserProvider
    {
        int UserId { get; }

        string UserName { get; }
    }
}