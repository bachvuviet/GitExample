﻿using Fnz.Core.Platform.Framework;
using Fnz.Framework.Cca.Security;

namespace Fnz.Framework.Authentication.Api.Users.ContextProvider
{
    /// <summary>
    /// Get the <see cref="IUserContext"/> object for given userId
    /// </summary>
    public interface IGetUserContext : IQueryHandler<UserContextQuery, IUserContext>
    {
    }
}