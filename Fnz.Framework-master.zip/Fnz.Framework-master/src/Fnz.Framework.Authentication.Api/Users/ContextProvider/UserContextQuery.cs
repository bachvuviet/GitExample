﻿namespace Fnz.Framework.Authentication.Api.Users.ContextProvider
{
    public class UserContextQuery
    {
        public int UserId { get; set; }
    }
}