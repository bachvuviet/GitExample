﻿using Fnz.Framework.Cca.Security;

namespace Fnz.Framework.Authentication.Api.Users.ContextProvider
{
    //TODO: Rename to IGetCurrentUserContext

    /// <summary>
    /// Uses Current Thread Principal to get user context associated with current web request.
    /// </summary>
    public interface IUserContextProvider
    {
        IUserContext GetUserContext();
    }
}