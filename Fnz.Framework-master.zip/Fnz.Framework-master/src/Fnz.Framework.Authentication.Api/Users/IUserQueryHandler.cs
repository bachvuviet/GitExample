﻿using Fnz.Core.Platform.Framework;

namespace Fnz.Framework.Authentication.Api.Users
{
    /// <summary>
    /// Provides operation for obtaining <see cref="UserIdentifier"/> for a user without performing permission validation
    /// </summary>
    public interface IUserQueryHandler : IQueryHandler<UserQuery, UserIdentifier>
    {
    }
}