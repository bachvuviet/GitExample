namespace Fnz.Framework.Authentication.Api.Users
{
    public class UserQuery
    {
        public int RequestedUserId { get; set; }

        public string ExternalUserId { get; set; }

        public string UserName { get; set; }

        public string Email { get; set; }

        public string ApplicationName { get; set; }
        
        public bool SearchByEmail
        {
            get
            {
                return !string.IsNullOrEmpty(Email);
            }
        }

        public bool SearchByUserId
        {
            get
            {
                return this.RequestedUserId > 0;
            }
        }

        public bool SearchByUserName
        {
            get
            {
                return !string.IsNullOrEmpty(this.UserName);
            }
        }
    }
}