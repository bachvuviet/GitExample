﻿using System;

namespace Fnz.Framework.Authentication.Api.Users
{
    public class UserContextAuthorizationCommand
    {
        public static readonly UserContextAuthorizationCommand Invalid = new UserContextAuthorizationCommand { UserId = -1, UserName = null, ExternalCustomerId = null, ExternalUserId = null };

        public int UserId { get; set; }

        public string UserName { get; set; }

        public string ExternalUserId { get; set; }

        public string ExternalCustomerId { get; set; }

        public string EmailAddress { get; set; }
        
        public string ApplicationName { get; set; }

        public bool HasUserId
        {
            get
            {
                return this.UserId > 0;
            }
        }

        public bool HasUserName
        {
            get
            {
                return this.UserName.IsNotNullOrEmpty();
            }
        }

        public bool HasExternalUserId
        {
            get
            {
                return this.ExternalUserId.IsNotNullOrEmpty();
            }
        }

        public bool HasExternalCustomerId
        {
            get
            {
                return this.ExternalCustomerId.IsNotNullOrEmpty();
            }
        }

        public bool HasEmailAddress
        {
            get
            {
                return this.EmailAddress.IsNotNullOrEmpty();
            }
        }

        public bool HasExactlyOneIdentifier()
        {
            int c = 0;

            if (UserName.IsNotNullOrEmpty())
            {
                c++;
            }

            if (UserId > 0)
            {
                c++;
            }

            if (ExternalUserId.IsNotNullOrEmpty())
            {
                c++;
            }

            if (ExternalCustomerId.IsNotNullOrEmpty())
            {
                c++;
            }

            if (EmailAddress.IsNotNullOrEmpty())
            {
                c++;
            }

            return c == 1;
        }
    }
}