﻿using Fnz.Core.Platform.Framework.Commands;

namespace Fnz.Framework.Authentication.Api.Users
{
    public interface IUserContextAuthorizationCommandHandler : ICommandHandler<UserContextAuthorizationCommand, int>
    {
    }
}