﻿namespace Fnz.Framework.Authentication.Api.Sessions
{
    public class SingleSignOnSession
    {
        public System.Guid Token { get; set; }

        public int DefaultTimeout { get; set; }

        public bool FirstTimeLogin { get; set; }

        public int UserId { get; set; }
    }
}