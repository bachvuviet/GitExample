﻿namespace Fnz.Framework.Authentication.Api.Sessions
{
    public class SessionRefreshStatus
    {
        public int UserId { get; set; }
    }
}