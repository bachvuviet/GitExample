﻿using System;

namespace Fnz.Framework.Authentication.Api.Sessions
{
    public class AuthenticationToken
    {
        public Guid Token { get; set; }

        public int DefaultTimeout { get; set; }

        public int UserId { get; set; }

        public bool FirstTimeLogin { get; set; }

        public bool PasswordUpdateRequired { get; set; }

        public bool MemorableWordUpdateRequired { get; set; }

        public bool FullAuthenticationRequired { get; set; }
    }
}