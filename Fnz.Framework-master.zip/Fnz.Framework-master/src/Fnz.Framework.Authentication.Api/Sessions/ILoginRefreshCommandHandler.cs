﻿using Fnz.Core.Platform.Framework.Commands;

namespace Fnz.Framework.Authentication.Api.Sessions
{
    public interface ILoginRefreshCommandHandler : ICommandHandler<LoginRefreshCommand, SessionRefreshStatus>
    {
    }
}