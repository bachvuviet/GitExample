﻿namespace Fnz.Framework.Authentication.Api.Sessions
{
    public interface IUserTokenReader
    {
        UserToken Get(int userId, int propositionId);
    }
}