﻿namespace Fnz.Framework.Authentication.Api.Sessions
{
    public enum UserIdentifierType
    {
        UserId,
        ExternalUserId,
        ExternalCustomerId,
        SessionKey
    }
}