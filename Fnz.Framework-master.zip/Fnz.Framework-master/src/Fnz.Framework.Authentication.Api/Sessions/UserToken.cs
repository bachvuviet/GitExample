﻿using System;

namespace Fnz.Framework.Authentication.Api.Sessions
{
    public class UserToken
    {
        public int UserId { get; set; }

        public int PropositionId { get; set; }

        public Guid Token { get; set; }

        public DateTime StartDate { get; set; }
    }
}