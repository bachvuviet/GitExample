﻿using System;
using Fnz.Core.Platform.Framework.Commands;

namespace Fnz.Framework.Authentication.Api.Sessions
{
    public interface ILogoutCommandHandler : ICommandHandler<Guid?>
    {
    }
}