using System;

namespace Fnz.Framework.Authentication.Api.Sessions
{
    public class LoginRefreshCommand
    {
        public Guid? Token { get; set; }
        
        public string ApplicationName { get; set; }
    }
}