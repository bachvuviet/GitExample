﻿using System.Reflection;
using Castle.MicroKernel.Registration;
using Castle.MicroKernel.Resolvers.SpecializedResolvers;
using Castle.MicroKernel.SubSystems.Configuration;
using Castle.Windsor;
using Fnz.Framework.Archiving.DataAccess.Readers;
using Fnz.Framework.Archiving.Utilities;
using Fnz.Framework.Cca.Setup;
using Fnz.Framework.Components.Config.Mapping;

namespace Fnz.Framework.Archiving.Setup
{
    public class ArchivingInstaller : DefaultInstaller
    {
        public ArchivingInstaller()
            : base(Assembly.GetExecutingAssembly().FullName)
        {
        }

        public override void Install(IWindsorContainer container, IConfigurationStore store)
        {
            base.Install(container, store);

            container.Kernel.Resolver.AddSubResolver(new CollectionResolver(container.Kernel, true));

            container.Register(
                Component.For<ISupportedProcesses>()
                    .ImplementedBy<SupportedProcesses>()
                    .LifeStyle.Transient,
                Component.For<IMigrationsEmailer>()
                    .ImplementedBy<MigrationsEmailer>()
                    .LifeStyle.Transient,
                Component.For<IArchiveFileGenerator>()
                    .ImplementedBy<ArchiveFileGenerator>()
                    .LifeStyle.Transient,
                Component.For<IGetConfigurationProperties<EmailApplication>>()
                    .ImplementedBy<GetConfigurationProperties<EmailApplication>>()
                    .LifestyleTransient(),
                Component.For<IConfigurationPropertyMap<EmailApplication>>()
                    .ImplementedBy<EmailApplicationMap>()
                    .LifestyleTransient()
                );
        }
    }
}