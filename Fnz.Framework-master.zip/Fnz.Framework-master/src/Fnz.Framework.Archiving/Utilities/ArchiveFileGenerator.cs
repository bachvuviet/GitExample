﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Fnz.Framework.DataAccess;
using ICSharpCode.SharpZipLib.Core;
using ICSharpCode.SharpZipLib.Zip;

namespace Fnz.Framework.Archiving.Utilities
{
    public class ArchiveFileGenerator : IArchiveFileGenerator
    {
        private const int ZipCompressionLevel = 5;  // valid range: 0-9
        private const int ZipStreamBufferSize = 4096;

        public Stream GenerateArchiveZip(Recordset rs, string fileName)
        {
            return CreateZipMemoryStream(RecordsetToCsvStream(rs), fileName);
        }

        private MemoryStream RecordsetToCsvStream(Recordset rs)
        {
            var stream = new MemoryStream();
            var streamWriter = new StreamWriter(stream);

            rs.MoveFirst();

            foreach (var r in rs)
            {
                // var "r" is useless, ignore
                var row = new List<string>();

                foreach (var f in rs.Fields)
                {
                    // var "f" is useless, ignore
                    var fieldName = rs.Fields.CurrentItem().Name;
                    var fieldValue = rs.GetAsString(fieldName);
                    row.Add(String.Format("\"{0}\"", fieldValue));
                }

                streamWriter.WriteLine(String.Join(",", row.Select(col => col.ToString()).ToArray()));
            }

            streamWriter.Flush();
            stream.Position = 0;

            return stream;
        }

        private MemoryStream CreateZipMemoryStream(MemoryStream memStreamIn, string zipEntryName)
        {
            var outputMemStream = new MemoryStream();
            var zipStream = new ZipOutputStream(outputMemStream);

            zipStream.SetLevel(ZipCompressionLevel);

            var newEntry = new ZipEntry(zipEntryName) { DateTime = DateTime.Now };

            zipStream.PutNextEntry(newEntry);

            StreamUtils.Copy(memStreamIn, zipStream, new byte[ZipStreamBufferSize]);
            zipStream.CloseEntry();

            zipStream.IsStreamOwner = false;
            zipStream.Close();

            outputMemStream.Position = 0;
            return outputMemStream;
        }
    }
}
