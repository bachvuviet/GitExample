﻿using System.IO;
using Fnz.Framework.DataAccess;

namespace Fnz.Framework.Archiving.Utilities
{
    public interface IArchiveFileGenerator
    {
        Stream GenerateArchiveZip(Recordset rs, string fileName);
    }
}
