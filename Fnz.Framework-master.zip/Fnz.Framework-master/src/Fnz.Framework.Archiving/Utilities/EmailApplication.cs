﻿using Fnz.Framework.Components.Config.Mapping;

namespace Fnz.Framework.Archiving.Utilities
{
    public class EmailApplication
    {
        public string ClientSupportServices { get; set; }

        public string DefaultSenderAddress { get; set; }

        public string DefaultName { get; set; }
    }

    public class EmailApplicationMap : ConfigurationPropertyMap<EmailApplication>
    {
        public EmailApplicationMap()
        {
            Map(x => x.ClientSupportServices).FromSystemVariables("Email", "UKClientSupportServices@fnz.co.uk", "ClientSupportServices");

            Map(x => x.DefaultSenderAddress).FromSystemVariables("Email", "support@fnz.co.uk", "DefaultSenderAddress");

            Map(x => x.DefaultName).FromSystemVariables("Email", "First NZ Wrap (UK) Limited", "DefaultName");
        }
    }
}
