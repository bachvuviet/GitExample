﻿using System;
using System.Collections.Generic;
using System.Linq;
using Fnz.Framework.Components.Config.Mapping;
using Fnz.Framework.Components.Email;
using Fnz.Framework.Components.Environment;

namespace Fnz.Framework.Archiving.Utilities
{
    public class MigrationsEmailer : IMigrationsEmailer
    {
        private readonly IEmail _emailer;

        private readonly IEnvironmentInformationProvider _environment;

        private readonly IGetConfigurationProperties<EmailApplication> _configProvider;

        public MigrationsEmailer(IEmail emailer, IGetConfigurationProperties<EmailApplication> configProvider, IEnvironmentInformationProvider environment)
        {
            _emailer = emailer;

            _configProvider = configProvider;

            _environment = environment;
        }

        public void SendCompleteProcessNotification(IList<string> processes)
        {
            const string SubjectFormat = "Completed archive migration processes in {0}";

            const string BodyFormat =
                "The following migration processes have finished, " +
                "so we need to create a script to truncate (not delete!) the data in these tables:\n{0}";

            var subject = SubjectFormat.FormatWith(_environment.GetCurrentEnvironmentName());

            /* for the email body make a little list containing the process names on separate lines, eg:
              - XMLServicesLog
              - ErrorHandler
             */

            var body = BodyFormat.FormatWith(String.Join(String.Empty, processes.Select(x => String.Format("- {0}\n", x)).ToArray()));

            SendMigrationEmail(subject, body);
        }

        public void SendDisableTaskNotification()
        {
            const int TaskId = 152280;

            const string SubjectFormat = "Migration task {0} can be disabled in {1}";

            const string BodyFormat =
                "There are no more enabled processes in Platform.Archiving.Migrations.\n" +
                "Task {0} can now be disabled until a new archive migration process is created.";

            var subject = SubjectFormat.FormatWith(TaskId, _environment.GetCurrentEnvironmentName());
            var body = BodyFormat.FormatWith(TaskId);

            SendMigrationEmail(subject, body);
        }

        private void SendMigrationEmail(string subject, string body)
        {
            var emailConfig = _configProvider.Execute();

            var email = new EmailDetails(_emailer.EmailReader)
            {
                Subject = subject,
                Body = body,
                SenderAddress = emailConfig.DefaultSenderAddress,
                SenderName = emailConfig.DefaultName,
            };

            email.AddNameAndAddressRecipient(String.Empty, emailConfig.ClientSupportServices);

            _emailer.Send(email);
        }
    }
}
