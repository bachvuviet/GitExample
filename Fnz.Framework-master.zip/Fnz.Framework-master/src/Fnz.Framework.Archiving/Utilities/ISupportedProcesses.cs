﻿using System.Collections.Generic;
using Fnz.Core.Platform.Framework.Commands;
using Fnz.Framework.Archiving.Api.Commands;

namespace Fnz.Framework.Archiving.DataAccess.Readers
{
    public interface ISupportedProcesses
    {
        Dictionary<string, ICommandHandler<ArchiveProcessCommand>> GetSupportedArchiveProcesses();

        Dictionary<string, ICommandHandler<ArchiveProcessCommand>> GetSupportedMigrationProcesses();
    }
}
