﻿using System.Collections.Generic;
using Fnz.Core.Platform.Framework.Commands;
using Fnz.Framework.Archiving.Api.Commands;
using Fnz.Framework.Archiving.DataAccess.Writers;
using Fnz.Framework.Archiving.Utilities;
using Fnz.Framework.DocumentRepository.Api;

namespace Fnz.Framework.Archiving.DataAccess.Readers
{
    public class SupportedProcesses : ISupportedProcesses
    {
        private readonly IArchiveAuditLogWriter _auditLogWriter;

        private readonly IArchiveFileLogWriter _fileLogWriter;

        private readonly IDocumentRepository _documentRepository;

        private readonly IArchiveFileGenerator _archiveFileGenerator;

        public SupportedProcesses(IArchiveAuditLogWriter auditLogWriter, IArchiveFileLogWriter fileLogWriter, IDocumentRepository documentRepository, IArchiveFileGenerator archiveFileGenerator)
        {
            _auditLogWriter = auditLogWriter;

            _fileLogWriter = fileLogWriter;

            _documentRepository = documentRepository;

            _archiveFileGenerator = archiveFileGenerator;
        }

        public Dictionary<string, ICommandHandler<ArchiveProcessCommand>> GetSupportedArchiveProcesses()
        {
            return new Dictionary<string, ICommandHandler<ArchiveProcessCommand>>
            {
                { "XMLServicesLog", new ArchiveProcessCommandHandler("id", _auditLogWriter, _fileLogWriter, new XmlServicesLogArchiveProcessReader(), new XmlServicesLogArchiveProcessWriter(), _documentRepository, _archiveFileGenerator) },
            };
        }

        public Dictionary<string, ICommandHandler<ArchiveProcessCommand>> GetSupportedMigrationProcesses()
        {
            return new Dictionary<string, ICommandHandler<ArchiveProcessCommand>>
            {
                { "XMLServicesLog", new ArchiveProcessCommandHandler("id", _auditLogWriter, _fileLogWriter, new XmlServicesLogMigrationProcessReader(), new XmlServicesLogMigrationProcessWriter(), _documentRepository, _archiveFileGenerator) },
            };
        }
    }
}
