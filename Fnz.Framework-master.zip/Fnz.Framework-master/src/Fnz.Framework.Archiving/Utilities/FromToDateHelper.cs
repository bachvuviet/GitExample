﻿using System;

namespace Fnz.Framework.Archiving.Utilities
{
    public class FromToDateHelper
    {
        public DateTime GetFromDate(DateTime asAt, int daysOfDataToKeep)
        {
            return GetToDate(asAt, daysOfDataToKeep).AddDays(-1);
        }

        public DateTime GetToDate(DateTime asAt, int daysOfDataToKeep)
        {
            return asAt.AddDays(-daysOfDataToKeep);
        }
    }
}
