﻿using System.Collections.Generic;

namespace Fnz.Framework.Archiving.Utilities
{
    public interface IMigrationsEmailer
    {
        void SendCompleteProcessNotification(IList<string> processes);

        void SendDisableTaskNotification();
    }
}
