﻿using System.Collections.Generic;
using System.Linq;
using Fnz.Framework.Archiving.Api.Entities;
using Fnz.Framework.Archiving.DataAccess.Mappers;
using Fnz.Framework.DataAccess;
using Fnz.Framework.MetaData.Archiving.Archiving;
using Fnz.Framework.ReadersWriters;

namespace Fnz.Framework.Archiving.DataAccess.Readers
{
    public class ProcessesReader : DataAccessBase, IProcessesReader
    {
        public ProcessesReader() : this(new Dal())
        {
        }

        public ProcessesReader(IDataAccess dal)
            : base(dal)
        {
        }

        public IList<ArchiveProcess> GetArchiveProcessCommands()
        {
            var search = new Params
            {
                Column(ProcessesTable.Columns.Enabled).IsEqualTo(1)
            };

            var processes = QueryFactory.Select()
                .From<ProcessesTable>()
                .Where(search)
                .Execute(new ArchiveProcessMapper());

            return processes.OrderBy(p => p.ArchivingOrder).ToList();
        }
    }
}
