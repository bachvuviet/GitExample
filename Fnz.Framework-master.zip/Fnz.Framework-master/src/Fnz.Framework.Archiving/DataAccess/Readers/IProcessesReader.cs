﻿using System.Collections.Generic;
using Fnz.Framework.Archiving.Api;
using Fnz.Framework.Archiving.Api.Commands;
using Fnz.Framework.Archiving.Api.Entities;

namespace Fnz.Framework.Archiving.DataAccess.Readers
{
    public interface IProcessesReader
    {
        IList<ArchiveProcess> GetArchiveProcessCommands();
    }
}
