﻿using System;
using Fnz.Framework.DataAccess;
using Fnz.Framework.MetaData.Archiving.Archiving;
using Fnz.Framework.ReadersWriters;

namespace Fnz.Framework.Archiving.DataAccess.Readers
{
    public class XmlServicesLogMigrationProcessReader : DataAccessBase, IArchiveProcessReader
    {
        public XmlServicesLogMigrationProcessReader() : this(new Dal())
        {
        }

        public XmlServicesLogMigrationProcessReader(IDataAccess dal)
            : base(dal)
        {
        }

        public int GetFromIdForDay(DateTime date)
        {
            var result = QueryFactory.Procedure<GetXMLServicesLogMigrationFromIdProcedure>()
                .WithParameters(date, 0)
                .ExecuteWithOutputValues<GetXMLServicesLogMigrationFromIdProcedure.OutputValues>();

            return result.StartId;
        }

        public int GetToIdForDay(DateTime date)
        {
            var result = QueryFactory.Procedure<GetXMLServicesLogMigrationToIdProcedure>()
                .WithParameters(date, 0)
                .ExecuteWithOutputValues<GetXMLServicesLogMigrationToIdProcedure.OutputValues>();

            return result.EndId;
        }

        public Recordset GetRows(int rowsToRead, int fromId, int toId, DateTime fromDate, DateTime toDate)
        {
            return QueryFactory.Procedure<GetXMLServicesLogMigrationProcedure>()
                .WithParameters(rowsToRead, fromId, toId, fromDate, toDate)
                .Execute();
        }
    }
}
