﻿using System;
using Fnz.Framework.DataAccess;

namespace Fnz.Framework.Archiving.DataAccess.Readers
{
    public interface IArchiveProcessReader
    {
        int GetFromIdForDay(DateTime date);

        int GetToIdForDay(DateTime date);

        Recordset GetRows(int rowsToRead, int fromId, int toId, DateTime fromDate, DateTime toDate);
    }
}
