﻿using System.Collections.Generic;
using Fnz.Framework.Archiving.Api.Entities;

namespace Fnz.Framework.Archiving.DataAccess.Readers
{
    public interface IMigrationsReader
    {
        IList<MigrationProcess> GetMigrationProcessCommands();
    }
}
