﻿using System;
using Fnz.Framework.DataAccess;
using Fnz.Framework.MetaData.Archiving.Archiving;
using Fnz.Framework.ReadersWriters;

namespace Fnz.Framework.Archiving.DataAccess.Readers
{
    public class XmlServicesLogArchiveProcessReader : DataAccessBase, IArchiveProcessReader
    {
        public XmlServicesLogArchiveProcessReader() : this(new Dal())
        {
        }

        public XmlServicesLogArchiveProcessReader(IDataAccess dal) : base(dal)
        {
        }

        public int GetFromIdForDay(DateTime date)
        {
            var result = QueryFactory.Procedure<GetXMLServicesLogFromIdProcedure>()
                .WithParameters(date, 0)
                .ExecuteWithOutputValues<GetXMLServicesLogFromIdProcedure.OutputValues>();

            return result.StartId;
        }

        public int GetToIdForDay(DateTime date)
        {
            var result = QueryFactory.Procedure<GetXMLServicesLogToIdProcedure>()
                .WithParameters(date, 0)
                .ExecuteWithOutputValues<GetXMLServicesLogToIdProcedure.OutputValues>();

            return result.EndId;
        }

        public Recordset GetRows(int rowsToRead, int fromId, int toId, DateTime fromDate, DateTime toDate)
        {
            return QueryFactory.Procedure<GetXMLServicesLogProcedure>()
                .WithParameters(rowsToRead, fromId, toId, fromDate, toDate)
                .Execute();
        }
    }
}
