﻿using System.Collections.Generic;
using System.Linq;
using Fnz.Framework.Archiving.Api.Entities;
using Fnz.Framework.Archiving.DataAccess.Mappers;
using Fnz.Framework.DataAccess;
using Fnz.Framework.MetaData.Archiving.Archiving;
using Fnz.Framework.ReadersWriters;

namespace Fnz.Framework.Archiving.DataAccess.Readers
{
    public class MigrationsReader : DataAccessBase, IMigrationsReader
    {
        public MigrationsReader() : this(new Dal())
        {
        }

        public MigrationsReader(IDataAccess dal) : base(dal)
        {
        }

        public IList<MigrationProcess> GetMigrationProcessCommands()
        {
            var search = new Params
            {
                Column(MigrationsTable.Columns.Enabled).IsEqualTo(1)
            };

            var processes = QueryFactory.Select()
                .From<MigrationsTable>()
                .Where(search)
                .Execute(new MigrationProcessMapper());

            return processes.OrderBy(p => p.ArchivingOrder).ToList();
        }
    }
}
