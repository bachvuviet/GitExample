﻿using Fnz.Framework.Archiving.Api.Entities;
using Fnz.Framework.Archiving.DataAccess.Mappers;
using Fnz.Framework.DataAccess;
using Fnz.Framework.MetaData.Archiving.Archiving;
using Fnz.Framework.ReadersWriters;

namespace Fnz.Framework.Archiving.DataAccess.Writers
{
    public class MigrationsWriter : DataAccessBase, IMigrationsWriter
    {
        private readonly MigrationProcessMapper _mapper;

        public MigrationsWriter(IDataAccess dal)
            : base(dal)
        {
            _mapper = new MigrationProcessMapper();
        }

        public bool AdvanceNextArchiveDate(MigrationProcess migration)
        {
            var completed = false;
            migration.NextArchiveDate = migration.NextArchiveDate.AddDays(1);

            if (migration.NextArchiveDate > migration.FinalArchiveDate)
            {
                completed = true;
                migration.Enabled = 0;
            }

            var rs = _mapper.CreateRecordset(migration);

            rs.Apply(r => r.RowStatus = Recordset.RecordStatus.Modified);
            DataAccess.SaveRecordset<MigrationsTable>(rs, false);

            return completed;
        }
    }
}
