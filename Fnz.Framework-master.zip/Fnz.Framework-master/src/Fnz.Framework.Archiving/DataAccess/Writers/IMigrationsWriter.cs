﻿using Fnz.Framework.Archiving.Api.Entities;

namespace Fnz.Framework.Archiving.DataAccess.Writers
{
    public interface IMigrationsWriter
    {
        /// <summary>
        /// Increment the archive date. Returns bool indicating if migration process has just completed.
        /// </summary>
        bool AdvanceNextArchiveDate(MigrationProcess migration);
    }
}
