﻿using System;
using System.Diagnostics;
using Fnz.Framework.DataAccess;
using Fnz.Framework.MetaData.Archiving.Archiving;
using Fnz.Framework.ReadersWriters;

namespace Fnz.Framework.Archiving.DataAccess.Writers
{
    public class ArchiveAuditLogWriter : DataAccessBase, IArchiveAuditLogWriter
    {
        private readonly Stopwatch _watch;

        public ArchiveAuditLogWriter(IDataAccess dal) : base(dal)
        {
            _watch = new Stopwatch();
        }

        public int BeginAuditLog(string processName, DateTime archiveDate)
        {
            _watch.Start();
            var result = QueryFactory.Procedure<InsertAuditLogProcedure>()
                .WithParameters(processName, archiveDate, 0)
                .ExecuteWithOutputValues<InsertAuditLogProcedure.OutputValues>();
            return result.AuditLogId;
        }

        public void CompleteAuditLog(int auditLogId, int rowsDeleted)
        {
            _watch.Stop();

            QueryFactory.Procedure<InsertAuditLogStatsProcedure>()
                .WithParameters(auditLogId, _watch.Elapsed.Seconds, rowsDeleted)
                .Execute();
        }

        public void CompleteAuditLogWithError(int auditLogId, int rowsDeleted, string errorString)
        {
            CompleteAuditLog(auditLogId, rowsDeleted);

            QueryFactory.Procedure<InsertAuditLogErrorsProcedure>()
                .WithParameters(auditLogId, errorString)
                .Execute();
        }
    }
}
