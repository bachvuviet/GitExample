﻿using Fnz.Framework.Archiving.Api.Entities;

namespace Fnz.Framework.Archiving.DataAccess.Writers
{
    public interface IArchiveFileLogWriter
    {
        void CreateFileLog(ArchiveFileLog fileLog);
    }
}
