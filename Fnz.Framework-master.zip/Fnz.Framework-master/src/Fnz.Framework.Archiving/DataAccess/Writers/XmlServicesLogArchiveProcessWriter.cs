﻿using System;
using Fnz.Framework.DataAccess;
using Fnz.Framework.MetaData.Archiving.Archiving;
using Fnz.Framework.ReadersWriters;

namespace Fnz.Framework.Archiving.DataAccess.Writers
{
    public class XmlServicesLogArchiveProcessWriter : DataAccessBase, IArchiveProcessWriter
    {
        public XmlServicesLogArchiveProcessWriter() : this(new Dal())
        {
        }

        public XmlServicesLogArchiveProcessWriter(IDataAccess dal) : base(dal)
        {
        }

        public int DeleteLogRows(int fromId, int toId, DateTime fromDate, DateTime toDate)
        {
            var result = QueryFactory.Procedure<DeleteXMLServicesLogProcedure>()
                .WithParameters(fromId, toId, fromDate, toDate, 0)
                .ExecuteWithOutputValues<DeleteXMLServicesLogProcedure.OutputValues>();

            return result.DeletedRowCount;
        }
    }
}
