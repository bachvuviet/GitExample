﻿using System;
using Fnz.Framework.Archiving.Api.Commands;

namespace Fnz.Framework.Archiving.DataAccess.Writers
{
    public interface IArchiveAuditLogWriter
    {
        int BeginAuditLog(string processName, DateTime archiveDate);

        void CompleteAuditLog(int auditLogId, int rowsDeleted);

        void CompleteAuditLogWithError(int auditLogId, int rowsDeleted, string errorString);
    }
}
