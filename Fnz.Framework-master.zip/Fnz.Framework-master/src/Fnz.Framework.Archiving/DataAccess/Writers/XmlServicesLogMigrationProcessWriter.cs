﻿using System;
using Fnz.Framework.DataAccess;
using Fnz.Framework.ReadersWriters;

namespace Fnz.Framework.Archiving.DataAccess.Writers
{
    public class XmlServicesLogMigrationProcessWriter : DataAccessBase, IArchiveProcessWriter
    {
        public XmlServicesLogMigrationProcessWriter()
            : this(new Dal())
        {
        }

        public XmlServicesLogMigrationProcessWriter(IDataAccess dal)
            : base(dal)
        {
        }

        public int DeleteLogRows(int fromId, int toId, DateTime fromDate, DateTime toDate)
        {
            // For migrations we don't want to delete as we go, as it will just fill up the
            // transaction logs. Instead we'll send an email once the migration is complete
            // and S&S can raise a script to truncate the table. 

            return 1 + toId - fromId;
        }
    }
}
