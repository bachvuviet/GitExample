﻿using Fnz.Framework.Archiving.Api.Entities;
using Fnz.Framework.Archiving.DataAccess.Mappers;
using Fnz.Framework.DataAccess;
using Fnz.Framework.MetaData.Archiving.Archiving;
using Fnz.Framework.ReadersWriters;

namespace Fnz.Framework.Archiving.DataAccess.Writers
{
    public class ArchiveFileLogWriter : DataAccessBase, IArchiveFileLogWriter
    {
        private readonly ArchiveFileLogMapper _mapper;

        public ArchiveFileLogWriter(IDataAccess dal) : base(dal)
        {
            _mapper = new ArchiveFileLogMapper();
        }

        public void CreateFileLog(ArchiveFileLog fileLog)
        {
            var rs = _mapper.CreateRecordset(fileLog);
            rs.Apply(r => r.RowStatus = Recordset.RecordStatus.Added);
            DataAccess.SaveRecordset<FileLogTable>(rs, false);
        }
    }
}
