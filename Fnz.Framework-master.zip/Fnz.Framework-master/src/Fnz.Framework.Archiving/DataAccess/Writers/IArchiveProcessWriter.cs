﻿using System;

namespace Fnz.Framework.Archiving.DataAccess.Writers
{
    public interface IArchiveProcessWriter
    {
        int DeleteLogRows(int fromId, int toId, DateTime fromDate, DateTime toDate);
    }
}
