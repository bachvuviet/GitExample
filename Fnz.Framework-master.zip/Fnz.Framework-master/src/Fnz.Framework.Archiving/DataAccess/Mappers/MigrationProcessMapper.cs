﻿using Fnz.Framework.Archiving.Api.Entities;
using Fnz.Framework.DataAccess.RecordsetMapping;
using Fnz.Framework.DataAccess.RecordsetMapping.Data.ChangeTracking;
using Fnz.Framework.MetaData.Archiving.Archiving;

namespace Fnz.Framework.Archiving.DataAccess.Mappers
{
    public sealed class MigrationProcessMapper : RecordsetMapper<MigrationProcess>
    {
        public MigrationProcessMapper() : base(new ActivatorFactory())
        {
            Maps(x => x.ProcessName).To(MigrationsTable.Columns.ProcessName);
            Maps(x => x.RowsPerFile).To(MigrationsTable.Columns.RowsPerFile);
            Maps(x => x.ArchivingOrder).To(MigrationsTable.Columns.ArchivingOrder);
            Maps(x => x.Enabled).To(MigrationsTable.Columns.Enabled);
            Maps(x => x.NextArchiveDate).To(MigrationsTable.Columns.NextArchiveDate);
            Maps(x => x.FinalArchiveDate).To(MigrationsTable.Columns.FinalArchiveDate);
        }
    }
}
