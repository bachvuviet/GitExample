﻿using Fnz.Framework.Archiving.Api.Entities;
using Fnz.Framework.DataAccess.RecordsetMapping;
using Fnz.Framework.DataAccess.RecordsetMapping.Data.ChangeTracking;
using Fnz.Framework.MetaData.Archiving.Archiving;

namespace Fnz.Framework.Archiving.DataAccess.Mappers
{
    public sealed class ArchiveFileLogMapper : RecordsetMapper<ArchiveFileLog>
    {
        public ArchiveFileLogMapper()
            : base(new ActivatorFactory())
        {
            Maps(x => x.FileName).To(FileLogTable.Columns.FileName);
            Maps(x => x.AuditLogId).To(FileLogTable.Columns.AuditLogId);
            Maps(x => x.MinId).To(FileLogTable.Columns.MinId);
            Maps(x => x.MaxId).To(FileLogTable.Columns.MaxId);
            Maps(x => x.RowsArchived).To(FileLogTable.Columns.RowsArchived);
            Maps(x => x.DateTimeArchived).To(FileLogTable.Columns.DateTimeArchived);
        }
    }
}
