﻿using Fnz.Framework.Archiving.Api.Entities;
using Fnz.Framework.DataAccess.RecordsetMapping;
using Fnz.Framework.DataAccess.RecordsetMapping.Data.ChangeTracking;
using Fnz.Framework.MetaData.Archiving.Archiving;

namespace Fnz.Framework.Archiving.DataAccess.Mappers
{
    public sealed class ArchiveProcessMapper : RecordsetMapper<ArchiveProcess>
    {
        public ArchiveProcessMapper()
            : base(new ActivatorFactory())
        {
            Maps(x => x.ProcessName).To(ProcessesTable.Columns.ProcessName);
            Maps(x => x.DaysOfDataToKeep).To(ProcessesTable.Columns.DaysOfDataToKeep);
            Maps(x => x.RowsPerFile).To(ProcessesTable.Columns.RowsPerFile);
            Maps(x => x.ArchivingOrder).To(ProcessesTable.Columns.ArchivingOrder);
            Maps(x => x.Enabled).To(ProcessesTable.Columns.Enabled);
        }
    }
}