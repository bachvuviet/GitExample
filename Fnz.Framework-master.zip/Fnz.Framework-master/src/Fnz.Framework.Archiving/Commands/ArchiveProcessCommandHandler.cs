﻿using System;
using System.IO;
using System.Linq;
using Fnz.Core.Platform.Framework.Commands;
using Fnz.Framework.Archiving.Api.Commands;
using Fnz.Framework.Archiving.Api.Entities;
using Fnz.Framework.Archiving.DataAccess.Readers;
using Fnz.Framework.Archiving.DataAccess.Writers;
using Fnz.Framework.Archiving.Utilities;
using Fnz.Framework.DataAccess;
using Fnz.Framework.DocumentRepository.Api;

namespace Fnz.Framework.Archiving
{
    /// <summary>
    /// Represents an single archiving process - like one which would archive
    /// XMLServices log for example. Will produce a CSV archive, upload to HCP
    /// then delete the archived rows from the table in question. 
    /// </summary>
    public class ArchiveProcessCommandHandler : ICommandHandler<ArchiveProcessCommand>
    {
        private readonly IArchiveProcessReader _archiveProcessReader;

        private readonly IArchiveProcessWriter _archiveProcessWriter;

        private readonly IDocumentRepository _documentRepository;

        private readonly IArchiveFileGenerator _fileGenerator;

        private readonly IArchiveAuditLogWriter _auditLogWriter;

        private readonly IArchiveFileLogWriter _fileLogWriter;

        private readonly string _identityColumn;

        private int _auditLogId;

        private int _totalRowsArchived;

        private int _fromId;

        private int _toId;

        public ArchiveProcessCommandHandler(string identityColumn, IArchiveAuditLogWriter auditLogWriter, IArchiveFileLogWriter fileLogWriter, IArchiveProcessReader archiveProcessReader, IArchiveProcessWriter archiveProcessWriter, IDocumentRepository documentRepository, IArchiveFileGenerator fileGenerator)
        {
            _identityColumn = identityColumn;

            _auditLogWriter = auditLogWriter;

            _fileLogWriter = fileLogWriter;

            _archiveProcessReader = archiveProcessReader;

            _archiveProcessWriter = archiveProcessWriter;

            _documentRepository = documentRepository;

            _fileGenerator = fileGenerator;
        }

        public void Execute(ArchiveProcessCommand command)
        {
            _auditLogId = _auditLogWriter.BeginAuditLog(command.ProcessName, command.FromDate);

            GetToAndFromIdsFromDay(command.FromDate, command.ToDate);

            while (_fromId <= _toId)
            {
                var rowsToArchive = _archiveProcessReader.GetRows(command.RowsPerFile, _fromId, _toId, command.FromDate, command.ToDate);
                if (!rowsToArchive.Any())
                {
                    break;
                }

                var csvFileName = GetFileName(command.ProcessName, command.ToDate, _fromId);

                using (var archiveFile = ProduceArchiveFile(rowsToArchive, csvFileName))
                {
                    var zipFileName = UploadToDocumentRepository(archiveFile, csvFileName);
                    var archivedRangeEndId = DeleteRowsFromTable(rowsToArchive, _fromId, command.FromDate, command.ToDate);

                    CreateFileLogEntry(zipFileName, _fromId, archivedRangeEndId, rowsToArchive.Count());
                    _totalRowsArchived += rowsToArchive.Count();
                    _fromId = archivedRangeEndId + 1;
                }
            }

            _auditLogWriter.CompleteAuditLog(_auditLogId, _totalRowsArchived);
        }

        private void GetToAndFromIdsFromDay(DateTime fromDate, DateTime toDate)
        {
            try
            {
                _fromId = _archiveProcessReader.GetFromIdForDay(fromDate);
                _toId = _archiveProcessReader.GetToIdForDay(toDate);
            }
            catch (Exception e)
            {
                _auditLogWriter.CompleteAuditLogWithError(_auditLogId, 0,
                                                          "Could not retrieve the From/To IDs for the archive process. Error: " + e.Message);
                throw;
            }
        }

        private Stream ProduceArchiveFile(Recordset rowsToArchive, string csvFileName)
        {
            Stream archiveFile;

            try
            {
                archiveFile = _fileGenerator.GenerateArchiveZip(rowsToArchive, csvFileName);
            }
            catch (Exception)
            {
                _auditLogWriter.CompleteAuditLogWithError(_auditLogId, _totalRowsArchived, "Error creating file to archive");
                throw;
            }

            return archiveFile;
        }

        private string UploadToDocumentRepository(Stream archiveFile, string fileName)
        {
            var zipFileName = fileName + ".zip";

            try
            {
                _documentRepository.SaveDocument(archiveFile, zipFileName, SaveActionEnum.Create);
            }
            catch (Exception)
            {
                _auditLogWriter.CompleteAuditLogWithError(_auditLogId, _totalRowsArchived, "Error saving file to Document Repository (HCP)");
                throw;
            }

            return zipFileName;
        }

        private int DeleteRowsFromTable(Recordset rowsToArchive, int startId, DateTime fromDate, DateTime toDate)
        {
            rowsToArchive.MoveLast();
            var endId = rowsToArchive.GetAsInteger(_identityColumn);

            using (var ts = new TransactionAndConnectionScope())
            {
                int rowsDeleted;
                try
                {
                    rowsDeleted = _archiveProcessWriter.DeleteLogRows(startId, endId, fromDate, toDate);
                }
                catch (Exception)
                {
                    _auditLogWriter.CompleteAuditLogWithError(_auditLogId, _totalRowsArchived, "Error attempting to delete table rows");
                    throw;
                }

                if (rowsDeleted != rowsToArchive.Count())
                {
                    var errorMessage = String.Format("Archived {0} rows, but attempted to delete {1}",
                        rowsToArchive.Count(), rowsDeleted);
                    _auditLogWriter.CompleteAuditLogWithError(_auditLogId, _totalRowsArchived, errorMessage);
                    throw new Exception(errorMessage);
                }

                ts.Complete();
            }

            return endId;
        }
        
        private void CreateFileLogEntry(string fileName, int startId, int endId, int rowsArchivedCount)
        {
            _fileLogWriter.CreateFileLog(new ArchiveFileLog
            {
                AuditLogId = _auditLogId,
                FileName = fileName,
                MinId = startId,
                MaxId = endId,
                RowsArchived = rowsArchivedCount,
                DateTimeArchived = DateTime.Now
            });    
        }

        private static string GetFileName(string processName, DateTime asat, int archiveStartId)
        {
            return String.Format("{0}_Archive_{1}_{2}.csv", processName, asat.ToString("yyyyMMdd"), archiveStartId);
        }
    }
}