﻿using System;
using System.Collections.Generic;
using System.Linq;
using Fnz.Framework.Archiving.Api.Commands;
using Fnz.Framework.Archiving.DataAccess.Readers;
using Fnz.Framework.Archiving.DataAccess.Writers;
using Fnz.Framework.Archiving.Utilities;
using Fnz.Framework.DataAccess.Logging;

namespace Fnz.Framework.Archiving
{
    /// <summary>
    /// Task to orchestrate archiving and deletion of DB tables. Reads archive 
    /// process configurations from Platform.Archiving.Processes, then uses
    /// an ISupportedArchiveProcessReader to map the process config to the class
    /// responsible for retrieving\deleting the code in question.
    /// </summary>
    public class ArchiveTaskCommandHandler : IArchiveTaskCommandHandler
    {
        private readonly IProcessesReader _processesReader;

        private readonly IExceptionLogger _exceptionLogger;

        private readonly ISupportedProcesses _supportedProcesses;

        private readonly IArchiveAuditLogWriter _auditLogWriter;

        public ArchiveTaskCommandHandler(IProcessesReader commandReader, IExceptionLogger exceptionLogger, ISupportedProcesses supportedProcesses, IArchiveAuditLogWriter auditLogWriter)
        {
            _processesReader = commandReader;

            _exceptionLogger = exceptionLogger;

            _supportedProcesses = supportedProcesses;

            _auditLogWriter = auditLogWriter;
        }

        public void Execute(ArchiveTaskCommand taskCommand)
        {
            var processes = _processesReader.GetArchiveProcessCommands();
            var supportedProcesses = _supportedProcesses.GetSupportedArchiveProcesses();
            var failedProcesses = new List<string>();
            var dateHelper = new FromToDateHelper();

            foreach (var process in processes.Where(c => c.Enabled == 1))
            {
                try
                {
                    var asAt = taskCommand.AsAt.HasValue ? taskCommand.AsAt.Value : DateTime.Today;

                    var archiveCommand = new ArchiveProcessCommand
                    {
                        ProcessName = process.ProcessName,
                        FromDate = dateHelper.GetFromDate(asAt, process.DaysOfDataToKeep),
                        ToDate = dateHelper.GetToDate(asAt, process.DaysOfDataToKeep),
                        RowsPerFile = process.RowsPerFile
                    };

                    if (!supportedProcesses.ContainsKey(archiveCommand.ProcessName))
                    {
                        var auditLogId = _auditLogWriter.BeginAuditLog(archiveCommand.ProcessName,
                                                                       archiveCommand.ToDate);
                        _auditLogWriter.CompleteAuditLogWithError(auditLogId, 0, "Archive process is not supported");
                        failedProcesses.Add(archiveCommand.ProcessName);
                        continue;
                    }

                    supportedProcesses[archiveCommand.ProcessName].Execute(archiveCommand);
                }
                catch (Exception e)
                {
                    failedProcesses.Add(process.ProcessName);
                    _exceptionLogger.LogException(e);
                }
            }

            if (failedProcesses.Any())
            {
                throw new Exception(String.Format("The following archive processes failed: {0}", String.Join(", ", failedProcesses.ToArray())));
            }
        }
    }
}
