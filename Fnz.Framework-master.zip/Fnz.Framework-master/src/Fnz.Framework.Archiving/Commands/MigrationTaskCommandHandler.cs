﻿using System;
using System.Collections.Generic;
using System.Linq;
using Fnz.Core.Platform.Framework.Commands;
using Fnz.Framework.Archiving.Api.Commands;
using Fnz.Framework.Archiving.Api.Entities;
using Fnz.Framework.Archiving.DataAccess.Readers;
using Fnz.Framework.Archiving.DataAccess.Writers;
using Fnz.Framework.Archiving.Utilities;
using Fnz.Framework.DataAccess.Logging;

namespace Fnz.Framework.Archiving.Commands
{
    /// <summary>
    /// Task responsible for migrating historical data in DB tables we're going
    /// to start archiving. Driven by Platform.Archiving.Migrations (and dependent
    /// on an existing Platform.Archiving.Processes) and roughly similar to 
    /// ArchiveTaskCommandHandler, but different enough that it's not worth trying
    /// to pretend otherwise.
    /// </summary>
    public class MigrationTaskCommandHandler : ICommandHandler<MigrationTaskCommand>
    {
        private readonly IMigrationsReader _migrationsReader;

        private readonly IMigrationsWriter _migrationsWriter;

        private readonly IExceptionLogger _exceptionLogger;

        private readonly ISupportedProcesses _supportedProcesses;

        private readonly IArchiveAuditLogWriter _auditLogWriter;

        private readonly IMigrationsEmailer _emailer;

        private readonly IList<string> _failedProcesses;

        private readonly IList<string> _completedProcesses; 

        public MigrationTaskCommandHandler(IMigrationsReader migrationsReader, IMigrationsWriter migrationsWriter, IExceptionLogger exceptionLogger, ISupportedProcesses supportedProcesses, IArchiveAuditLogWriter auditLogWriter, IMigrationsEmailer emailer)
        {
            _migrationsReader = migrationsReader;

            _migrationsWriter = migrationsWriter;

            _exceptionLogger = exceptionLogger;

            _supportedProcesses = supportedProcesses;

            _auditLogWriter = auditLogWriter;

            _emailer = emailer;

            _failedProcesses = new List<string>();

            _completedProcesses = new List<string>();
        }

        public void Execute(MigrationTaskCommand command)
        {
            var migrations = _migrationsReader.GetMigrationProcessCommands();
            var migrationProcesses = _supportedProcesses.GetSupportedMigrationProcesses();
            
            ReportTaskCanBeDisabled(migrations);

            foreach (var migration in migrations.Where(c => c.Enabled == 1))
            {
                try
                {
                    var archiveCommand = CreateArchiveProcessCommand(migration.ProcessName, migration.NextArchiveDate,
                                                                     migration.RowsPerFile);
                    if (!migrationProcesses.ContainsKey(migration.ProcessName))
                    {
                        LogUnsupportedProcess(archiveCommand.ProcessName, archiveCommand.ToDate);
                        continue;
                    }

                    migrationProcesses[archiveCommand.ProcessName].Execute(archiveCommand);
                    AdvanceNextArchiveDate(migration);
                } 
                catch (Exception e)
                {
                    FailProcess(migration.ProcessName, e);
                }
            }

            ReportCompletedAndFailedProcesses();
        }

        private ArchiveProcessCommand CreateArchiveProcessCommand(string processName, DateTime fromDate, int rowsPerFile)
        {
            return new ArchiveProcessCommand
            {
                ProcessName = processName,
                FromDate = fromDate,
                ToDate = fromDate.AddDays(1),
                RowsPerFile = rowsPerFile
            };
        }

        private void FailProcess(string processName, Exception e)
        {
            _failedProcesses.Add(processName);
            _exceptionLogger.LogException(e);
        }

        private void LogUnsupportedProcess(string processName, DateTime asat)
        {
            var auditLogId = _auditLogWriter.BeginAuditLog(processName, asat);
            _auditLogWriter.CompleteAuditLogWithError(auditLogId, 0, "Archive process is not supported");
            _failedProcesses.Add(processName);
        }

        private void ReportTaskCanBeDisabled(IEnumerable<MigrationProcess> migrations)
        {
            if (!migrations.Where(m => m.Enabled == 1).Any())
            {
                _emailer.SendDisableTaskNotification();
            }
        }
        
        private void ReportCompletedAndFailedProcesses()
        {
            if (_completedProcesses.Any())
            {
                _emailer.SendCompleteProcessNotification(_completedProcesses);
            }

            if (_failedProcesses.Any())
            {
                throw new Exception(String.Format("The following migration processes failed: {0}", String.Join(", ", _failedProcesses.ToArray())));
            }
        }

        private void AdvanceNextArchiveDate(MigrationProcess migration)
        {
            if (_migrationsWriter.AdvanceNextArchiveDate(migration))
            {
                _completedProcesses.Add(migration.ProcessName);
            }
        }
    }
}