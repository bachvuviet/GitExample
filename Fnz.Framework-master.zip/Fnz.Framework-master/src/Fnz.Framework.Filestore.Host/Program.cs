﻿using System;
using System.Configuration;
using System.IO;
using System.Reflection;
using Castle.MicroKernel.Registration;
using Castle.Windsor;
using log4net;
using log4net.Config;
using Topshelf;

namespace Fnz.Framework.Filestore.Host
{
    public class Program
    {
        // Using Raw Log4net here because we have not bootrapped the container yet, so can't use the Castle Logging Facility
        private static readonly ILog Log = LogManager.GetLogger(typeof(Program));

        public static void Main(string[] args)
        {
            try
            {
                try
                {
                    var exeFile = new FileInfo(Assembly.GetExecutingAssembly().Location);
                    string logConfig = Path.Combine(exeFile.Directory.FullName, "log4net.config");
                    XmlConfigurator.Configure(new FileInfo(logConfig));
                }
                catch (Exception e) 
                {
                    // TODO logging failed to load - suppress just now but should probably fail
                    Console.WriteLine("Failed to load the log4net.config. Error: " + e.Message);
                }

                var container = new WindsorContainer();

                container.Register(Component.For<FilestoreHosting>().Named("filestore"));

                HostFactory.Run(x =>                                 
                {
                    x.Service<FilestoreHosting>(s =>                        
                    {
                        s.ConstructUsing(name => new FilestoreHosting());
                        s.WhenStarted(service => service.Start());
                        s.WhenStopped(service =>
                        {
                            // stop and release the service, then dispose the container.
                            service.Stop();
                            container.Release(service);
                            container.Dispose();
                        });             
                    });
                    x.RunAsLocalSystem();

                    var assembly = Assembly.GetAssembly(typeof(FilestoreHosting));
                    x.SetDescription("Filestore Service | Fnz - Version: " + assembly.GetName().Version);                     
                    var displayName = "Filestore - " + ConfigurationManager.AppSettings["SystemId"];
                    x.SetDisplayName(displayName);
                    x.SetServiceName("Filestore");                     
                }); 

                //var cfg = RunnerConfigurator.New(x =>   
                //                                     {
                //                                         x.ConfigureService<FilestoreHosting>(
                //                                             "filestore",
                //                                             s =>
                //                                                 {
                //                                                     s.CreateServiceLocator(() => new WindsorServiceLocator(container));
                //                                                     s.WhenStarted(fs => fs.Start());             
                //                                                     s.WhenStopped(fs => fs.Stop());              
                //                                                 });
                //                                         x.RunAsLocalSystem();

                //                                         var assembly = Assembly.GetAssembly(typeof(FilestoreHosting));
                //                                         x.SetDescription("Filestore Service | Open Wrap - Version: " + assembly.GetName().Version);                     
                //                                         var name = "Filestore - " + ConfigurationManager.AppSettings["SystemId"];
                //                                         x.SetDisplayName(name);
                //                                         x.SetServiceName(name);
                //                                     });
                //Runner.Host(cfg, args);
            }
            catch (Exception e)
            {
                Log.Fatal("Filestore exiting because an exception occurred", e);
                Console.WriteLine("Filestore exiting because an exception occurred, see log for details");
            }
        }
    }
}
