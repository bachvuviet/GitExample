﻿using System;
using System.ServiceModel;
using Castle.Facilities.WcfIntegration;
using Castle.Windsor;
using Fnz.Framework.Filestore.Service;
using Fnz.Framework.Filestore.Service.Bootstrapping;

namespace Fnz.Framework.Filestore.Host
{
    public class FilestoreHosting
    {
        private ServiceHostBase _selfHost;

        private IWindsorContainer Container { get; set; }

        public void Start()
        {
            BootstrapWindsor();
            BootstrapServiceHost();
        }

        public void Stop()
        {
            _selfHost.Close();
        }

        private void BootstrapWindsor()
        {
            Container = new WindsorContainer();
            Container.Install(new FilestoreServiceInstaller());
        }

        private void BootstrapServiceHost()
        {
            // force FilestoreService to load to check for exceptions
            Container.Resolve<IFilestoreService>();

            _selfHost = new DefaultServiceHostFactory().CreateServiceHost(
                            typeof(IFilestoreService).AssemblyQualifiedName, 
                            new Uri[0]);

            _selfHost.Open();
            Console.WriteLine("Filestore Service has started.  Hit Ctrl+C to exit.");
        }
    }
}
