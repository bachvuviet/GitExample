﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Castle.MicroKernel.Registration;
using Fnz.Framework.Archiving.Setup;
using Fnz.Framework.Authentication.Saml;
using Fnz.Framework.Cca.DataFlow;
using Fnz.Framework.Cca.Setup;
using Fnz.Framework.Components.Bootstrapping;
using Fnz.Framework.DocumentRepository.Bootstrapping;
using Fnz.Framework.Integration.DataWarehouse.BusinessObjects.Setup;
using Fnz.Framework.Messaging.Interfaces;
using Fnz.Framework.Messaging.Setup;
using Fnz.Framework.Reports.Setup;
using Fnz.Framework.Util.Container;

namespace Fnz.Framework.Bootstrapping
{
    public enum DocumentRespositoryType
    {
        NotSpecified,
        Legacy,
        Hcp
    }

    public class FrameworkInstallersProvider : IInstallersProvider
    {
        private bool _withDataAccess;
        private bool _withComponents;
        private bool _withCca;
        private bool _withArchiving;
        private bool _withDataWarehouse;
        private bool _withReports;
        private bool _withSaml;
        private bool _withMessaging;
        private DocumentRespositoryType _withDocumentRepositoryType = DocumentRespositoryType.NotSpecified;
        private Type[] _withCcaEventWiringTypes;
        private IMessageBusFactory _messageBusFactory;
        private MessagingInstallerConfiguration _messagingConfiguration;

        public IEnumerable<IWindsorInstaller> GetInstallers()
        {
            var installers = new List<IWindsorInstaller>();

            AddInstallerConditionally(_withDataAccess, installers, () => new DataAccessInstaller(true));
            AddInstallerConditionally(_withComponents, installers, () => new ComponentsInstaller());
            AddInstallerConditionally(_withArchiving, installers, () => new ArchivingInstaller());            
            AddInstallerConditionally(_withCca, installers, () => new CoreFrameworkInstaller());
            AddInstallerConditionally(_withCcaEventWiringTypes != null && _withCcaEventWiringTypes.Any(), installers, () => new EventListenersInstaller(_withCcaEventWiringTypes));
            AddInstallerConditionally(_withSaml, installers, () => new SamlInstaller());

            AddInstallerConditionally(_withDataWarehouse || _withReports, installers, () => new DataWarehouseInstaller()); // Reports make use of the Data Warehouse
            AddInstallerConditionally(_withReports, installers, () => new ReportsInstaller());

            AddInstallerConditionally(_withMessaging && _messageBusFactory == null, installers, () => new MessagingInstaller().WithConfiguration(_messagingConfiguration));
            AddInstallerConditionally(_withMessaging && _messageBusFactory != null, installers, () => new MessagingInstaller(_messageBusFactory).WithConfiguration(_messagingConfiguration));

            AddInstallerConditionally(_withDocumentRepositoryType == DocumentRespositoryType.Legacy, installers, () => new DocumentRepositoryInstaller());
            AddInstallerConditionally(_withDocumentRepositoryType == DocumentRespositoryType.Hcp, installers, () => new DocumentRepositoryInstaller().WithHcp());

            return installers;
        }

        private void AddInstallerConditionally(bool condition, IList<IWindsorInstaller> installers, Func<IWindsorInstaller> installerFactory)
        {
            if (condition)
            {
                installers.Add(installerFactory());
            }
        }

        public FrameworkInstallersProvider WithDataAccess()
        {
            _withDataAccess = true;
            return this;
        }           
        
        /// <summary>
        /// Registers ISystemVariablesReader, IEmailReader/Writer, ITask(Request)Reader etc
        /// </summary>
        public FrameworkInstallersProvider WithComponents()
        {
            _withComponents = true;
            return this;
        }

        /// <summary>
        /// Registers Fnz.Framework.Cca components
        /// </summary>
        public FrameworkInstallersProvider WithCca()
        {
            _withCca = true;
            return this;
        }

        /// <summary>
        /// Registers Fnz.Framework.Archiving components
        /// </summary>
        public FrameworkInstallersProvider WithArchiving()
        {
            _withArchiving = true;
            return this;
        }

        /// <summary>
        /// Registers Fnz.Framework.DataWarehouse components
        /// </summary>
        public FrameworkInstallersProvider WithDataWarehouse()
        {
            _withDataWarehouse = true;
            return this;
        }       
        
        /// <summary>
        /// Registers Fnz.Framework.Reports components (and DataWarehouse components)
        /// </summary>
        public FrameworkInstallersProvider WithReports()
        {
            _withReports = true;
            return this;
        }

        /// <summary>
        /// Registers Fnz.Framework.Cca.EventWiring components
        /// </summary>
        public FrameworkInstallersProvider WithCcaEventWiring(Type[] eventListenerTypes)
        {
            _withCcaEventWiringTypes = eventListenerTypes;
            return this;
        }         
        
        /// <summary>
        /// Registers Fnz.Framework.Cca.EventWiring components
        /// </summary>
        public FrameworkInstallersProvider WithCcaEventWiring(Assembly assemblyWithIEventListeners)
        {
            _withCcaEventWiringTypes = assemblyWithIEventListeners.GetTypes();
            return this;
        }        
        
        /// <summary>
        /// Registers Fnz.Framework.Authentication components (for single sign on)
        /// </summary>
        public FrameworkInstallersProvider WithSaml()
        {
            _withSaml = true;
            return this;
        }        

        /// <summary>
        /// Registers Fnz.Framework.DocumentRepository - either the DB (legacy) or HCP (Hitatchi Content Platform filestore)
        /// </summary>
        public FrameworkInstallersProvider WithDocumentRepository(DocumentRespositoryType type)
        {
            _withDocumentRepositoryType = type;
            return this;
        }

        /// <summary>
        /// Registers Fnz.Framework.Messaging components 
        /// </summary>
        public FrameworkInstallersProvider WithMessaging()
        {
            _withMessaging = true;
            return this;
        }

        /// <summary>
        /// Registers Fnz.Framework.Messaging components 
        /// </summary>
        public FrameworkInstallersProvider WithMessaging(MessagingInstallerConfiguration configuration)
        {
            _withMessaging = true;
            _messagingConfiguration = configuration;
            return this;
        }

        /// <summary>
        /// Registers Fnz.Framework.Messaging components 
        /// </summary>
        public FrameworkInstallersProvider WithMessaging(IMessageBusFactory messageBusFactory)
        {
            _withMessaging = true;
            _messageBusFactory = messageBusFactory;
            return this;
        }

        /// <summary>
        /// Registers Fnz.Framework.Messaging components 
        /// </summary>
        public FrameworkInstallersProvider WithMessaging(IMessageBusFactory messageBusFactory, MessagingInstallerConfiguration configuration)
        {
            _withMessaging = true;
            _messageBusFactory = messageBusFactory;
            _messagingConfiguration = configuration;
            return this;
        }
    }
}