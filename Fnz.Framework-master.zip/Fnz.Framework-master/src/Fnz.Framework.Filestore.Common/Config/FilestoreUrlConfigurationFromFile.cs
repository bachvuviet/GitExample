﻿using System.Configuration;

namespace Fnz.Framework.Filestore.Common
{
    public class FilestoreUrlConfigurationFromFile : IFilestoreUrlConfiguration
    {
        public const string FilestoreSystemId = "FilestoreSystemId";
        public const string FilestorePassword = "FilestorePassword";

        public string SystemId
        {
            get { return ConfigurationManager.AppSettings[FilestoreSystemId] ?? "fnz_dev"; }
        }

        public string Password
        {
            get { return ConfigurationManager.AppSettings[FilestorePassword] ?? "password"; }
        }
    }
}
