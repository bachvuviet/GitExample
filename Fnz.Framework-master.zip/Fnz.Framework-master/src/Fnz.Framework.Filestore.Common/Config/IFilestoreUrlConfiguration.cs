﻿namespace Fnz.Framework.Filestore.Common
{
    public interface IFilestoreUrlConfiguration
    {
        string SystemId { get; }

        string Password { get; }
    }
}
