﻿namespace Fnz.Framework.Filestore.Common
{
    public class FilestoreUrlConfiguration : IFilestoreUrlConfiguration
    {
        public string Password { get; set; }

        public string SystemId { get; set; }
    }
}
