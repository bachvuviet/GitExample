﻿using System;
using Fnz.Framework.Util.CodeQuality;

namespace Fnz.Framework.Filestore.Common
{
    [ExcludeFromTestCoverage(IgnoreReason.RequiresAdditionalWork, "Graham Wright", "23 Apr 2010")]
    public class FilestoreLocationNotFoundException : FilestoreException
    {
        public FilestoreLocationNotFoundException(string filestoreLocation)
            : base("Filestore location: {0} not found".FormatWith(filestoreLocation))
        {
        }
    }
}
