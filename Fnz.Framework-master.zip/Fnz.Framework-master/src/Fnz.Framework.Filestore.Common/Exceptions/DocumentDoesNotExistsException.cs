﻿using System;

namespace Fnz.Framework.Filestore.Common
{
    public class DocumentDoesNotExistsException : FilestoreException
    {
        public DocumentDoesNotExistsException(string documentId)
            : base("Document id: {0} does not exist".FormatWith(documentId))
        {
        }
    }
}
