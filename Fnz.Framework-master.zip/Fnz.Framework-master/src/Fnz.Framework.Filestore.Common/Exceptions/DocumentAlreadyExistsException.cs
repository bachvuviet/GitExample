﻿using System;

namespace Fnz.Framework.Filestore.Common
{
    public class DocumentAlreadyExistsException : FilestoreException
    {
        public DocumentAlreadyExistsException(string documentId)
            : base("Document id: {0} already exists".FormatWith(documentId))
        {
        }
    }
}
