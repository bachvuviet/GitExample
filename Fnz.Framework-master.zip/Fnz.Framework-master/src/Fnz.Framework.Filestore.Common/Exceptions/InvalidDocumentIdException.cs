﻿using System;

namespace Fnz.Framework.Filestore.Common
{
    public class InvalidDocumentIdException : FilestoreException
    {
        public InvalidDocumentIdException(string documentId)
            : base("Invalid document id: {0}".FormatWith(documentId))
        {
        }
    }
}
