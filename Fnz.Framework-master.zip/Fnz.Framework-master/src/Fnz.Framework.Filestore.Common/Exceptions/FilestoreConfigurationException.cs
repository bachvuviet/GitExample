﻿using System;
using Fnz.Framework.Util.CodeQuality;

namespace Fnz.Framework.Filestore.Common
{
    [ExcludeFromTestCoverage(IgnoreReason.RequiresAdditionalWork, "Graham Wright", "23 Apr 2010")]
    public class FilestoreConfigurationException : FilestoreException
    {
        public FilestoreConfigurationException(string cause)
            : base("Filestore configuration error: {0}".FormatWith(cause))
        {
        }
    }
}
