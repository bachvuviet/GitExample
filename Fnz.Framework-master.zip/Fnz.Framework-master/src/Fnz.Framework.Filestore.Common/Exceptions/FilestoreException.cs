﻿using System;
using Fnz.Framework.Util.CodeQuality;

namespace Fnz.Framework.Filestore.Common
{
    [ExcludeFromTestCoverage(IgnoreReason.RequiresAdditionalWork, "Graham Wright", "23 Apr 2010")]
    public class FilestoreException : Exception
    {
        public FilestoreException(string message)
            : base(message)
        {
        }

        public FilestoreException(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }
}
