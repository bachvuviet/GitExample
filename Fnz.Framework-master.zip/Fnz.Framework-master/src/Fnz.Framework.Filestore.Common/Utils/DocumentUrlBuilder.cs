﻿using System;

namespace Fnz.Framework.Filestore.Common
{
    public interface IDocumentUrlBuilder
    {
        string BuildDocumentUrl(long documentId);
    }

    public class DocumentUrlBuilder : IDocumentUrlBuilder
    {
        private DocumentUrlCrypto _documentUrlEncryptor;

        public DocumentUrlBuilder()
        {
        }

        public DocumentUrlBuilder(IFilestoreUrlConfiguration filestoreUrlConfiguration)
        {
            SystemId = filestoreUrlConfiguration.SystemId;
            Password = filestoreUrlConfiguration.Password;
        }

        public string SystemId { get; set; }

        public string Password { private get; set; }

        private DocumentUrlCrypto DocumentUrlEncryptor
        {
            get
            {
                if (_documentUrlEncryptor == null)
                {
                    if (Password.IsNullOrEmpty())
                    {
                        throw new FilestoreException("Filestore password not set");
                    }

                    _documentUrlEncryptor = new DocumentUrlCrypto(Password);
                }

                return _documentUrlEncryptor;
            }
        }

        public string BuildDocumentUrl(long documentId)
        {
            if (SystemId.IsNullOrEmpty())
            {
                throw new FilestoreException("Filestore system id not set");
            }

            string documentUrl = SystemId.ToLower() + ":" + documentId.ToString("D20");
            string encryptedDocumentUrl = DocumentUrlEncryptor.EncryptDocumentUrl(documentUrl);

            return encryptedDocumentUrl;
        }
    }
}
