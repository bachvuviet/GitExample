﻿using System;
using System.Security.Cryptography;

namespace Fnz.Framework.Filestore.Common
{
    public class DocumentUrlCrypto
    {
        private readonly SymmetricAlgorithm _symmetricAlgorithm;

        public DocumentUrlCrypto(string password)
        {
            _symmetricAlgorithm = new DESCryptoServiceProvider();
            _symmetricAlgorithm.Key = GenerateKey(8, password);
            _symmetricAlgorithm.IV = GenerateKey(8, "openwrap");
        }

        public string EncryptDocumentUrl(string documentUrl)
        {
            lock (_symmetricAlgorithm)
            {
                var encryptedBytes = CryptoMemoryStream.Encrypt(documentUrl, _symmetricAlgorithm);
                var encryptedDocumentUrl = Convert.ToBase64String(encryptedBytes);
                encryptedDocumentUrl = encryptedDocumentUrl.Replace('+', '-');
                encryptedDocumentUrl = encryptedDocumentUrl.Replace('/', '_');                
                return encryptedDocumentUrl;
            }
        }

        public string DecryptDocumentUrl(string encryptedDocumentUrl)
        {
            lock (_symmetricAlgorithm)
            {
                encryptedDocumentUrl = encryptedDocumentUrl.Replace('-', '+');
                encryptedDocumentUrl = encryptedDocumentUrl.Replace('_', '/');
                var encryptedBytes = Convert.FromBase64String(encryptedDocumentUrl);
                var documentUrl = CryptoMemoryStream.Decrypt(encryptedBytes, _symmetricAlgorithm);

                return documentUrl;
            }
        }

        private static byte[] GenerateKey(int size, string password)
        {
            byte[] salt = new byte[] { 23, 34, 36, 71, 164, 5, 78, 34 };
            var deriveBytes = new Rfc2898DeriveBytes(password, salt);
            var key = deriveBytes.GetBytes(size);

            return key;
        }
    }
}
