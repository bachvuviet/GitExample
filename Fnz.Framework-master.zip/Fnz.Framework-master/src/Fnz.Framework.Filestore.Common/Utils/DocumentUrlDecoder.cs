﻿using System;
using Castle.Core.Logging;

namespace Fnz.Framework.Filestore.Common
{
    public interface IDocumentUrlDecoder
    {
        long DecodeDocumentUrl(string documentUrl);
    }

    public class DocumentUrlDecoder : IDocumentUrlDecoder
    {
        private const int SystemIdPartIndex = 0;
        private const int DocumentIdPartIndex = 1;
        private DocumentUrlCrypto _documentUrlCrytpo;

        private ILogger _logger = NullLogger.Instance;

        public DocumentUrlDecoder()
        {
        }

        public DocumentUrlDecoder(IFilestoreUrlConfiguration filestoreUrlConfiguration)
        {
            SystemId = filestoreUrlConfiguration.SystemId;
            Password = filestoreUrlConfiguration.Password;            
        }

        public ILogger Logger
        {
            set { _logger = value; }
        }

        public string SystemId { get; set; }

        public string Password { get; set; }

        private DocumentUrlCrypto DocumentUrlCrypto
        {
            get
            {
                if (_documentUrlCrytpo == null)
                {
                    if (Password.IsNullOrEmpty())
                    {
                        throw new FilestoreException("Filestore password not set");
                    }

                    _documentUrlCrytpo = new DocumentUrlCrypto(Password);
                }

                return _documentUrlCrytpo;
            }
        }

        public long DecodeDocumentUrl(string documentUrl)
        {
            string[] parts = GetParts(documentUrl);

            long documentId;
            if (long.TryParse(parts[DocumentIdPartIndex], out documentId) == false)
            {
                throw new InvalidDocumentIdException(documentUrl);
            }

            string systemId = parts[SystemIdPartIndex];
            if (systemId.IsNullOrEmpty() || !systemId.Equals(SystemId, StringComparison.CurrentCultureIgnoreCase))
            {
                throw new InvalidDocumentIdException(documentUrl);
            }

            return documentId;
        }

        private string[] GetParts(string documentUrl)
        {
            string unencryptedDocumentUrl;
            try
            {
                unencryptedDocumentUrl = DocumentUrlCrypto.DecryptDocumentUrl(documentUrl);
            }
            catch (Exception e)
            {
                _logger.Warn("Failed to get document id from document url: " + e.Message);
                throw new InvalidDocumentIdException(documentUrl);
            }

            var parts = unencryptedDocumentUrl.Split(':');

            if (parts.Length != 2)
            {
                throw new InvalidDocumentIdException(documentUrl);
            }

            return parts;
        }
    }
}
