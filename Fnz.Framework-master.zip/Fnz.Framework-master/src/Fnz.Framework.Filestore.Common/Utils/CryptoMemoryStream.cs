﻿using System.IO;
using System.Security.Cryptography;

namespace Fnz.Framework.Filestore.Common
{
    internal static class CryptoMemoryStream
    {
        // Encrypt the string.
        public static byte[] Encrypt(string plainText, SymmetricAlgorithm key)
        {
            // Create a memory stream.
            var ms = new MemoryStream();

            // Create a CryptoStream using the memory stream and the 
            // CSP DES key.  
            var encStream = new CryptoStream(ms, key.CreateEncryptor(), CryptoStreamMode.Write);

            // Create a StreamWriter to write a string
            // to the stream.
            var sw = new StreamWriter(encStream);

            // Write the plaintext to the stream.
            sw.WriteLine(plainText);

            // Close the StreamWriter and CryptoStream.
            sw.Close();
            encStream.Close();

            // Get an array of bytes that represents
            // the memory stream.
            byte[] buffer = ms.ToArray();

            // Close the memory stream.
            ms.Close();

            // Return the encrypted byte array.
            return buffer;
        }

        // Decrypt the byte array.
        public static string Decrypt(byte[] cypherText, SymmetricAlgorithm key)
        {
            // Create a memory stream to the passed buffer.
            var ms = new MemoryStream(cypherText);

            // Create a CryptoStream using the memory stream and the 
            // CSP DES key. 
            var encStream = new CryptoStream(ms, key.CreateDecryptor(), CryptoStreamMode.Read);

            // Create a StreamReader for reading the stream.
            var sr = new StreamReader(encStream);

            // Read the stream as a string.
            string val = sr.ReadLine();

            // Close the streams.
            sr.Close();
            encStream.Close();
            ms.Close();

            return val;
        }
    }
}
