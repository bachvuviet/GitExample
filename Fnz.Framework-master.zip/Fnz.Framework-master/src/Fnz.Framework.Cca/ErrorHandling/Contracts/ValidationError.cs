﻿using System;
using System.Collections.Generic;
using Fnz.Api.Errors;

namespace Fnz.Framework.Cca.ErrorHandling.Contracts
{
    public class ValidationError
    {
        public ValidationError()
        {
            this.Parameters = new List<ErrorParameter>();
        }

        public ValidationError(ErrorCode errorCode)
        {
            this.ErrorCode = errorCode.Id;
            this.UserMessage = errorCode.Description;
            this.Parameters = new List<ErrorParameter>();
        }

        /// <summary>
        /// Property associated to validation error 
        /// </summary>
        public string Property { get; set; }

        /// <summary>
        /// Error Code that describes validation error
        /// </summary>
        public int ErrorCode { get; set; }

        /// <summary>
        /// User friendly message
        /// </summary>
        public string UserMessage { get; set; }

        /// <summary>
        /// Collection of error parameters
        /// </summary>
        public List<ErrorParameter> Parameters { get; set; }

        public override string ToString()
        {
            string message = string.Format("ErrorCode={0}", ErrorCode);

            if (!string.IsNullOrEmpty(UserMessage))
            {
                message += string.Format(", UserMessage={0}", UserMessage);
            }

            if (!string.IsNullOrEmpty(Property))
            {
                message += string.Format(", Property={0}", Property);
            }

            if (Parameters != null && Parameters.Count > 0)
            {
                message += string.Format(", Parameters=[{{{0}}}]", string.Join("}, {", Parameters));
            }

            return message;
        }
    }
}