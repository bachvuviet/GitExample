﻿using System;
using System.Collections.Generic;

namespace Fnz.Framework.Cca.ErrorHandling.Contracts
{
    /// <summary>
    /// Defines format for faulted http response messages
    /// </summary>
    public class ErrorContract
    {
        public int ErrorCode { get; set; }

        public string UserMessage { get; set; }

        public string DeveloperMessage { get; set; }

        public string DocumentationUrl { get; set; }

        public int? LogId { get; set; }

        public List<ValidationError> ValidationErrors { get; set; }

        public List<ErrorParameter> Parameters { get; set; }

        public override string ToString()
        {
            string message = string.Format("ErrorCode={0}", ErrorCode);

            if (!string.IsNullOrEmpty(UserMessage))
            {
                message += string.Format(", UserMessage={0}", UserMessage);
            }

            if (!string.IsNullOrEmpty(DeveloperMessage))
            {
                message += string.Format(", DeveloperMessage={0}", DeveloperMessage);
            }

            if (!string.IsNullOrEmpty(DocumentationUrl))
            {
                message += string.Format(", DocumentationUrl={0}", DocumentationUrl);
            }

            if (LogId.HasValue)
            {
                message += string.Format(", LogId={0}", LogId.Value);
            }

            if (ValidationErrors != null && ValidationErrors.Count > 0)
            {
                message += string.Format(", ValidationErrors=[{{{0}}}]", string.Join("}, {", ValidationErrors));
            }

            if (Parameters != null && Parameters.Count > 0)
            {
                message += string.Format(", Parameters=[{{{0}}}]", string.Join("}, {", Parameters));
            }

            return message;
        }
    }
}