﻿using System;
using System.Net;
using Fnz.Framework.Cca.ErrorHandling.Contracts;

namespace Fnz.Framework.Cca.ErrorHandling.Exceptions
{
    public abstract class ErrorReferenceException : Exception
    {
        protected ErrorReferenceException(ErrorContract errorContract, HttpStatusCode statusCode)
        {
            this.StatusCode = statusCode;
            
            this.ErrorContract = errorContract;
        }

        protected ErrorReferenceException(ErrorContract errorContract, HttpStatusCode statusCode,
            Exception innerException): base(null, innerException)
        {
            this.StatusCode = statusCode;
            this.ErrorContract = errorContract;
        }

        public HttpStatusCode StatusCode { get; set; }

        public ErrorContract ErrorContract { get; set; }

        public override string Message
        {
            get
            {
                return base.Message + string.Format(" StatusCode={0}, ErrorContract={{{1}}}", StatusCode, ErrorContract);
            }
        }
    }
}