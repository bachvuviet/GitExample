﻿using System.Net;
using Fnz.Api.Errors;
using Fnz.Framework.Cca.ErrorHandling.Contracts;

namespace Fnz.Framework.Cca.ErrorHandling.Exceptions
{
    /// <summary>
    /// Occurs when authentication is required and has failed or has not been provided
    /// </summary>
    public class BadRequestException : ErrorReferenceException
    {
        public BadRequestException(ErrorCode errorCode)
            : base(CreateContract(errorCode), HttpStatusCode.BadRequest)
        {
        }

        private static ErrorContract CreateContract(ErrorCode errorCode)
        {
            return new ErrorContract
            {
                ErrorCode = errorCode.Id,
                DeveloperMessage = errorCode.Description,
                UserMessage = errorCode.Description
            };
        }
    }
}