﻿using System.Net;
using Fnz.Api.Errors;
using Fnz.Framework.Cca.ErrorHandling.Contracts;

namespace Fnz.Framework.Cca.ErrorHandling.Exceptions
{
    /// <summary>
    /// Occurs when authentication is required and has failed or has not been provided
    /// </summary>
    public class AuthenticationException : ErrorReferenceException
    {
        public AuthenticationException(ErrorCode errorCode)
            : base(CreateContract(errorCode), HttpStatusCode.Unauthorized)
        {
        }

        private static ErrorContract CreateContract(ErrorCode errorCode)
        {
            return new ErrorContract
            {
                ErrorCode = errorCode.Id,
                DeveloperMessage = errorCode.Description,
                UserMessage = errorCode.Description
            };
        }
    }
}