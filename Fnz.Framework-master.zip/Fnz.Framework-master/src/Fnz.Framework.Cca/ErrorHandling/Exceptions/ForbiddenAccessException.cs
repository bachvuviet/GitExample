﻿using System;
using System.Linq;
using System.Net;
using Fnz.Api.Errors;
using Fnz.Framework.Cca.ErrorHandling.Contracts;

namespace Fnz.Framework.Cca.ErrorHandling.Exceptions
{
    /// <summary>
    /// Occurs when caller is attempting to access restricted content
    /// </summary>
    public class ForbiddenAccessException : ErrorReferenceException
    {
        public ForbiddenAccessException(ErrorCode errorCode, string userMsg, ErrorParameter[] parameters) : base(CreateContract(errorCode, userMsg, parameters), HttpStatusCode.Forbidden)
        {
        }
        
        public ForbiddenAccessException(ErrorCode errorCode, string userMsg, ErrorParameter[] parameters, Exception innerException) : base(CreateContract(errorCode, userMsg, parameters), HttpStatusCode.Forbidden, innerException)
        {
        }

        private static ErrorContract CreateContract(ErrorCode errorCode, string userMsg, ErrorParameter[] parameters)
        {
            return new ErrorContract
            {
                ErrorCode = errorCode.Id,
                DeveloperMessage = errorCode.Description,
                UserMessage = userMsg,
                Parameters = parameters.ToList()
            };
        }
    }
}