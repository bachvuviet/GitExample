﻿using System.Collections.Generic;
using System.Net;
using Fnz.Api.Errors;
using Fnz.Framework.Cca.ErrorHandling.Contracts;

namespace Fnz.Framework.Cca.ErrorHandling.Exceptions
{
    /// <summary>
    /// Use this exception when the inputs are not semantically valid or fail business rules
    /// </summary>
    public class InvalidInputsException : ErrorReferenceException
    {
        public InvalidInputsException(ErrorCode errorCode, string userMsg)
            : base(CreateContract(errorCode, userMsg), (HttpStatusCode)422)
        {
        }

        public InvalidInputsException(ErrorCode errorCode, string userMsg, List<ErrorParameter> parameters)
            : base(CreateContract(errorCode, userMsg, parameters), (HttpStatusCode)422)
        {
        }

        private static ErrorContract CreateContract(ErrorCode errorCode, string userMsg, List<ErrorParameter> parameters)
        {
            return new ErrorContract
            {
                ErrorCode = errorCode.Id,
                DeveloperMessage = errorCode.Description,
                UserMessage = userMsg,
                Parameters = parameters
            };
        }

        private static ErrorContract CreateContract(ErrorCode errorCode, string userMsg)
        {
            return new ErrorContract
            {
                ErrorCode = errorCode.Id,
                DeveloperMessage = errorCode.Description,
                UserMessage = userMsg,
                Parameters = null
            };
        }
    }
}