﻿using System.Linq;
using System.Net;
using Fnz.Api.Errors;
using Fnz.Framework.Cca.ErrorHandling.Contracts;

namespace Fnz.Framework.Cca.ErrorHandling.Exceptions
{
    /// <summary>
    /// Occurs when requested entity can't be found
    /// </summary>
    public class EntityNotFoundException : ErrorReferenceException
    {
        public EntityNotFoundException(ErrorCode errorCode, string userMsg, params ErrorParameter[] entityIdentifier) : base(CreateContract(errorCode, userMsg, entityIdentifier), HttpStatusCode.NotFound)
        {
        }

        public EntityNotFoundException(ErrorCode errorCode, params ErrorParameter[] entityIdentifier) : this(errorCode, errorCode.Description, entityIdentifier)
        {
        }

        private static ErrorContract CreateContract(ErrorCode errorCode, string userMsg, params ErrorParameter[] entityIdentifier)
        {
            return new ErrorContract
            {
                ErrorCode = errorCode.Id,
                DeveloperMessage = errorCode.Description,
                UserMessage = userMsg,
                Parameters = entityIdentifier.ToList()
            };
        }
    }
}