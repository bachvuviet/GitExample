﻿using System.Net;
using Fnz.Api.Errors;
using Fnz.Framework.Cca.ErrorHandling.Contracts;

namespace Fnz.Framework.Cca.ErrorHandling.Exceptions
{
    /// <summary>
    /// Occurs when authentication is required and has failed or has not been provided
    /// </summary>
    public class UnauthorizedException : ErrorReferenceException
    {
        public UnauthorizedException(ErrorCode errorCode) : base(CreateContract(errorCode), HttpStatusCode.Unauthorized)
        {
        }

        private static ErrorContract CreateContract(ErrorCode errorCode)
        {
            return new ErrorContract
            {
                ErrorCode = errorCode.Id,
                DeveloperMessage = errorCode.Description,
                UserMessage = "You're not authorized to make this call"
            };
        }
    }
}