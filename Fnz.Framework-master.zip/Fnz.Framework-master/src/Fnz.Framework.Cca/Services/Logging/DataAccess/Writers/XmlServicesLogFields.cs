namespace Fnz.Framework.Cca.Services.Logging.DataAccess.Writers
{
    public class XmlServicesLogFields
    {
        public const string LogTime = "LogTime";
        public const string Request = "Request";
        public const string Response = "Response";
        public const string Url = "Url";
        public const string UserId = "UserId";
        public const string ServiceName = "ServiceName";
        public const string OperationName = "OperationName";
        public const string Method = "Method";
        public const string ServiceReference = "ServiceReference";
        public const string ResponseTimeInMs = "ResponseTimeInMs";
        public const string StatusCode = "StatusCode";
        public const string RequestId = "RequestId";
        public const string SessionId = "SessionId";
        public const string ApplicationName = "ApplicationName";
        public const string LogGuid = "LogGuid";
        public const string Host = "Host";
        public const string ErrorMessage = "ErrorMessage";
        public const string OnBehalfOf = "OnBehalfOf";
    }
}
