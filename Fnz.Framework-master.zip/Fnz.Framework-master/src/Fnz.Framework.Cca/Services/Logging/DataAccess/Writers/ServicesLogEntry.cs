using System;
using Fnz.Framework.Util.CodeQuality;

namespace Fnz.Framework.Cca.Services.Logging.DataAccess.Writers
{
    [IgnoreNumberOfMethods]
    public class ServicesLogEntry
    {
        public string LogGuid { get; set; }

        public string Method { get; set; }

        public string Url { get; set; }

        public string Request { get; set; }

        public string Response { get; set; }

        public string SessionId { get; set; }

        public int UserId { get; set; }

        public int StatusCode { get; set; }

        public string ErrorMessage { get; set; }

        public DateTime LogTime { get; set; }

        public double ResponseTimeInMs { get; set; }

        public string RequestId { get; set; }

        public string ApplicationName { get; set; }

        public string ServiceName { get; set; }
        
        public string OperationName { get; set; }

        public string ServiceReference { get; set; }

        public string Host { get; set; }

        public string OnBehalfOf { get; set; }

        public string RequestHeaders { get; set; }

        public string ApiKey { get; set; }
    }
}
