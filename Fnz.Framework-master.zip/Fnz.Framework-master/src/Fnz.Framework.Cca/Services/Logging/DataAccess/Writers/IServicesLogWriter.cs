namespace Fnz.Framework.Cca.Services.Logging.DataAccess.Writers
{
    public interface IServicesLogWriter
    {
        void LogRequestReply(ServicesLogEntry entry);
    }
}