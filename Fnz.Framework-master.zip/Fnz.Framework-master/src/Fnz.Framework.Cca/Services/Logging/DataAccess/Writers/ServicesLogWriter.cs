using Fnz.Framework.DataAccess;
using Fnz.Framework.MetaData.Logging.Logging;
using Fnz.Framework.ReadersWriters;

namespace Fnz.Framework.Cca.Services.Logging.DataAccess.Writers
{
    public class ServicesLogWriter : DataAccessBase, IServicesLogWriter
    {
        public ServicesLogWriter() : this(new Dal())
        {
        }

        public ServicesLogWriter(IDataAccess dataAccess) : base(dataAccess)
        {            
        }

        public void LogRequestReply(ServicesLogEntry entry)
        {
            QueryFactory
                .Procedure<InsertServicesLogProcedure>()
                .WithParameters(entry.LogTime, entry.Request, entry.Response, entry.Url, entry.UserId, entry.ServiceName, entry.OperationName, entry.Method, 
                    entry.ServiceReference, (int)entry.ResponseTimeInMs, entry.StatusCode, entry.RequestId, entry.ApplicationName, entry.Host, entry.ErrorMessage, 
                    entry.OnBehalfOf, entry.RequestHeaders, entry.ApiKey)
                .Execute();
        }
    }
}
