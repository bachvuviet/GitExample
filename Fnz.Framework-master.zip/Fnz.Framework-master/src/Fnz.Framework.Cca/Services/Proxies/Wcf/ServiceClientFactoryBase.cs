﻿using System;
using System.ServiceModel;
using System.ServiceModel.Channels;
using Fnz.Framework.Cca.Services.Proxies.DataAccess;
using Fnz.Framework.Util;
using ServiceConfiguration = Fnz.Framework.Cca.Services.Proxies.DataAccess.ServiceConfiguration;

namespace Fnz.Framework.Cca.Services.Proxies.Wcf
{
    public delegate void UseClientDelegate<T>(T client);

    public abstract class ServiceClientFactoryBase<TInterface, TClient>
        where TClient : ClientBase<TInterface>, TInterface
        where TInterface : class
    {
        protected readonly IServiceConfigurationReader ServiceConfigurationReader;                                           

        protected ServiceClientFactoryBase(IServiceConfigurationReader serviceConfigurationReader)
        {
            ServiceConfigurationReader = serviceConfigurationReader;
        }

        protected abstract string ServiceName { get; }

        protected abstract TClient ConstructClient(ServiceConfiguration config, int userId);

        public TClient GetClient(int userId)
        {
            var config = ServiceConfigurationReader.GetServiceConfiguration(ServiceName);
            var client = ConstructClient(config, userId);
            return client;
        }

        public void UseClient(UseClientDelegate<TClient> @delegate, int userId)
        {
            UseClientInternal(@delegate, userId, null);
        }

        public void UseClient(UseClientDelegate<TClient> @delegate, LoggingInformation logInfo)
        {
            Enforce.ArgumentNotNull(() => logInfo, "logInfo");
            UseClientInternal(@delegate, logInfo.UserId, logInfo);
        }

        private void UseClientInternal(UseClientDelegate<TClient> @delegate, int userId, LoggingInformation logInfo)
        {
            var client = GetClient(userId);
            var success = false;
            try
            {
                using (new OperationContextScope(client.InnerChannel))
                {
                    AddLogInfoToCurrentScope(logInfo);
                    @delegate(client);
                }

                client.Close();
                success = true;
            }
            finally
            {
                if (!success)
                {
                    client.Abort();
                }
            }
        }

        private static void AddLogInfoToCurrentScope(LoggingInformation logInfo)
        {
            if (logInfo != null)
            {
                OperationContext.Current.Extensions.Add(logInfo);
            }
        }

        protected static Binding GetBasicHttpServiceBinding(Uri endpointUri)
        {
            var securityMode =
                endpointUri.Scheme.Equals("https") ? BasicHttpSecurityMode.Transport : BasicHttpSecurityMode.None;

            var binding = new BasicHttpBinding(securityMode);
            return binding;
        }
    }
}
