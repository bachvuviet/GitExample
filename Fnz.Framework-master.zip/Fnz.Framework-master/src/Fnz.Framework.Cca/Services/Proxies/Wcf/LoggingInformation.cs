﻿using System;
using System.Diagnostics;
using System.ServiceModel;
using Fnz.Framework.Util;

namespace Fnz.Framework.Cca.Services.Proxies.Wcf
{
    public class LoggingInformation : IExtension<OperationContext>
    {
        private readonly Stopwatch _stopwatch;
        
        public LoggingInformation(Guid requestId, string serviceName)
        {
            _stopwatch = new Stopwatch();
            RequestIdentifier = requestId;
            ServiceName = serviceName;
        }

        public Guid RequestIdentifier { get; private set; }

        public DateTime RequestTime { get; private set; }

        public string RemoteService { get; set; }

        public Uri RemoteUri { get; set; }
        
        public string ServiceName { get; private set; }
        
        public string AccountNumber { get; set; }
        
        public int UserId { get; set; }

        public TimeSpan ResponseTime
        {
            get { return _stopwatch.Elapsed; }
        }
        
        public void StartTimer()
        {
            RequestTime = Clock.Now();
            _stopwatch.Start();
        }

        public void Attach(OperationContext owner)
        {
        }

        public void Detach(OperationContext owner)
        {
        }
    }
}
