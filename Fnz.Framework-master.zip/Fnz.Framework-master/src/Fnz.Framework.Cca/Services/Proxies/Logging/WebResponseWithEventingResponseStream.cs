using System;
using System.IO;
using System.Net;
using Fnz.Services.Proxies.Logging;

namespace Fnz.Framework.Cca.Services.Proxies.Logging
{
    public class WebResponseWithEventingResponseStream : WebResponse
    {
        private readonly WebResponse _internalResponse;
        private EventingReadStream _responseStream;             

        public WebResponseWithEventingResponseStream(WebRequestWithEventingRequestStream request, WebResponse response)
        {
            _internalResponse = response;
            request.AttachReadEventHandlers(this);
            request.SetHttpStatusCode(_internalResponse);
        }

        public EventHandler<EventArgs> BeforeFirstReadEvent { get; set; }

        public EventHandler<EventArgs> AfterLastReadEvent { get; set; }

        public EventHandler<DataEventArgs> ReadEvent { get; set; }   

        public HttpStatusCode ResponseStatus { get; set; }       

        #region base properties

        public override long ContentLength
        {
            get
            {
                return _internalResponse.ContentLength;
            }

            set
            {
                _internalResponse.ContentLength = value;
            }
        }

        public override string ContentType
        {
            get
            {
                return _internalResponse.ContentType;
            }

            set
            {
                _internalResponse.ContentType = value;
            }
        }

        public override WebHeaderCollection Headers
        {
            get
            {
                return _internalResponse.Headers;
            }
        }

        public override bool IsFromCache
        {
            get
            {
                return _internalResponse.IsFromCache;
            }
        }

        public override bool IsMutuallyAuthenticated
        {
            get
            {
                return _internalResponse.IsMutuallyAuthenticated;
            }
        }

        public override Uri ResponseUri
        {
            get
            {
                return _internalResponse.ResponseUri;
            }
        }

        #endregion

        #region base methods

        public override void Close()
        {
            _internalResponse.Close();
        }

        public override object InitializeLifetimeService()
        {
            return _internalResponse.InitializeLifetimeService();
        }

        #endregion

        public override Stream GetResponseStream()
        {
            _responseStream = new EventingReadStream(_internalResponse.GetResponseStream());
            _responseStream.AfterLastReadEvent += AfterLastReadEvent;
            _responseStream.BeforeFirstReadEvent += BeforeFirstReadEvent;
            _responseStream.ReadEvent += ReadEvent;
            return _responseStream;
        }
    }
}
