using System;
using System.IO;
using Fnz.Services.Proxies.Logging;

namespace Fnz.Framework.Cca.Services.Proxies.Logging
{
    public class EventingReadStream : Stream
    {
        private readonly Stream _internalStream;
        private bool _firstRead;
        private bool _isClosed;

        public EventingReadStream(Stream streamToEvent)
        {
            _internalStream = streamToEvent;
            _firstRead = true;
            _isClosed = false;
        }

        public event EventHandler<EventArgs> AfterLastReadEvent;

        public event EventHandler<EventArgs> BeforeFirstReadEvent;

        public event EventHandler<DataEventArgs> ReadEvent;

        public override bool CanWrite
        {
            get { return _internalStream.CanWrite; }
        }

        public override bool CanRead
        {
            get { return _internalStream.CanRead; }
        }

        public override bool CanSeek
        {
            get { return _internalStream.CanSeek; }
        }

        public override long Length
        {
            get { return _internalStream.Length; }
        }

        public override long Position
        {
            get
            {
                return _internalStream.Position;
            }

            set
            {
                _internalStream.Position = value;
                if (value == 0 && !_firstRead)
                {
                    OnBeforeFirstReadEvent();
                }
            }
        }

        protected void OnBeforeFirstReadEvent()
        {
            new EventArgs().Raise(this, BeforeFirstReadEvent);
        }

        protected void OnReadEvent(byte[] buffer, int offset, int bytesRead)
        {
            new DataEventArgs(buffer, offset, bytesRead).Raise(this, ReadEvent);
        }

        protected void OnAfterLastReadEvent()
        {
            new EventArgs().Raise(this, AfterLastReadEvent);
        }

        public override void Write(byte[] buffer, int offset, int count)
        {
            _internalStream.Write(buffer, offset, count);
        }

        public override int Read(byte[] buffer, int offset, int count)
        {
            if (_firstRead)
            {
                OnBeforeFirstReadEvent();
                _firstRead = false;
            }

            int readBytes = _internalStream.Read(buffer, offset, count);
            OnReadEvent(buffer, offset, readBytes);

            return readBytes;
        }

        public override void SetLength(long value)
        {
            _internalStream.SetLength(value);
        }

        public override void Flush()
        {
            _internalStream.Flush();
        }

        public override void Close()
        {
            if (_isClosed)
            {
                return;
            }

            _internalStream.Close();
            if (_firstRead)
            {
                OnBeforeFirstReadEvent();
                _firstRead = false;
            }

            OnAfterLastReadEvent();
            _isClosed = true;
        }

        public override long Seek(long offset, SeekOrigin origin)
        {
            long returnValue = _internalStream.Seek(offset, origin);
            if (offset == 0 && origin == SeekOrigin.Begin && !_firstRead)
            {
                OnBeforeFirstReadEvent();
            }
            
            return returnValue;
        }
    }
}
