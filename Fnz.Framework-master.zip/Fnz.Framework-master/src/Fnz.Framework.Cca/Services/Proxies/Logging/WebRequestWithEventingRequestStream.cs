using System;
using System.IO;
using System.Net;
using System.Net.Cache;
using System.Runtime.Remoting;
using Fnz.Services.Proxies.Logging;

namespace Fnz.Framework.Cca.Services.Proxies.Logging
{
    public class WebRequestWithEventingRequestStream : WebRequest
    {
        private readonly WebRequest _internalRequest;

        public WebRequestWithEventingRequestStream(WebRequest baseRequest)
        {
            _internalRequest = baseRequest;
        }

        public HttpStatusCode ResponseStatus { get; set; }

        public EventHandler<EventArgs> BeforeFirstWriteEvent { get; set; }

        public EventHandler<EventArgs> AfterLastWriteEvent { get; set; }

        public EventHandler<DataEventArgs> WriteEvent { get; set; }

        public EventHandler<EventArgs> BeforeFirstReadEvent { get; set; }

        public EventHandler<EventArgs> AfterLastReadEvent { get; set; }

        public EventHandler<DataEventArgs> ReadEvent { get; set; }

        #region base properties
        public override RequestCachePolicy CachePolicy
        {
            get
            {
                return _internalRequest.CachePolicy;
            }

            set
            {
                _internalRequest.CachePolicy = value;
            }
        }

        public override string ConnectionGroupName
        {
            get
            {
                return _internalRequest.ConnectionGroupName;
            }

            set
            {
                _internalRequest.ConnectionGroupName = value;
            }
        }

        public override long ContentLength
        {
            get
            {
                return _internalRequest.ContentLength;
            }

            set
            {
                _internalRequest.ContentLength = value;
            }
        }

        public override string ContentType
        {
            get
            {
                return _internalRequest.ContentType;
            }

            set
            {
                _internalRequest.ContentType = value;
            }
        }

        public override ICredentials Credentials
        {
            get
            {
                return _internalRequest.Credentials;
            }

            set
            {
                _internalRequest.Credentials = value;
            }
        }

        public override WebHeaderCollection Headers
        {
            get
            {
                return _internalRequest.Headers;
            }

            set
            {
                _internalRequest.Headers = value;
            }
        }

        public override string Method
        {
            get
            {
                return _internalRequest.Method;
            }

            set
            {
                _internalRequest.Method = value;
            }
        }

        public override bool PreAuthenticate
        {
            get
            {
                return _internalRequest.PreAuthenticate;
            }

            set
            {
                _internalRequest.PreAuthenticate = value;
            }
        }

        public override IWebProxy Proxy
        {
            get
            {
                return _internalRequest.Proxy;
            }

            set
            {
                _internalRequest.Proxy = value;
            }
        }

        public override Uri RequestUri
        {
            get
            {
                return _internalRequest.RequestUri;
            }
        }

        public override int Timeout
        {
            get
            {
                return _internalRequest.Timeout;
            }

            set
            {
                _internalRequest.Timeout = value;
            }
        }

        public override bool UseDefaultCredentials
        {
            get
            {
                return _internalRequest.UseDefaultCredentials;
            }

            set
            {
                _internalRequest.UseDefaultCredentials = value;
            }
        }
        #endregion

        public HttpWebRequest HttpRequest
        {
            get { return _internalRequest as HttpWebRequest; }
        }

        #region base methods

        public override void Abort()
        {
            _internalRequest.Abort();
        }

        public override IAsyncResult BeginGetRequestStream(AsyncCallback callback, object state)
        {
            return _internalRequest.BeginGetRequestStream(callback, state);
        }

        public override IAsyncResult BeginGetResponse(AsyncCallback callback, object state)
        {
            return _internalRequest.BeginGetResponse(callback, state);
        }

        public override ObjRef CreateObjRef(Type requestedType)
        {
            return _internalRequest.CreateObjRef(requestedType);
        }

        public override Stream EndGetRequestStream(IAsyncResult asyncResult)
        {
            var requestStream = new EventingWriteStream(_internalRequest.EndGetRequestStream(asyncResult));
            AttachWriteEventHandlers(requestStream);

            return requestStream;
        }

        public override WebResponse EndGetResponse(IAsyncResult asyncResult)
        {
            return _internalRequest.EndGetResponse(asyncResult);
        }

        public override object InitializeLifetimeService()
        {
            return _internalRequest.InitializeLifetimeService();
        }

        #endregion

        public override Stream GetRequestStream()
        {
            var requestStream = new EventingWriteStream(_internalRequest.GetRequestStream());
            AttachWriteEventHandlers(requestStream);

            return requestStream;
        }

        public override WebResponse GetResponse()
        {
            return _internalRequest.GetResponse();
        }

        internal void SetHttpStatusCode(WebResponse response)
        {
            var localReponse = (HttpWebResponse)response;
            if (localReponse != null)
            {
                ResponseStatus = localReponse.StatusCode;
            }
        }

        internal void AttachReadEventHandlers(WebResponseWithEventingResponseStream response)
        {
            response.AfterLastReadEvent += AfterLastReadEvent;
            response.BeforeFirstReadEvent += BeforeFirstReadEvent;
            response.ReadEvent += ReadEvent;
        }

        private void AttachWriteEventHandlers(EventingWriteStream stream)
        {
            stream.AfterLastWriteEvent += AfterLastWriteEvent;
            stream.BeforeFirstWriteEvent += BeforeFirstWriteEvent;
            stream.WriteEvent += WriteEvent;
        }
    }
}
