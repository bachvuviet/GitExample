using System;
using Fnz.Framework.Cca.Security;
using Fnz.Framework.Cca.Services.Proxies.Logging.DataAccess;
using Fnz.Framework.DataAccess.Logging;

namespace Fnz.Framework.Cca.Services.Proxies.Logging
{
    public interface IRequestLogger
    {
        string GetNewLogIdentifier(string serviceName);

        void Log(string serviceName, HttpRequestInformation request);

        void LogException(Exception ex, HttpRequestInformation request);
    }

    public class DatabaseRequestLogger : IRequestLogger
    {
        private readonly IXmlLogWriter _xmlLogWriter;
        private readonly IExceptionLogger _exceptionLogger;

        public DatabaseRequestLogger(IXmlLogWriter xmlLogWriter)
        {
            _xmlLogWriter = xmlLogWriter;
            ClientId = SystemUser.Id;

            _exceptionLogger = new ExceptionDatabaseLogger();
        }        

        public int ClientId { get; set; }

        public string GetNewLogIdentifier(string serviceName)
        {
            var requestId = Guid.NewGuid().ToString();
            
            _xmlLogWriter.AddLogRecord(requestId, ClientId, serviceName, string.Empty);

            return requestId;
        }

        public void Log(string serviceName, HttpRequestInformation request)
        {
            var logContext = new ServiceRequestContext
                              {
                                  RequestId = request.RequestId,
                                  UserId = ClientId,
                                  ServiceName = serviceName,
                                  Request = request.Request,
                                  RequestUri = request.RequestUri.ToString(),
                                  Response = request.Response,
                                  ResponseStatus = request.StatusCode,
                                  ResponseTime = request.ResponseTime, 
                              };

            _xmlLogWriter.LogCompletedRequestResponse(logContext, request.RequestTime);
        }

        public void LogException(Exception ex, HttpRequestInformation request)
        {
            _exceptionLogger.LogException(ex, "RequestId: {0}, Url: {1}".FormatWith(request.RequestId, request.RequestUri));
        }
    }
}
