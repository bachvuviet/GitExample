using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using Fnz.Services.Proxies.Logging;

namespace Fnz.Framework.Cca.Services.Proxies.Logging
{
    public class RequestEventObserver
    {
        private readonly IRequestLogger _logger;
        private readonly HttpRequestInformation _logData;
        private readonly Stopwatch _timer;

        private MemoryStream _requestStream;
        private MemoryStream _responseStream;
        private WebRequestWithEventingRequestStream _request;

        public RequestEventObserver(IRequestLogger logger)
            : this(logger, null)
        {
        }

        public RequestEventObserver(IRequestLogger logger, string requestId)
        {
            _logger = logger;
            _logData = new HttpRequestInformation();
            _timer = new Stopwatch();

            if (!string.IsNullOrEmpty(requestId))
            {
                _logData.RequestId = requestId;
            }
        }

        public string ServiceName { get; set; }

        public string GetNextRequestId()
        {
            _logData.RequestId = _logger.GetNewLogIdentifier(ServiceName);
            return _logData.RequestId;
        }

        public void AttachToRequest(WebRequestWithEventingRequestStream request)
        {
            _request = request;
            _logData.RequestUri = request.RequestUri;

            AttachEventHandlers();
        }

        private void ClearRequestStream(object sender, EventArgs e)
        {
            _requestStream = new MemoryStream();
            RecordTimeAndStartTimer();
        }

        private void RecordTimeAndStartTimer()
        {
            if (string.IsNullOrEmpty(_logData.RequestId))
            {
                _logData.RequestId = _logger.GetNewLogIdentifier(ServiceName);
            }

            _logData.RequestTime = DateTime.Now;
            _timer.Start();
        }

        private void PopulateRequestDetails(object sender, EventArgs e)
        {
            _requestStream.Position = 0;
            _logData.Request = ReadStreamContent(_requestStream);
            _requestStream.Close();
        }

        private void ClearResponseStream(object sender, EventArgs e)
        {
            _responseStream = new MemoryStream();
        }

        private void PopulateAndLogResponseDetails(object sender, EventArgs e)
        {
            _responseStream.Position = 0;
            _logData.Response = ReadStreamContent(_responseStream);
            _responseStream.Close();

            _logData.StatusCode = _request.ResponseStatus;

            LogDetailsAndDetachHanders();
        }

        internal void LogException(Exception ex)
        {
            LogDetailsAndDetachHanders();
            _logger.LogException(ex, _logData);
        }

        public void ProcessException(Exception ex)
        {
            var webException = ex as WebException;

            if (webException != null && webException.Response != null && (webException.Response as HttpWebResponse != null))
            {
                LogFailureResponse((HttpWebResponse)webException.Response);
                return;
            }

            LogException(ex);
        }

        internal void LogFailureResponse(HttpWebResponse response)
        {
            var content = string.Empty;
            
            var contentStream = response.GetResponseStream();
            if (contentStream != null)
            {
                using (var reader = new StreamReader(contentStream))
                {
                    content = reader.ReadToEnd();
                }
            }

            LogFailureResponse(response.StatusCode, content);
        }

        private void LogFailureResponse(HttpStatusCode statusCode, string responseContent)
        {
            _logData.Response = responseContent;
            _logData.StatusCode = statusCode;
            LogDetailsAndDetachHanders();
        }

        private void LogDetailsAndDetachHanders()
        {
            _logData.ResponseTime = _timer.Elapsed;
            _logger.Log(ServiceName, _logData);

            DetachEventHandlers();
        }

        private void WriteToResponseStream(object sender, DataEventArgs e)
        {
            _responseStream.Write(e.Buffer, e.Offset, e.BytesRead);
        }

        private void WriteToRequestStream(object sender, DataEventArgs e)
        {
            _requestStream.Write(e.Buffer, e.Offset, e.BytesRead);
        }

        private void AttachEventHandlers()
        {
            _request.BeforeFirstWriteEvent += ClearRequestStream;
            _request.WriteEvent += WriteToRequestStream;
            _request.AfterLastWriteEvent += PopulateRequestDetails;

            _request.BeforeFirstReadEvent += ClearResponseStream;
            _request.ReadEvent += WriteToResponseStream;
            _request.AfterLastReadEvent += PopulateAndLogResponseDetails;
        }

        private void DetachEventHandlers()
        {
            _request.BeforeFirstWriteEvent -= ClearRequestStream;
            _request.WriteEvent -= WriteToRequestStream;
            _request.AfterLastWriteEvent -= PopulateRequestDetails;

            _request.BeforeFirstReadEvent -= ClearResponseStream;
            _request.ReadEvent -= WriteToResponseStream;
            _request.AfterLastReadEvent -= PopulateAndLogResponseDetails;
        }

        private static string ReadStreamContent(Stream stream)
        {
            using (var reader = new StreamReader(stream))
            {
                return reader.ReadToEnd();
            }
        }
    }
}
