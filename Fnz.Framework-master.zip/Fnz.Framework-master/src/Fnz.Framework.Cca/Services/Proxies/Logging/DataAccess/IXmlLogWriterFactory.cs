﻿namespace Fnz.Framework.Cca.Services.Proxies.Logging.DataAccess
{
    public interface IXmlLogWriterFactory
    {
        IXmlLogWriter Create();
    }
}
