﻿using System;
using Fnz.Services.Proxies.Logging;

namespace Fnz.Framework.Cca.Services.Proxies.Logging.DataAccess
{
    public interface IXmlLogWriter
    {
        void LogXmlRequest(string requestId, int userId, string serviceName, string request, string accountId);

        void LogXmlRequest(string requestId, string serviceName, string request);

        void LogXmlResponse(string requestId, int status, string response, long responseTime);

        void LogRequest(ServiceRequestContext context);

        void LogResponse(ServiceRequestContext context);

        void LogCompletedRequestResponse(ServiceRequestContext context, DateTime logTime);

        void AddLogRecord(string requestId, int clientId, string serviceName, string remoteServiceName);

        void LogServiceAttempt(ServiceAttempt attempt);
    }
}
