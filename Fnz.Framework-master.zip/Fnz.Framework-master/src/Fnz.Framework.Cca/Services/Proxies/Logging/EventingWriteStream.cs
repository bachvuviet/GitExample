using System;
using System.IO;
using Fnz.Services.Proxies.Logging;

namespace Fnz.Framework.Cca.Services.Proxies.Logging
{
    public class EventingWriteStream : Stream
    {
        private readonly Stream _internalStream;
        private bool _firstWrite;

        public EventingWriteStream(Stream streamToEvent)
        {
            _internalStream = streamToEvent;
            _firstWrite = true;
        }

        public event EventHandler<EventArgs> AfterLastWriteEvent;

        public event EventHandler<EventArgs> BeforeFirstWriteEvent;

        public event EventHandler<DataEventArgs> WriteEvent;

        public override bool CanWrite
        {
            get { return _internalStream.CanWrite; }
        }

        public override bool CanRead
        {
            get { return _internalStream.CanRead; }
        }

        public override bool CanSeek
        {
            get { return _internalStream.CanSeek; }
        }

        public override long Length
        {
            get { return _internalStream.Length; }
        }

        public override long Position
        {
            get { return _internalStream.Position; }
            set { _internalStream.Position = value; }
        }

        protected void OnBeforeFirstWriteEvent()
        {
            new EventArgs().Raise(this, BeforeFirstWriteEvent);
        }

        protected void OnWriteEvent(byte[] buffer, int offset, int bytesRead)
        {
            new DataEventArgs(buffer, offset, bytesRead).Raise(this, WriteEvent);
        }

        protected void OnAfterLastWriteEvent()
        {
            new EventArgs().Raise(this, AfterLastWriteEvent);
        }

        public override void Write(byte[] buffer, int offset, int count)
        {
            if (_firstWrite)
            {
                OnBeforeFirstWriteEvent();
                _firstWrite = false;
            }

            _internalStream.Write(buffer, offset, count);
            OnWriteEvent(buffer, offset, count);
        }

        public override int Read(byte[] buffer, int offset, int count)
        {
            return _internalStream.Read(buffer, offset, count);
        }

        public override void SetLength(long value)
        {
            _internalStream.SetLength(value);
        }

        public override void Flush()
        {
            _internalStream.Flush();
        }

        public override void Close()
        {
            _internalStream.Close();

            if (!_firstWrite)
            {
                OnAfterLastWriteEvent();
            }
        }

        public override long Seek(long offset, SeekOrigin origin)
        {
            var returnValue = _internalStream.Seek(offset, origin);
            if (offset == 0 && origin == SeekOrigin.Begin && !_firstWrite)
            {
                OnBeforeFirstWriteEvent();
            }

            return returnValue;
        }        
    }
}
