﻿using System;
using System.Net;
using Fnz.Framework.Cca.Services.Proxies.Wcf;

namespace Fnz.Framework.Cca.Services.Proxies.Logging
{
    public class ServiceRequestContext
    {
        public ServiceRequestContext()
        {
        }

        public ServiceRequestContext(LoggingInformation logInfo)
        {
            RequestId = logInfo.RequestIdentifier.ToString();
            UserId = logInfo.UserId;
            ServiceName = logInfo.ServiceName;
            RequestUri = logInfo.RemoteUri.ToString();
            SoapAction = logInfo.RemoteService;
        }

        public string RequestId { get; set; }

        public int UserId { get; set; }

        public string ServiceName { get; set; }

        public string RequestUri { get; set; }

        public string SoapAction { get; set; }

        public string Request { get; set; }

        public string Response { get; set; }

        public TimeSpan ResponseTime { get; set; }

        public HttpStatusCode ResponseStatus { get; set; }

        public string ClientIp { get; set; }

        public string ServerIp { get; set; }

        public string UserAgent { get; set; }

        public Exception Failure { get; set; }
    }
}
