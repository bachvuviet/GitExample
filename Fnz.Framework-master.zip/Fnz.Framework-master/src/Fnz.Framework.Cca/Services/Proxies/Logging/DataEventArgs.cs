using System;

namespace Fnz.Services.Proxies.Logging
{
    public class DataEventArgs : EventArgs
    {
        private readonly byte[] _buffer;
        private readonly int _bytesRead;
        private readonly int _offset;

        public DataEventArgs(byte[] buffer, int offset, int count)
        {
            _buffer = buffer;
            _offset = offset;
            _bytesRead = count;
        }

        public byte[] Buffer
        {
            get { return _buffer; }
        }

        public int Offset
        {
            get { return _offset; }
        }

        public int BytesRead
        {
            get { return _bytesRead; }
        }
    }
}
