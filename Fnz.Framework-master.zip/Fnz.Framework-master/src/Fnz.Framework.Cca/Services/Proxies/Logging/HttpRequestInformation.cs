using System;
using System.Net;

namespace Fnz.Framework.Cca.Services.Proxies.Logging
{
    public class HttpRequestInformation
    {
        public string RequestId { get; set; }

        public Uri RequestUri { get; set; }

        public string Request { get; set; }

        public string Response { get; set; }

        public HttpStatusCode StatusCode { get; set; }

        public TimeSpan ResponseTime { get; set; }

        public DateTime RequestTime { get; set; }
    }
}
