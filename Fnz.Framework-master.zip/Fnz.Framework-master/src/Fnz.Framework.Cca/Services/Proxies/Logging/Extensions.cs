﻿using System;
using System.Threading;

namespace Fnz.Framework.Cca.Services.Proxies.Logging
{
    internal static class Extensions
    {
        public static void Raise<TEventArgs>(this TEventArgs args, object sender, EventHandler<TEventArgs> eventDelegate) where TEventArgs : EventArgs
        {
            var handler = Interlocked.CompareExchange(ref eventDelegate, null, null);

            if (handler != null)
            {
                handler(sender, args);
            }
        }
    }
}
