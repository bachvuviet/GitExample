﻿namespace Fnz.Framework.Cca.Services.Proxies.Logging  
{
    public class ServiceAttempt
    {
        public bool Success { get; set; }

        public string RequestIdentifier { get; set; }

        public int ClientId { get; set; }
        
        public string ServiceName { get; set; }
        
        public string ErrorMessage { get; set; }
    }
}
