﻿namespace Fnz.Framework.Cca.Services.Proxies.DataAccess
{
    public class ServiceConfigurationHeader
    {
        public string RequestHeaderName { get; set; }

        public string RequestHeaderValue { get; set; }
    }
}