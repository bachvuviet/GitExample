﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Security.Cryptography.X509Certificates;

namespace Fnz.Framework.Cca.Services.Proxies.DataAccess
{
    public class ServiceConfiguration
    {
        public bool IsStub { get; set; }

        public X509Certificate2 ClientCertificate { get; set; }

        public X509Certificate2Collection ServerCertificates { get; set; }

        public bool KeepAlive { get; set; }

        public int SendTimeout { get; set; }

        public WebProxy Proxy { get; set; }

        public Uri Url { get; set; }

        public string WebServiceName { get; set; }

        public int ServicePointConnectionLimit { get; set; }

        public TimeSpan? EnableAfter { get; set; }

        public TimeSpan? DisableAfter { get; set; }

        public string UserId { get; set; }

        public string Password { get; set; }

        public List<ServiceConfigurationHeader> Headers { get; set; }
    }
}
