﻿namespace Fnz.Framework.Cca.Services.Proxies.DataAccess
{
    public interface IServiceConfigurationReader
    {
        /// <summary>
        /// Load the configuration of the web service identified by the webservicename
        /// </summary>
        /// <param name="messageName">e.g. "finex_PortfolioAnalyserTool"</param>
        /// <returns>the Configuration of that web service</returns>
        ServiceConfiguration GetServiceConfiguration(string messageName);

        /// <summary>
        /// Load the configuration of the web service identified by the webservicename
        /// </summary>
        /// <param name="webservicename">e.g. "finex_PortfolioAnalyserTool"</param>
        /// <param name="cachePeriodInMins">the time that this value should be cached for, or 0 if it is not to be cached</param>
        /// <returns>the Configuration of that web service</returns>
        ServiceConfiguration GetServiceConfiguration(string webservicename, int cachePeriodInMins);
    }  
}