using System;

namespace Fnz.Framework.Cca.Commands
{
    /// <summary>
    /// The name of the parameter as specified in the Paramaters column in the Task row in the database.
    /// This is useful if we want a more meaningful name in the code Vs what is already in the database (and we are not able to change it in the database)
    /// </summary>
    /// <example>
    /// In this example in the Tasks2..Parameters column we have "ClAccountId" but in the code want to use "AccountId"
    /// public class MyLegacyCommand
    /// {
    ///     [TaskParameterAdapter("ClAccountId")] 
    ///     public AccountId { get; set; }
    /// } 
    /// </example>
    public sealed class TaskParameterAdapterAttribute : Attribute
    {
        public TaskParameterAdapterAttribute(string parameterDbName)
        {
            ParameterDbName = parameterDbName;
        }

        public string ParameterDbName { get; set; }
    }
}