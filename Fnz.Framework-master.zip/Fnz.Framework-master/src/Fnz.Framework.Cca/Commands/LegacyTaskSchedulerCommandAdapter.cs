using Castle.Windsor;
using Fnz.Core.Platform.Framework.Commands;
using Fnz.Framework.DataAccess;
using Fnz.Framework.Util;
using Fnz.Framework.Util.Caching;

namespace Fnz.Framework.Cca.Commands
{
    /// <summary>
    /// Allows us to execute a command on the Legacy task schedulers (they expect the method to be executed to one 'RecordSet' argument).
    /// When executed it creates an instance of TCommand and populates its properties with matching values from the RecordSet 
    /// (matching the RecordSet field name to the TCommand property name).
    /// </summary>
    /// <typeparam name="TCommand">the type of command to create an instance of and populate with matching values from the RecordSet.</typeparam>
    public abstract class LegacyTaskSchedulerCommandAdapter<TCommand> 
        where TCommand : class, new()
    {
#pragma warning disable 612, 618
        private readonly MemoryCache _containerCache = new MemoryCache();
#pragma warning restore 612, 618
        private readonly RecordsetToCommandConverter<TCommand> _recordsetToCommandConverter;

        /// <summary>
        /// Constructor for when we are using inside code that does not have a container (for example when executing a task in the old task schedulers)
        /// </summary>
        protected LegacyTaskSchedulerCommandAdapter()
            : this(new RecordsetToCommandConverter<TCommand>())
        {
        }

        /// <summary>
        /// Constructor for when we are using inside code that does not have a container and want to override the recordset converter (for example when executing a task in the old task schedulers)
        /// </summary>
        protected LegacyTaskSchedulerCommandAdapter(RecordsetToCommandConverter<TCommand> recordsetToCommandConverter)
        {
            BootstrapContainer();
            CommandHandler = Container.Resolve<ICommandHandler<TCommand>>();
            _recordsetToCommandConverter = recordsetToCommandConverter;
        }

        protected LegacyTaskSchedulerCommandAdapter(ICommandHandler<TCommand> commandHandler) : this(commandHandler, new RecordsetToCommandConverter<TCommand>())
        {
        }

        protected LegacyTaskSchedulerCommandAdapter(ICommandHandler<TCommand> commandHandler, RecordsetToCommandConverter<TCommand> recordsetToCommandConverter)
        {
            CommandHandler = commandHandler;
            _recordsetToCommandConverter = recordsetToCommandConverter;
        }
        
        public IWindsorContainer Container { get; private set; }

        protected ICommandHandler<TCommand> CommandHandler { get; set; }

        public void Execute(Recordset parameters)
        {
            TCommand command = _recordsetToCommandConverter.CreateCommandFromRecordset(parameters);
            CommandHandler.Execute(command);
        }
       
        private void BootstrapContainer()
        {
            // Note another alternative to having a dictionary of containers would have been to just create a new container each time
            // - in tests this was timed at 500ms, so we could take that approach instead
            var fullName = GetType().FullName;

            if (_containerCache.Contains(fullName))
            {
                Container = _containerCache.Get<IWindsorContainer>(fullName);
            } 
            else
            {
                Container = new WindsorContainer();            
                InstallItemsInContainer();
                _containerCache.Add(fullName, Container, Clock.Now().AddMinutes(30));
            }
        }

        /// <summary>
        /// Implement this to do any bootstrapping of the _container i.e. _container.Install(...);
        /// </summary>
        protected virtual void InstallItemsInContainer()
        {            
        }
    }
}