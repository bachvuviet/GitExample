using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Fnz.Framework.DataAccess;

namespace Fnz.Framework.Cca.Commands
{
    public class RecordsetToCommandConverter<TCommand>
        where TCommand : class, new()
    {
        public virtual TCommand CreateCommandFromRecordset(Recordset parameters) 
        {
            var command = new TCommand();

            foreach (var field in parameters.Fields)
            {
                var name = parameters.Fields.CurrentItem().Name;
                var value = parameters[parameters.Fields.CurrentItem().Name];

                SetCommandPropertyValue(name, value, command);
            }

            return command;
        }

        private void SetCommandPropertyValue(string name, object value, TCommand command)
        {
            var target = typeof(TCommand);
            PropertyInfo prop = target.GetProperty(name) ?? GetPropertyWithMatchingAttribute(target, name);

            if (prop != null)
            {
                var parsedValue = GetValueAsCorrectType(prop, value);
                prop.SetValue(command, parsedValue, null);
            }
        }

        private object GetValueAsCorrectType(PropertyInfo prop, object value)
        {
            if (value.GetType() == typeof(string))
            {
                if (prop.PropertyType == typeof(DateTime))
                {
                    return DateTime.Parse((string)value);
                }
                else if (prop.PropertyType == typeof(int))
                {
                    return Int32.Parse((string)value);
                }
                else if (prop.PropertyType == typeof(long))
                {
                    return Int64.Parse((string)value);
                }
                else if (prop.PropertyType == typeof(decimal))
                {
                    return Decimal.Parse((string)value);
                }
                else if (prop.PropertyType == typeof(float))
                {
                    return float.Parse((string)value);
                }
                else if (prop.PropertyType == typeof(double))
                {
                    return Double.Parse((string)value);
                }
                else if (prop.PropertyType == typeof(bool))
                {
                    return bool.Parse((string) value);
                }
                else if (prop.PropertyType == typeof(byte))
                {
                    return Byte.Parse((string)value);
                }
                else if (prop.PropertyType.IsEnum)
                {
                    return Enum.Parse(prop.PropertyType, (string) value, true);
                }
                else if (prop.PropertyType.IsGenericType && prop.PropertyType.GetGenericTypeDefinition() == typeof(IEnumerable<>))
                {
                    return GetGenericIEnumerableValueAsCorrectType(prop, (string)value);
                } 
            }

            return value;
        }

        private object GetGenericIEnumerableValueAsCorrectType(PropertyInfo prop, string value)
        {
            Type underlyingType = prop.PropertyType.GetGenericArguments()[0];

            if (underlyingType == typeof(DateTime))
            {
                return new List<DateTime>(value.Split(',').Select(DateTime.Parse));
            }
            else if (underlyingType == typeof(int))
            {
                return new List<int>(value.Split(',').Select(Int32.Parse));
            }
            else if (underlyingType == typeof(long))
            {
                return new List<Int64>(value.Split(',').Select(Int64.Parse));
            }
            else if (underlyingType == typeof(decimal))
            {
                return new List<Decimal>(value.Split(',').Select(Decimal.Parse));
            }
            else if (underlyingType == typeof(float))
            {
                return new List<float>(value.Split(',').Select(float.Parse));
            }
            else if (underlyingType == typeof(double))
            {
                return new List<Double>(value.Split(',').Select(Double.Parse));
            }
            else if (underlyingType == typeof(byte))
            {
                return new List<Byte>(value.Split(',').Select(Byte.Parse));
            }

            return null;
        }

        /// <summary>
        /// Iterate over properties to find one with a TaskParameterAdapterAttribute.ParameterDBName == name
        /// </summary>
        private PropertyInfo GetPropertyWithMatchingAttribute(Type target, string name)
        {
            PropertyInfo toRet = null;

            foreach (var propertyInfo in target.GetProperties())
            {
                if (propertyInfo.HasCustomAttribute<TaskParameterAdapterAttribute>())
                {
                    var parameterDbName = ReflectionExtensionMethods.GetCustomAttribute<TaskParameterAdapterAttribute>(propertyInfo).ParameterDbName;

                    if (parameterDbName == name)
                    {
                        toRet = propertyInfo;
                    }
                }
            }

            return toRet;
        }
    }
}
