﻿namespace Fnz.Framework.Cca.DataFlow
{
    /// <summary>
    /// Marker interface for an event publisher
    /// </summary>
    public interface IEventPublisher
    {
    }
}