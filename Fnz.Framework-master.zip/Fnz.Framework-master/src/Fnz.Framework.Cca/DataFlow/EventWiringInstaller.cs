﻿using System;
using System.Reflection;
using Castle.MicroKernel.Registration;
using Castle.MicroKernel.Resolvers.SpecializedResolvers;
using Castle.MicroKernel.SubSystems.Configuration;
using Castle.Windsor;

namespace Fnz.Framework.Cca.DataFlow
{
    /// <summary>
    /// Installs <see cref="IEventListener"/> from given type scope. Listeners are installed base on all interfaces.
    /// Inject IEnumerable of specific <see cref="IEventListener"/> derived interfaces into event publisher.
    /// </summary>
    [Obsolete("Use EventListenersInstaller")]
    public class EventWiringInstaller : IWindsorInstaller
    {
        private readonly Type[] _typeScope;

        public EventWiringInstaller(Assembly assembly) : this(assembly.GetTypes())
        {
        }

        public EventWiringInstaller(params Type[] typeScope)
        {
            _typeScope = typeScope;
        }

        public void Install(IWindsorContainer container, IConfigurationStore store)
        {
            container.Register(Classes.From(_typeScope).BasedOn<IEventListener>().LifestyleTransient().WithService.AllInterfaces());

            container.Kernel.Resolver.AddSubResolver(new CollectionResolver(container.Kernel, true));
        }
    }
}