﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Fnz.Framework.Cca.DataFlow
{
    /// <summary>
    /// Base implementation for event publishing
    /// </summary>
    public abstract class EventPublisher : IEventPublisher
    {
        private readonly IEnumerable<IEventListener> _listeners;

        protected EventPublisher(IEnumerable<IEventListener> listeners)
        {
            _listeners = listeners;
        }

        protected bool AnyListenersAreRegistered
        {
            get
            {
                return _listeners.Any();
            }
        }

        /// <summary>
        /// Use this method to raise notification to certain type of listeners
        /// </summary>
        /// <typeparam name="TListener">listeners to notify</typeparam>
        /// <param name="notifyAction">notification action</param>
        protected void Notify<TListener>(Action<TListener> notifyAction) where TListener : IEventListener
        {
            foreach (TListener listener in _listeners.OfType<TListener>())
            {
                notifyAction(listener);
            }
        }
    }
}