﻿namespace Fnz.Framework.Cca.DataFlow
{
    /// <summary>
    /// Marker interface for loosely coupled event listeners
    /// </summary>
    public interface IEventListener
    {
    }
}