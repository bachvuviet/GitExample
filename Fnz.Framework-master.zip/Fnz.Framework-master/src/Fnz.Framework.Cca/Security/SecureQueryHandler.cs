﻿using Fnz.Core.Platform.Framework;
using Fnz.Framework.Cca.Validation;

namespace Fnz.Framework.Cca.Security
{
    /// <summary>
    /// Decorator that checks user permissions for the command before executing it
    /// </summary>
    /// <typeparam name="TQuery">Query Handler Type</typeparam>
    /// /// <typeparam name="TResult">Query Handler Return Type</typeparam>
    public class SecureQueryHandler<TQuery, TResult> : IQueryHandler<TQuery, TResult>    
    {
        private readonly IQueryHandler<TQuery, TResult> _handler;

        private readonly IPermissionValidator<TQuery> _permissionValidator;

        public SecureQueryHandler(IQueryHandler<TQuery, TResult> handler, IPermissionValidator<TQuery> permissionValidator)
        {
            _handler = handler;
            _permissionValidator = permissionValidator;
        }

        public TResult Execute(TQuery query)
        {
            _permissionValidator.EnsureUserHasPermission();

            return _handler.Execute(query);
        }
    }
}