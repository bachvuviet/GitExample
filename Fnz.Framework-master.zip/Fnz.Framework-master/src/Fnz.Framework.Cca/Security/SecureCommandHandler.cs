﻿using Fnz.Core.Platform.Framework.Commands;
using Fnz.Framework.Cca.Validation;

namespace Fnz.Framework.Cca.Security
{
    /// <summary>
    /// Decorator that checks user permissions for the command before executing it
    /// </summary>
    /// <typeparam name="TCommand">Command Handler Type</typeparam>
    public class SecureCommandHandler<TCommand> : ICommandHandler<TCommand>    
    {
        private readonly ICommandHandler<TCommand> _handler;

        private readonly IPermissionValidator<TCommand> _permissionValidator;

        public SecureCommandHandler(ICommandHandler<TCommand> handler, IPermissionValidator<TCommand> permissionValidator)
        {
            _handler = handler;
            _permissionValidator = permissionValidator;
        }

        public void Execute(TCommand command)
        {
            _permissionValidator.EnsureUserHasPermission();

            _handler.Execute(command);
        }
    }
}