﻿namespace Fnz.Framework.Cca.Security
{
    public interface IPermission
    {
        int Id { get; }

        string Name { get; }   
    }
}