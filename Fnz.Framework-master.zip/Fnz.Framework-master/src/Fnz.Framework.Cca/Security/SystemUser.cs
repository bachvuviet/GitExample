﻿namespace Fnz.Framework.Cca.Security
{
    public static class SystemUser
    {
        public static readonly int Id = 8245;
    }
}