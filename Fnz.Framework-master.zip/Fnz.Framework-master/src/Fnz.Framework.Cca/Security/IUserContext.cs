﻿namespace Fnz.Framework.Cca.Security
{
    public interface IUserContext
    {
        int UserId { get; }

        bool IsCustomerUser { get; }

        string Branch { get; }

        string Company { get; }

        string Network { get; }

        string WrapProvider { get; }

        int JurisdictionId { get; }

        int AdviserId { get; }

        string AdviserCode { get; }

        void EnsureUserHasPermission(IPermission permission);
    }
}