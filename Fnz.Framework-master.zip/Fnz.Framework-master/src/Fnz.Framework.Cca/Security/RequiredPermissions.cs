﻿namespace Fnz.Framework.Cca.Security
{
    public interface IRequiredPermissions
    {
        Permission GetPermissionFor<T>();
    }
}