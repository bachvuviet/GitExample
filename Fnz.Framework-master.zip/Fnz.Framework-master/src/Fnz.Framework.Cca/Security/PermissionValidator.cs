﻿using Fnz.Framework.Cca.Validation;

namespace Fnz.Framework.Cca.Security
{
    public class PermissionValidator<T> : IPermissionValidator<T>
    {
        private readonly IUserContext _context;

        private readonly IRequiredPermissions _requiredPermissions;

        public PermissionValidator(IUserContext context, IRequiredPermissions requiredPermissions)
        {
            _context = context;
            _requiredPermissions = requiredPermissions;
        }

        public void EnsureUserHasPermission()
        {
            //TODO: look up the required permission based on the command type
            _context.EnsureUserHasPermission(_requiredPermissions.GetPermissionFor<T>());
        }
    }
}