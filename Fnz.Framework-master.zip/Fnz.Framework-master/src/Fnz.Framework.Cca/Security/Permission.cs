﻿namespace Fnz.Framework.Cca.Security
{
    public class Permission : IPermission
    {
        public int Id { get; set; }

        public string Name { get; set; }
    }
}