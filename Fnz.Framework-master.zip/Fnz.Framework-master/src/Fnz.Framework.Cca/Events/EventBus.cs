using Fnz.Framework.Components.Tasks.DataAccess.Writers;
using Fnz.Framework.DataAccess;

namespace Fnz.Framework.Cca.Events
{
    public interface IEventBus
    {
        void Raise(IEvent @event);
    }

    public class EventBus : IEventBus
    {
        private readonly ITaskRequestWriter _taskRequestWriter;

        public EventBus(IDataAccess dataAccess) : this(new TaskRequestWriter(dataAccess))
        {
        }
        
        public EventBus(ITaskRequestWriter taskRequestWriter)
        {
            _taskRequestWriter = taskRequestWriter;
        }

        public void Raise(IEvent @event)
        {
            _taskRequestWriter.AddPendingTaskRequest(@event.EventTypeId(), TaskPriority.Medium, @event.Parameters());
        }
    }
}