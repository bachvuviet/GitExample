﻿using System.Collections.Generic;

namespace Fnz.Framework.Cca.Events
{
    public interface IEvent
    {
        int EventTypeId();

        string EventName();

        IDictionary<string, object> Parameters();
    }
}
