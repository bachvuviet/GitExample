﻿namespace Fnz.Framework.Cca.Messaging
{
    /// <summary>
    /// Implement this to consume platform messages. Rabbit MQ will call this to consume/handle a message
    /// </summary>
    /// <typeparam name="T">message to consume</typeparam>
    public interface IMessageConsumer<in T> : IBaseMessageConsumer<T>
    {
        /// <summary>
        /// This method gets called when a message of the given type arrives at a messaging host
        /// </summary>
        /// <param name="messageToConsume">The message being consumed</param>
        void Consume(T messageToConsume);
    }
}
