﻿namespace Fnz.Framework.Cca.Messaging
{
    /// <summary>
    /// Implement this to consume a platform messages coming from a specific virtual host
    /// Rabbit MQ will call this to consume/handle a message
    /// </summary>
    /// <typeparam name="T">message to consume</typeparam>
    public interface IPropositionMessageConsumer<in T> : IBaseMessageConsumer<T>
    {
        /// <summary>
        /// This method gets called when a message of the given type arrives at a messaging host
        /// </summary>
        /// <param name="messageToConsume">The message being consumed</param>
        /// <param name="propositionId">Populated if the message comes from a queue that is bound to a specific proposition</param>
        void Consume(T messageToConsume, int propositionId);
    }
}