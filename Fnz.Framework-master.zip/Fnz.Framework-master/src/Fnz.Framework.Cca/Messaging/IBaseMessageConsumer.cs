﻿namespace Fnz.Framework.Cca.Messaging
{
    /// <summary>
    /// Marker for base interface for all message consumers.
    /// </summary>
    public interface IBaseMessageConsumer
    {
    }

    /// <summary>
    /// Base interface for all message consumers.
    /// </summary>
    public interface IBaseMessageConsumer<in T> : IBaseMessageConsumer
    {
    }
}