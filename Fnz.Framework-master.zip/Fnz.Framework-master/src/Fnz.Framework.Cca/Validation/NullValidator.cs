﻿namespace Fnz.Framework.Cca.Validation
{
    public class NullValidator<T> : IValidate<T>
    {
        public ValidationResult Validate(T command)
        {
            return new ValidationResult();
        }

        public void EnsureCommandIsValid(T command)
        {
        }
    }
}