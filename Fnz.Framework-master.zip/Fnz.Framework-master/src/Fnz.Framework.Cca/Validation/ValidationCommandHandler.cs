﻿using Fnz.Core.Platform.Framework.Commands;

namespace Fnz.Framework.Cca.Validation
{
    /// <summary>
    /// Decorator that validates the command before executing it
    /// </summary>
    /// <typeparam name="TCommand">Command Handler Type</typeparam>
    public class ValidationCommandHandler<TCommand> : ICommandHandler<TCommand>
    {
        private readonly ICommandHandler<TCommand> _handler;

        private readonly IValidate<TCommand> _commandValidator;

        public ValidationCommandHandler(ICommandHandler<TCommand> handler, IValidate<TCommand> commandValidator)
        {
            _handler = handler;
            _commandValidator = commandValidator;
        }

        public void Execute(TCommand command)
        {
            _commandValidator.EnsureCommandIsValid(command);

            _handler.Execute(command);
        }
    }
}