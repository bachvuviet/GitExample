﻿using Fnz.Framework.Cca.ErrorHandling.Exceptions;

namespace Fnz.Framework.Cca.Validation
{
    public abstract class Validator<T> : IValidate<T>
    {
        public abstract ValidationResult Validate(T command);

        public void EnsureCommandIsValid(T command)
        {
            var validationResult = Validate(command);

            if (!validationResult.IsValid())
            {
                throw new ValidationException(validationResult.Errors());
            }
        }
    }
}