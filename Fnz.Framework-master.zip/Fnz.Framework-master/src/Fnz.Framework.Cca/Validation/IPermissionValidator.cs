﻿namespace Fnz.Framework.Cca.Validation
{
    public interface IPermissionValidator<T>
    {
        void EnsureUserHasPermission();
    }
}