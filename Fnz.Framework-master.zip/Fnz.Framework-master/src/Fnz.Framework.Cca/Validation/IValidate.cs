﻿namespace Fnz.Framework.Cca.Validation
{
    public interface IValidate<T>
    {
        ValidationResult Validate(T command);

        void EnsureCommandIsValid(T command);
    }
}