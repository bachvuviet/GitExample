﻿using System.Collections.Generic;

using Fnz.Framework.Cca.ErrorHandling.Contracts;

namespace Fnz.Framework.Cca.Validation
{
    public interface IContractValidator<TCommand>
    {
        List<ValidationError> Validate(TCommand command);
    }
}
