using System;
using System.Collections.Generic;
using System.Linq;
using FluentValidation.Results;
using Fnz.Framework.Cca.ErrorHandling.Contracts;

namespace Fnz.Framework.Cca.Validation.Fluent
{
    public class DefaultErrorParameterBuilder<T> : IErrorParameterBuilder<T>
    {
        private readonly string[] _toIgnore = new[] { "PropertyName" };

        public IEnumerable<ErrorParameter> BuildFromFailure(ValidationFailure failure, T command)
        {
            var parameters = new List<ErrorParameter>();

            // add the attempted value
            parameters.Add(new ErrorParameter { Name = failure.PropertyName, Value = Convert.ToString(failure.AttemptedValue) });

            // add any message parameters we populated
            parameters.AddRange(
                failure.MessageArguments
                    .Where(c => !_toIgnore.Contains(c.Key))
                    .Select(arg => new ErrorParameter { Name = arg.Key, Value = Convert.ToString(arg.Value) })
            );

            return parameters;
        }
    }
}