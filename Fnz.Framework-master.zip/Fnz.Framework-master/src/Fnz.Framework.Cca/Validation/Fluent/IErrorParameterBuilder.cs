using System.Collections.Generic;
using FluentValidation.Results;
using Fnz.Framework.Cca.ErrorHandling.Contracts;

namespace Fnz.Framework.Cca.Validation.Fluent
{
    public interface IErrorParameterBuilder<T>
    {
        IEnumerable<ErrorParameter> BuildFromFailure(ValidationFailure failure, T command);
    }
}