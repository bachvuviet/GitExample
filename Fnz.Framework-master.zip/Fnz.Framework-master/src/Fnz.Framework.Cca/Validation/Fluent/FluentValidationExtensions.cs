﻿using System.Diagnostics.CodeAnalysis;
using FluentValidation;
using Fnz.Api.Errors;

namespace Fnz.Framework.Cca.Validation.Fluent
{
    public static class FluentValidationExtensions
    {
        /// <summary>
        /// Specifies an error code & message pair to use if validation fails
        /// </summary>
        /// <typeparam name="T">the type of the class</typeparam>
        /// <typeparam name="TProperty">the type of the property on the class</typeparam>
        /// <param name="rule">The current rule</param>
        /// <param name="errorCode">The FNZ error code to use</param>
        /// <returns>the rule builder</returns>
        [SuppressMessage("Microsoft.StyleCop.CSharp.DocumentationRules", "SA1603:DocumentationMustContainValidXml", Justification = "The Xml in the documentation looks fine - not sure why stylecop is flagging this up.")]
        public static IRuleBuilderOptions<T, TProperty> WithErrorCodeAndMessage<T, TProperty>(
            this IRuleBuilderOptions<T, TProperty> rule, ErrorCode errorCode)
        {
            rule.WithMessage(errorCode.Description);

            return rule.Configure(config => { config.CurrentValidator.ErrorCode = errorCode.Id; });
        }
    }
}