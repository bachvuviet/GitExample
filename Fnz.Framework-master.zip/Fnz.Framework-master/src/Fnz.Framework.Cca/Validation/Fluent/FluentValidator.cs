﻿using System.Linq;
using FluentValidation;
using Fnz.Framework.Cca.ErrorHandling.Contracts;
using Fnz.Framework.Util.CodeQuality;
using ValidationException = Fnz.Framework.Cca.ErrorHandling.Exceptions.ValidationException;

namespace Fnz.Framework.Cca.Validation.Fluent
{
    /// <summary>
    /// Provides a base class for validators which use FluentValidation
    /// Adapts FluentValidation.Results.ValidationResult to Fnz.Framework.Cca.Validation.ValidationResult
    /// </summary>
    /// <typeparam name="T">Type to be validated</typeparam>
    public abstract class FluentValidator<T> : AbstractValidator<T>, IValidate<T>
    {
        private readonly IErrorParameterBuilder<T> _parameterBuilder;

        protected FluentValidator() : this(new DefaultErrorParameterBuilder<T>())
        {            
        }

        protected FluentValidator(IErrorParameterBuilder<T> parameterBuilder)
        {
            _parameterBuilder = parameterBuilder;
        }

        [IgnoreMethodHidesBase(IgnoreReason.AcceptableDesign)] // The return type is different so we could not override the Validate
        public new ValidationResult Validate(T command)
        {
            var validationResult = base.Validate(command);

            var mappedResult = new ValidationResult();

            if (!validationResult.IsValid)
            {
                mappedResult.AddError(validationResult.Errors.Select(
                    failure => new ValidationError
                    {
                        ErrorCode = failure.ErrorCode.GetValueOrDefault(),
                        UserMessage = failure.ErrorMessage,
                        Property = failure.PropertyName,
                        Parameters = _parameterBuilder.BuildFromFailure(failure, command).ToList()
                    }

                ));
            }

            return mappedResult;
        }

        public void EnsureCommandIsValid(T command)
        {
            var validationResult = Validate(command);
            if (!validationResult.IsValid())
            {
                throw new ValidationException(validationResult.Errors());
            }
        }
    }
}
