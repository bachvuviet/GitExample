﻿using System.Collections.Generic;
using FluentValidation.Results;
using Fnz.Api.Errors;

namespace Fnz.Framework.Cca.Validation.Fluent
{
    public class FluentValidationFailure : ValidationFailure
    {
        public FluentValidationFailure(string propertyName, ErrorCode errorCode)
            : base(propertyName, errorCode.Description, errorCode.Id)
        {
            MessageArguments = CreateDefaultMessageArguments(propertyName);
        }

        public FluentValidationFailure(string propertyName, ErrorCode errorCode, object attemptedValue)
            : base(propertyName, errorCode.Description, errorCode.Id, attemptedValue)
        {
            MessageArguments = CreateDefaultMessageArguments(propertyName);
        }

        public FluentValidationFailure(string propertyName, ErrorCode errorCode, Dictionary<string, object> messageArguments)
            : base(propertyName, errorCode.Description, errorCode.Id)
        {
            MessageArguments = messageArguments ?? CreateDefaultMessageArguments(propertyName);
        }

        public FluentValidationFailure(string propertyName, ErrorCode errorCode, object attemptedValue, Dictionary<string, object> messageArguments)
            : base(propertyName, errorCode.Description, errorCode.Id, attemptedValue)
        {
            MessageArguments = messageArguments ?? CreateDefaultMessageArguments(propertyName);
        }

        private static Dictionary<string, object> CreateDefaultMessageArguments(string propertyName)
        {
            return new Dictionary<string, object>
            {
                { "PropertyName", propertyName }
            };
        }
    }
}