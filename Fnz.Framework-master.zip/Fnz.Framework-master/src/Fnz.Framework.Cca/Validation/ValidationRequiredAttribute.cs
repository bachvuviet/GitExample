﻿using System;

namespace Fnz.Framework.Cca.Validation
{
    /// <summary>
    /// Marker interface to specify that a validator should be injected before the command / query is executed (AOP)
    /// </summary>
    public sealed class ValidationRequiredAttribute : Attribute
    {
    }
}