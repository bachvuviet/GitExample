﻿using System.Collections.Generic;
using System.Linq;
using Fnz.Framework.Cca.ErrorHandling.Contracts;

namespace Fnz.Framework.Cca.Validation
{
    public class ValidationResult
    {
        private readonly List<ValidationError> _errors;

        public ValidationResult()
        {
            _errors = new List<ValidationError>();
        }

        public bool IsValid()
        {
            return !_errors.Any();
        }

        public IEnumerable<ValidationError> Errors()
        {
            return _errors;
        }

        public void AddError(ValidationError error)
        {
            _errors.Add(error);
        }

        public void AddError(IEnumerable<ValidationError> errors)
        {
            _errors.AddRange(errors);
        }
    }
}