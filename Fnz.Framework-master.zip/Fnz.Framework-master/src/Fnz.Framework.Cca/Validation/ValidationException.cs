﻿using System.Collections.Generic;
using System.Linq;
using System.Net;
using Fnz.Framework.Cca.ErrorHandling.Contracts;

namespace Fnz.Framework.Cca.ErrorHandling.Exceptions
{
    /// <summary>
    /// Occurs when contract or its properties violates validation rules
    /// </summary>
    public class ValidationException : ErrorReferenceException
    {
        // NOTE: System.Net.HttpStatusCode doesn't contain status 422 Unprocessable Entity,
        // so we need to return it in the way below.
        public ValidationException(params ValidationError[] validationErrors)
            : base(new ErrorContract { ValidationErrors = validationErrors.ToList() }, (HttpStatusCode)422)
        {
        }

        public ValidationException(IEnumerable<ValidationError> validationErrors)
            : base(new ErrorContract { ValidationErrors = validationErrors.ToList() }, (HttpStatusCode)422)
        {
        }
    }
}