﻿namespace Fnz.Framework.Cca.Validation
{
    public interface IValidationRule<T>
    {
        void Validate(T command, ValidationResult result);
    }
}