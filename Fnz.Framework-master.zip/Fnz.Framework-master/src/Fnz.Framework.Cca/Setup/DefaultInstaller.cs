using Castle.MicroKernel.Registration;
using Castle.MicroKernel.SubSystems.Configuration;
using Castle.Windsor;
using FluentValidation;
using Fnz.Framework.Cca.Validation;
using Fnz.Framework.DataAccess.RecordsetMapping;
using Fnz.Framework.ReadersWriters;
using Fnz.Framework.Util.Caching.EnumCache.CachePopulators;

namespace Fnz.Framework.Cca.Setup
{
    /// <summary>
    /// Register all the common types in the specified assembly.
    /// </summary>
    public class DefaultInstaller : IWindsorInstaller
    {
        // TODO: Migrate towards this always being true, but for now keep compatibility with code that expects it to be false
        private readonly bool _includeInternalTypes;
        // TODO: Migrate towards this always being false, but for now keep compatibility with code that expects it to be true
        private readonly bool _includeRecordsetMappers;

        public DefaultInstaller(string assemblyName)
        {
            AssemblyName = assemblyName;
            _includeInternalTypes = false;
            _includeRecordsetMappers = true;
        }

        public DefaultInstaller(string assemblyName, bool includeInternalTypes)
        {
            AssemblyName = assemblyName;
            _includeInternalTypes = includeInternalTypes;
            _includeRecordsetMappers = true;
        }

        public DefaultInstaller(string assemblyName, bool includeInternalTypes, bool includeRecordsetMappers)
        {
            AssemblyName = assemblyName;
            _includeInternalTypes = includeInternalTypes;
            _includeRecordsetMappers = includeRecordsetMappers;
        }

        protected string AssemblyName { get; private set; }

        public virtual void Install(IWindsorContainer container, IConfigurationStore store)
        {
            container.Register(
                Classes
                    .FromAssemblyNamed(AssemblyName)
                    .IncludeNonPublicTypes(_includeInternalTypes)
                    .BasedOn(typeof(EnumCachePopulatorBase<>))
                    .LifestyleTransient()
                    .WithService.FirstInterface(),
                Classes.FromAssemblyNamed(AssemblyName)
                    .IncludeNonPublicTypes(_includeInternalTypes)
                    .BasedOn(typeof(IPermissionValidator<>))
                    .LifestyleTransient()
                    .WithService.AllInterfaces(),
                Classes.FromAssemblyNamed(AssemblyName)
                    .IncludeNonPublicTypes(_includeInternalTypes)
                    .BasedOn(typeof(DataAccessBase))
                    .LifestyleTransient()
                    .WithService.AllInterfaces(),
                Classes.FromAssemblyNamed(AssemblyName)
                    .IncludeNonPublicTypes(_includeInternalTypes)
                    .BasedOn(typeof(IValidate<>))
                    .LifestyleTransient()
                    .WithService.AllInterfaces(),
                Classes.FromAssemblyNamed(AssemblyName)
                    .IncludeNonPublicTypes(_includeInternalTypes)
                    .BasedOn(typeof(IValidator<>))
                    .LifestyleTransient()
                    .WithService.AllInterfaces()
                )
                .RegisterCommandHandler(AssemblyName, _includeInternalTypes)
                .RegisterQueryHandlers(AssemblyName, _includeInternalTypes);
                
                if (_includeRecordsetMappers){
                    container.Register(
                         Classes.FromAssemblyNamed(AssemblyName)
                             .IncludeNonPublicTypes(_includeInternalTypes)
                             .BasedOn(typeof(RecordsetMapper<>))
                             .LifestyleTransient()
                             .WithService.AllInterfaces()
                    );
                }               
        }
    }
}
