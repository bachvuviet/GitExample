using System;
using Castle.MicroKernel.Registration;
using Castle.Windsor;
using Fnz.Core.Platform.Framework;
using Fnz.Core.Platform.Framework.Commands;
using Fnz.Framework.Cca.Validation;

namespace Fnz.Framework.Cca.Setup
{
    public static class HandlerRegistrationUtil
    {
        public static IWindsorContainer RegisterQueryHandlers(this IWindsorContainer container, string assemblyName, bool includeInternalTypes = false)
        {
            return container.Register(CreateDescriptor(assemblyName, typeof(IQueryHandler<,>), false, includeInternalTypes));
        }

        public static IWindsorContainer OverrideQueryHandlers(this IWindsorContainer container, string assemblyName, bool includeInternalTypes = false)
        {
            return container.Register(CreateDescriptor(assemblyName, typeof(IQueryHandler<,>), true, includeInternalTypes));
        }

        public static IWindsorContainer RegisterCommandHandler(this IWindsorContainer container, string assemblyName, bool includeInternalTypes = false)
        {
            return container
                .Register(CreateDescriptor(assemblyName, typeof(ICommandHandler<>), false, includeInternalTypes))
                .Register(CreateDescriptor(assemblyName, typeof(ICommandHandler<,>), false, includeInternalTypes));
        }

        public static IWindsorContainer OverrideCommandHandlers(this IWindsorContainer container, string assemblyName, bool includeInternalTypes = false)
        {
            return container
                .Register(CreateDescriptor(assemblyName, typeof(ICommandHandler<>), true, includeInternalTypes))
                .Register(CreateDescriptor(assemblyName, typeof(ICommandHandler<,>), true, includeInternalTypes));
        }

        internal static FromAssemblyDescriptor IncludeNonPublicTypes(this FromAssemblyDescriptor descriptor, bool includeInternalTypes)
        {
            if (includeInternalTypes)
            {
                return descriptor.IncludeNonPublicTypes();
            }

            return descriptor;
        }

        private static BasedOnDescriptor CreateDescriptor(string assemblyName, Type handlerType, bool overrideExisting, bool includeInternalTypes)
        {
            return
                Classes
                    .FromAssemblyNamed(assemblyName)
                    .IncludeNonPublicTypes(includeInternalTypes)
                    .BasedOn(handlerType)
                    .WithServiceAllInterfaces()
                    .LifestyleTransient()
                    .Configure(OverrideExistingAction(overrideExisting))
                    .Configure(IncludeValidationInterceptor(handlerType));
        }

        private static Action<ComponentRegistration> OverrideExistingAction(bool overrideExisting)
        {
            return component =>
                {
                    if (overrideExisting)
                    {
                        component.IsDefault();
                    }
                };
        }

        private static Action<ComponentRegistration> IncludeValidationInterceptor(Type handlerType)
        {
            return component =>
                {
                    if (Attribute.IsDefined(component.Implementation, typeof(ValidationRequiredAttribute)))
                    {
                        component.Interceptors(ResolveValidationInterceptor(component, handlerType));
                    }
                };
        }

        private static Type ResolveValidationInterceptor(ComponentRegistration component, Type handlerType)
        {
            return typeof(ValidationInteceptor<>).MakeGenericType(component.Implementation.GetInterface(handlerType.Name).GetGenericArguments()[0]);
        }
    }
}
