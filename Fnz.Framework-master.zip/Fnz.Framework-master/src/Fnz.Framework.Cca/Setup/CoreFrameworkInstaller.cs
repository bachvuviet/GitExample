using Castle.Facilities.Startable;
using Castle.MicroKernel.Registration;
using Castle.MicroKernel.SubSystems.Configuration;
using Castle.Windsor;
using Fnz.Framework.Cca.Events;
using Fnz.Framework.Components.Environment;
using Fnz.Framework.DataAccess.RecordsetMapping;
using Fnz.Framework.ReadersWriters;
using Fnz.Framework.Util.Caching.EnumCache;
using Fnz.Framework.Util.Extensions;
using Fnz.Framework.Util.Hashing;

namespace Fnz.Framework.Cca.Setup
{
    /// <summary>
    /// TODO - rename this to 'CcaInstaller'
    /// Install all the items in Fnz.Framework.Cca (TODO some of the items are now in Fnz.Framework dll so shouldn't really be installed here)
    /// </summary>
    /// <remarks>
    /// Note this does not inherit from DefaultInstaller because the DefaultInstaller's install of ICommand classes didn't register things correctly (not sure why)
    /// </remarks>
    public class CoreFrameworkInstaller : IWindsorInstaller
    {
        private bool _lazyLoadEnumCache = false;

        public void Install(IWindsorContainer container, IConfigurationStore store)
        {
            container.AddFacilitySafe<StartableFacility>();

            container.Register(
                Classes
                    .FromThisAssembly()
                    .BasedOn(typeof(DataAccessBase))
                    .LifestyleTransient()
                    .WithService.FirstInterface(),
                Classes
                    .FromThisAssembly()
                    .BasedOn(typeof(RecordsetMapper<>))
                    .LifestyleTransient()
                    .WithService.AllInterfaces(),
                Component
                    .For(typeof(ValidationInteceptor<>))
                    .LifestyleTransient(),
                Component
                    .For<IEventBus>().ImplementedBy<EventBus>()
                    .LifeStyle.Transient,
                Component
                    .For<IHashProcessFactory>()
                    .ImplementedBy<HashProcessFactory>()
                    .LifeStyle.Transient,            
                Component
                    .For<IEnvironmentInformationProvider>()
                    .ImplementedBy<EnvironmentInformationProvider>()
                    .LifestyleTransient());

            if (_lazyLoadEnumCache)
            {
                container.Register(
                    Component
                        .For<IEnumCache>()
                        .ImplementedBy<LazyLoadEnumCache>()
                        .LifestyleSingleton()
                    );
            }
            else
            {
                container.Register(
                    Component
                        .For<IEnumCache>()
                        .ImplementedBy<EnumCache>()
                        .LifestyleSingleton()
                        .StartUsingMethod("Refresh") // Using string version of the method due to a bug in Castle.Windsor (FWK-452)
                    );
            }        
        }

        /// <summary>
        /// Can be used when creating this installer to indicate (fluently) that we want the EnumCache to be loaded when first accessed
        /// rather than when we startup.
        /// e.g. new CoreFrameworkInstaller().LazyLoadEnumCache(true));
        /// </summary>
        public CoreFrameworkInstaller LazyLoadEnumCache(bool shouldLazyLoad)
        {
            _lazyLoadEnumCache = shouldLazyLoad;
            return this;
        }
    }
}
