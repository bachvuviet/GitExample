﻿using Castle.DynamicProxy;
using Fnz.Framework.Cca.Validation;
using Fnz.Framework.Util.Container;

namespace Fnz.Framework.Cca.Setup
{
    public class ValidationInteceptor<TCommand> : IInterceptor
    {
        /// <summary>
        /// We have to use factory here and release validators after calling EnsureCommandIsValid method!
        /// This is because validators may hold a state and reusing them may cause issues.
        /// e.g. during SubAccountInstructionGroup submit (SubmitSubAccountInstructionGroupCommandHandler)
        /// </summary>
        private readonly IFactory<IValidate<TCommand>> _validatorFactory;

        public ValidationInteceptor(IFactory<IValidate<TCommand>> validatorFactory)
        {
            _validatorFactory = validatorFactory;
        }

        public void Intercept(IInvocation invocation)
        {
            var validator = _validatorFactory.Create();

            try
            {
                var command = (TCommand)invocation.Arguments[0];

                validator.EnsureCommandIsValid(command);

                invocation.Proceed();
            }
            finally
            {
                _validatorFactory.Release(validator);
            }
        }
    }
}