﻿using Castle.Facilities.Logging;
using Castle.Facilities.WcfIntegration;
using Castle.MicroKernel.Registration;
using Castle.MicroKernel.SubSystems.Configuration;
using Castle.Windsor;
using Fnz.Framework.Filestore.Service.Config;

namespace Fnz.Framework.Filestore.Service.Bootstrapping
{
    public class FilestoreServiceInstaller : IWindsorInstaller
    {
        public void Install(IWindsorContainer container, IConfigurationStore store)
        {
            container.AddFacility<LoggingFacility>(f => f.LogUsing(LoggerImplementation.Log4net).WithConfig("log4net.config"));

            container.AddFacility<WcfFacility>()
                    .Register(
                            Component.For<IFilestoreConfiguration>()
                                    .ImplementedBy<FilestoreConfigurationFromFile>(),
                            Component.For<IFilestore>()
                                    .ImplementedBy<Filestore>(),
                            Component.For<IFilestoreService>()
                                    .ImplementedBy<FilestoreService>()
                    );
        }
    }
}