﻿using System;
using System.Configuration;
using System.IO;

namespace Fnz.Framework.Filestore.Service.Config
{
    public class FilestoreConfigurationFromFile : IFilestoreConfiguration
    {
        private const string FilestoreLocationSetting = "FilestoreLocation";
        private const string SystemIdSetting = "SystemId";
        private const string PasswordSetting = "Password";

        public string FilestoreLocation 
        {
            get { return ConfigurationManager.AppSettings[FilestoreLocationSetting]; }
        }

        public string Password
        {
            get { return ConfigurationManager.AppSettings[PasswordSetting]; }
        }

        public string SystemId
        {
            get { return ConfigurationManager.AppSettings[SystemIdSetting]; }
        }

        public string RootDirectory
        {
            get
            {
                string filestoreDirectory = Path.Combine(FilestoreLocation, "filestore");
                string rootDirectory = Path.Combine(filestoreDirectory, SystemId);

                return rootDirectory;
            }
        }

        public override string ToString()
        {
            return "FilestoreLocation: {0}. SystemId: {1}.".FormatWith(FilestoreLocation, SystemId);
        }
    }
}
