﻿using System.IO;

namespace Fnz.Framework.Filestore.Service.Config
{
    public class FilestoreConfiguration : IFilestoreConfiguration
    {
        public string FilestoreLocation { get; set; }

        public string Password { get; set; }

        public string SystemId { get; set; }

        public string RootDirectory
        {
            get
            {
                string filestoreDirectory = Path.Combine(FilestoreLocation, "filestore");
                string rootDirectory = Path.Combine(filestoreDirectory, SystemId);

                return rootDirectory;
            }
        }
    }
}
