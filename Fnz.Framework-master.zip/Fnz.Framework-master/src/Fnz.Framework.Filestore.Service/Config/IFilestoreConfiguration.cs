﻿namespace Fnz.Framework.Filestore.Service.Config
{
    public interface IFilestoreConfiguration
    {
        string RootDirectory { get; } 

        string FilestoreLocation { get; } 

        string SystemId { get; }

        string Password { get; }
    }
}
