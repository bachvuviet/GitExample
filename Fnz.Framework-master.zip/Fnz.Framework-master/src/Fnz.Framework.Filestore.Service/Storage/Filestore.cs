﻿using System;
using System.IO;
using Castle.Core.Logging;
using Fnz.Framework.Filestore.Common;
using Fnz.Framework.Filestore.Service.Config;

namespace Fnz.Framework.Filestore.Service
{
    public class Filestore : IFilestore
    {
        private readonly FilestorePathBuilder _filestorePathBuilder;
        private readonly DocumentUrlDecoder _documentUrlDecoder;
        private ILogger _logger = NullLogger.Instance;

        public Filestore(IFilestoreConfiguration filestoreConfiguration)
        {
            CheckFilestoreConfiguration(filestoreConfiguration);

            _filestorePathBuilder = new FilestorePathBuilder(filestoreConfiguration);
            CheckFilestoreLocation();

            _documentUrlDecoder = new DocumentUrlDecoder
                                      {
                                          SystemId = filestoreConfiguration.SystemId,
                                          Password = filestoreConfiguration.Password
                                      };
        }

        public ILogger Logger
        {
            set { _logger = value; }
        }

        public void SaveContent(string documentUrl, Stream contentStream)
        {
            CheckFilestoreLocation();

            long id = DecryptDocumentId(documentUrl);
            string filename = _filestorePathBuilder.ToFilename(id);
            string readOnlyFilename = _filestorePathBuilder.ToReadOnlyFilename(id);
            if (new FileInfo(filename).Exists || new FileInfo(readOnlyFilename).Exists)
            {
                _logger.Warn("Document already exists - document id: {0}".FormatWith(id));
                throw new DocumentAlreadyExistsException(documentUrl);
            }

            string path = _filestorePathBuilder.ToPath(id);
            Directory.CreateDirectory(path);

            WriteData(filename, contentStream);
        }

        private void WriteData(string filename, Stream stream)
        {
            int totalBytes = 0;
            using (var binaryWriter = new BinaryWriter(File.Open(filename, FileMode.Create)))
            {
                var buf = new byte[8192];
                int bytesRead = stream.Read(buf, 0, buf.Length);
                while (bytesRead > 0)
                {
                    totalBytes += bytesRead;
                    binaryWriter.Write(buf, 0, bytesRead);
                    bytesRead = stream.Read(buf, 0, buf.Length);
                }
            }

            _logger.Debug("WriteData completed '{0}' - {1} bytes".FormatWith(filename, totalBytes));
        }

        public Stream GetContent(string documentUrl)
        {
            CheckFilestoreLocation();

            long id = DecryptDocumentId(documentUrl);
            string filename = _filestorePathBuilder.ToFilename(id);
            if (new FileInfo(filename).Exists == false)
            {
                filename = _filestorePathBuilder.ToReadOnlyFilename(id);
                if (new FileInfo(filename).Exists == false)
                {
                    _logger.Warn("Document does not exist - document id: {0}".FormatWith(id));
                    throw new DocumentDoesNotExistsException(documentUrl);
                }
            } 

            Stream toReturn = new FileStream(filename, FileMode.Open, FileAccess.Read);

            return toReturn;
        }

        private long DecryptDocumentId(string encryptedDocumentUrl)
        {
            long documentId;

            try
            {
                documentId = _documentUrlDecoder.DecodeDocumentUrl(encryptedDocumentUrl);    
            }
            catch (InvalidDocumentIdException)
            {
                _logger.Warn("Invalid document url: {0}".FormatWith(encryptedDocumentUrl));
                throw;
            }

            return documentId;
        }

        public void CheckFilestoreLocation()
        {
            var filestoreLocation = new DirectoryInfo(_filestorePathBuilder.FilestoreRoot);
            if (!filestoreLocation.Exists)
            {
                _logger.Error("Filestore location not found: {0}".FormatWith(filestoreLocation.FullName));
                throw new FilestoreLocationNotFoundException(filestoreLocation.FullName);
            }
        }

        private void CheckFilestoreConfiguration(IFilestoreConfiguration filestoreConfiguration)
        {
            if (filestoreConfiguration.Password.IsNullOrEmpty())
            {
                _logger.Error("Filestore password not set");
                throw new FilestoreConfigurationException("Filestore password not set");
            }

            if (filestoreConfiguration.SystemId.IsNullOrEmpty())
            {
                _logger.Error("Filestore system id not set");
                throw new FilestoreConfigurationException("Filestore system id not set");
            }

            if (filestoreConfiguration.FilestoreLocation.IsNullOrEmpty())
            {
                _logger.Error("Filestore location not set");
                throw new FilestoreConfigurationException("Filestore location not set");
            }
        }
    }
}
