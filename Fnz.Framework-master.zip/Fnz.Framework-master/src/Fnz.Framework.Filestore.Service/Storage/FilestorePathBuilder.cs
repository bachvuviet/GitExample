﻿using Fnz.Framework.Filestore.Common;
using Fnz.Framework.Filestore.Service.Config;

namespace Fnz.Framework.Filestore.Service
{
    public class FilestorePathBuilder
    {
        private readonly IFilestoreConfiguration _fileStoreConfiguration;

        public FilestorePathBuilder(IFilestoreConfiguration filestoreConfiguration)
        {
            this._fileStoreConfiguration = filestoreConfiguration;
        }

        public string FilestoreRoot
        {
            get
            {
                return _fileStoreConfiguration.RootDirectory;
            }
        }

        public string ToRelativePath(long documentId)
        {
            ValidateDocumentId(documentId);
            string path = string.Empty;
            string hexId = documentId.ToString("X16");
            for (int i = 0; i < 7; i++)
            {
                string pathElement = hexId.Substring(i * 2, 2);
                path = System.IO.Path.Combine(path, pathElement);
            }

            return path;            
        }

        public string ToPath(long documentId)
        {
            ValidateDocumentId(documentId);
            string path = _fileStoreConfiguration.RootDirectory;
            path = System.IO.Path.Combine(path, ToRelativePath(documentId));

            return path;
        }

        public string ToReadOnlyPath(long documentId)
        {
            ValidateDocumentId(documentId);
            string path = _fileStoreConfiguration.RootDirectory;
            path = System.IO.Path.Combine(path, "readonly");
            path = System.IO.Path.Combine(path, ToRelativePath(documentId));

            return path;
        }

        public string ToFilename(long documentId)
        {
            ValidateDocumentId(documentId);
            string path = ToPath(documentId);
            string filename = System.IO.Path.Combine(path, documentId.ToString("X16"));  

            return filename;
        }

        public string ToReadOnlyFilename(long documentId)
        {
            ValidateDocumentId(documentId);
            string path = ToReadOnlyPath(documentId);
            string filename = System.IO.Path.Combine(path, documentId.ToString("X16"));  

            return filename;
        }

        public string GetSystemId()
        {
            return _fileStoreConfiguration.SystemId;
        }

        private static void ValidateDocumentId(long documentId)
        {
            if (documentId <= 0)
            {
                throw new InvalidDocumentIdException(documentId.ToString());
            }
        }
    }
}
