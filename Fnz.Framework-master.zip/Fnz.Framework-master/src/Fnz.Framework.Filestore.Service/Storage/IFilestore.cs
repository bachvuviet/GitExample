﻿using System.IO;
using Fnz.Framework.Filestore.Common;

namespace Fnz.Framework.Filestore.Service
{
    public interface IFilestore
    {
        /// <summary>
        /// Saves content of stream
        /// </summary>
        /// <param name="documentId">id of content to save</param>
        /// <param name="contentStream">content to save</param>
        void SaveContent(string documentId, Stream contentStream);

        /// <summary>
        /// Gets requested content as a Stream
        /// </summary>
        /// <param name="documentId">id of content to get</param>
        /// <returns>Stream of content</returns>
        Stream GetContent(string documentId);

        /// <summary>
        /// Checks that the Filestore location exists
        /// </summary>
        /// <exception cref="FilestoreLocationNotFoundException">Thrown if filestore location not found</exception>
        void CheckFilestoreLocation();
    }
}
