﻿using System;
using System.ServiceModel.Channels;
using System.ServiceModel.Description;
using System.ServiceModel.Dispatcher;
using Fnz.Framework.Util.CodeQuality;

namespace Fnz.Framework.Filestore.Service
{
    public sealed class ReadDocumentHeaderAttribute : Attribute, IOperationBehavior
    {
        [ExcludeFromTestCoverage(IgnoreReason.AcceptableDesign, "Craig Goldie", "10/03/11")] // Forced to implement method - but don't do anything, so can ignore
        public void Validate(OperationDescription operationDescription)
        {
        }

        public void ApplyDispatchBehavior(OperationDescription operationDescription, DispatchOperation dispatchOperation)
        {
            dispatchOperation.Parent.MessageInspectors.Add(new ReadDocumentHeader(dispatchOperation.Action));   
        }

        [ExcludeFromTestCoverage(IgnoreReason.AcceptableDesign, "Craig Goldie", "10/03/11")] // Forced to implement method - but don't do anything, so can ignore
        public void ApplyClientBehavior(OperationDescription operationDescription, ClientOperation clientOperation)
        {
        }

        [ExcludeFromTestCoverage(IgnoreReason.AcceptableDesign, "Craig Goldie", "10/03/11")] // Forced to implement method - but don't do anything, so can ignore
        public void AddBindingParameters(OperationDescription operationDescription, BindingParameterCollection bindingParameters)
        {
        }
    }
}