﻿using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Dispatcher;

namespace Fnz.Framework.Filestore.Service
{
    public class ReadDocumentHeader : IDispatchMessageInspector
    {
        private readonly string _action;

        public ReadDocumentHeader(string action)
        {
            _action = action;
        }

        public object AfterReceiveRequest(ref Message request, IClientChannel channel, InstanceContext instanceContext)
        {
            if (request.Headers != null &&
                request.Headers.Count > 0 &&
                request.Headers.Action == _action)
            {
                var documentUrl = request.Headers.GetHeader<string>("DocumentUrl", "FilestoreService");
                DocumentContext.SetDocumentUrl(documentUrl);
            }

            return null;            
        }

        public void BeforeSendReply(ref Message reply, object correlationState)
        {
        }
    }
}
