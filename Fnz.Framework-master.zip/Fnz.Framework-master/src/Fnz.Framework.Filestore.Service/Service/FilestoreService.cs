﻿using System.IO;
using System.Reflection;
using System.ServiceModel;
using Fnz.Framework.Filestore.Common;

namespace Fnz.Framework.Filestore.Service
{
    public class FilestoreService : IFilestoreService
    {
        private readonly IFilestore _filestore;

        public FilestoreService(IFilestore filestore)
        {
            _filestore = filestore;
        }

        public void SaveContent(Stream contentStream)
        {
            string documentUrl = DocumentContext.GetDocumentUrl();
            try
            {
                _filestore.SaveContent(documentUrl, contentStream);
            }
            catch (InvalidDocumentIdException e)
            {
                throw new FaultException(
                    new FaultReason(e.Message),
                    new FaultCode("InvalidDocumentIdException"));
            }
            catch (DocumentAlreadyExistsException e)
            {
                throw new FaultException(
                    new FaultReason(e.Message),
                    new FaultCode("DocumentAlreadyExistsException"));
            }
            catch (FilestoreLocationNotFoundException)
            {
                throw new FaultException(
                    new FaultReason("Filestore location not found"),
                    new FaultCode("FilestoreLocationNotFoundException"));
            }
        }

        public Stream GetContent()
        {
            string documentUrl = DocumentContext.GetDocumentUrl();
            try
            {
                Stream contentStream = _filestore.GetContent(documentUrl);

                return contentStream;
            }
            catch (InvalidDocumentIdException e)
            {
                throw new FaultException(
                    new FaultReason(e.Message),
                    new FaultCode("InvalidDocumentIdException"));
            }
            catch (DocumentDoesNotExistsException e)
            {
                throw new FaultException(
                    new FaultReason(e.Message),
                    new FaultCode("DocumentDoesNotExistsException"));
            }
            catch (FilestoreLocationNotFoundException)
            {
                throw new FaultException(
                    new FaultReason("Filestore location not found"),
                    new FaultCode("FilestoreLocationNotFoundException"));
            }
        }

        public string Ping()
        {
            string toReturn;
            try
            {
                _filestore.CheckFilestoreLocation();
                toReturn = "SITE IS UP - version " + Assembly.GetExecutingAssembly().GetName().Version;
            }
            catch (FilestoreLocationNotFoundException)
            {
                toReturn = "FILESTORE LOCATION NOT FOUND";
            }

            return toReturn;
        }
    }
}
