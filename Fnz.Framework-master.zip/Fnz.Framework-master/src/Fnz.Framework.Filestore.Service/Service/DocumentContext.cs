﻿using System;
using System.Threading;

namespace Fnz.Framework.Filestore.Service
{
    public static class DocumentContext
    {
        private const string DocumentUrl = "DocumentUrl";

        public static void SetDocumentUrl(string documentUrl)
        {
            LocalDataStoreSlot slot = Thread.GetNamedDataSlot(DocumentUrl);
            Thread.SetData(slot, documentUrl);            
        }

        public static string GetDocumentUrl()
        {
            LocalDataStoreSlot secSlot = Thread.GetNamedDataSlot(DocumentUrl);
            return (string)Thread.GetData(secSlot);
        }
    }
}
