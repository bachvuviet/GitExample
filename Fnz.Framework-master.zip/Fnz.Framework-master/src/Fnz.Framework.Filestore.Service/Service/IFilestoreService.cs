﻿using System.IO;
using System.ServiceModel;
using System.ServiceModel.Web;

namespace Fnz.Framework.Filestore.Service
{
    [ServiceContract(Namespace = "http://fnz.co.uk/openwrap/filestore")]
    public interface IFilestoreService
    {
        [OperationContract]
        [ReadDocumentHeader]
        void SaveContent(Stream contentStream);

        [OperationContract]
        [ReadDocumentHeader]
        Stream GetContent();

        [OperationContract]
        [WebGet(UriTemplate = "", ResponseFormat = WebMessageFormat.Xml)]
        string Ping();
    }
}
