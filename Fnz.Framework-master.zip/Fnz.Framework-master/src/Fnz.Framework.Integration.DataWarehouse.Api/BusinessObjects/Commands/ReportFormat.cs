﻿namespace Fnz.Framework.Integration.DataWarehouse.Api.BusinessObjects.Commands
{
    public enum ReportFormat
    {
        NA,
        Excel2003,
        Excel,
        PDF,
        Xml
    }
}