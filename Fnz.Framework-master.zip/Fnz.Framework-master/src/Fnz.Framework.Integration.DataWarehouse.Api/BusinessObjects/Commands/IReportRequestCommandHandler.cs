﻿using Fnz.Core.Platform.Framework.Commands;

namespace Fnz.Framework.Integration.DataWarehouse.Api.BusinessObjects.Commands
{
    public interface IReportRequestCommandHandler : ICommandHandler<ReportRequestCommand>
    {
    }
}
