﻿using System;
using System.Collections.Generic;

namespace Fnz.Framework.Integration.DataWarehouse.Api.BusinessObjects.Commands
{
    public class ReportRequestCommand
    {
        public int UserId { get; set; }

        public string FileName { get; set; }

        public int TaskRequestId { get; set; }

        public ReportFormat ReportFormat { get; set; }

        public int ReportId { get; set; }

        public string ReportCUID { get; set; }

        public Dictionary<string, object> Parameters { get; set; }
    }
}
